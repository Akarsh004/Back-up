#########################################################################################
##                                                                                     ##
##   File: sh_BTEQ_COLLECT_STATS_PLDB_VAR.sh                                           ##
##   Creation Date:13/10/12                                                            ##
##   Last Modified:16/10/12                                                            ##
##   Purpose:This script is used to collect stats of CDR_PLDB_EEDW_VAR table.          ##
##   Created By: Harsha                                                                ##
##                                                                                     ##
#########################################################################################

. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq <<EOF

.RUN File = ${SrcDir}/td_plp.mlbt

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database GEEDW_PLP_S;

COLLECT STATS ON  GEEDW_EP_BULK_T.CDR_PLDB_EEDW_VAR COLUMN (PLDB_TRB_NUM);
COLLECT STATS ON  GEEDW_EP_BULK_T.CDR_PLDB_EEDW_VAR COLUMN (PLDB_PRT_SR);
COLLECT STATS ON  GEEDW_EP_BULK_T.CDR_PLDB_EEDW_VAR COLUMN (PLDB_DRW_NUM);
COLLECT STATS ON  GEEDW_EP_BULK_T.CDR_PLDB_EEDW_VAR COLUMN (FISCAL_WEEK_NUM);

.LOGOFF
.EXIT 0
