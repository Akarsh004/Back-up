# ---------------------------------------------------------------------------- 
#                                             
# File: sh_GEEDW_BTEQ_CDR_ODS_R_ROUTE_NODE.sh
# Creation Date: 07/28/11 
# Last Modified: 07/28/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
/* ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED */
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_R_ROUTE_NODE : Start         

---- DROP TABLE VT_CDR_ODS_R_ROUTE_NODE;             

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_R_ROUTE_NODE,NO LOG (
               RELATION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_TYPE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FROM_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TO_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TO_TYPE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FROZEN_IND VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATE_DATE DATE FORMAT 'YY/MM/DD' ,
      SOURCE_MODIFIED_DATE DATE FORMAT 'YY/MM/DD',
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YY/MM/DD' ,
      OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROUTE_TASK_USER_COMPANY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CMTS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ACTUAL_COMPLETION_DT DATE FORMAT 'YY/MM/DD' ,
      APPROVERS_RESPONSIBILITY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROUTE_ACTION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ALLOW_DELEGATION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ROUTE_TASK_USER VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ROUTE_SEQUENCE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      APPROVAL_STATUS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      REVIEW_CMTS_NEEDED VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      PARALLEL_NODE_PROCESSION_RULE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      SCHEDULED_COMPLETION_DT DATE FORMAT 'YY/MM/DD' ,
      TITLE1 VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROUTE_NODE_ID VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROUTE_INSTRUCTIONS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      TMPLT_TASK VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TASK_REQUIREMENT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROUTE_BRANCH VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DUE_DT_OFFSET VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      REVIEW_TASK VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DT_OFFSET_FROM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      REVIEWERS_CMTS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
            ASSIGNEE_SET_DUE_DT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
)

PRIMARY INDEX ( RELATION_ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_R_ROUTE_NODE : Processing : Populate GT table with CDC data        

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_R_ROUTE_NODE
(
RELATION_ID                     ,
FROM_ID                            ,
FROM_TYPE                       ,
FROM_NAME                                    ,
FROM_REVISION                             ,
FROM_VAULT                                   ,
TO_ID                                   ,
TO_TYPE                              ,
TO_NAME                           ,
TO_REVISION                   ,
TO_VAULT                          ,
FROZEN_IND                    ,
CREATED_BY                      ,
CREATION_DATE                              ,
LAST_UPDATED_BY                        ,
LAST_UPDATE_DATE                      ,
SOURCE_MODIFIED_DATE                          ,
SOURCE_ORIGINATED_DATE                     ,
OWNER                                ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ROUTE_TASK_USER_COMPANY               ,
CMTS                                    ,
ACTUAL_COMPLETION_DT                         ,
APPROVERS_RESPONSIBILITY                    ,
ROUTE_ACTION                               ,
ALLOW_DELEGATION                    ,
ROUTE_TASK_USER                        ,
ROUTE_SEQUENCE                         ,
APPROVAL_STATUS                       ,
REVIEW_CMTS_NEEDED               ,
PARALLEL_NODE_PROCESSION_RULE    ,
SCHEDULED_COMPLETION_DT                  ,
TITLE1                                   ,
ROUTE_NODE_ID                            ,
ROUTE_INSTRUCTIONS                 ,
TMPLT_TASK                    ,
TASK_REQUIREMENT                     ,
ROUTE_BRANCH                              ,
DUE_DT_OFFSET                              ,
REVIEW_TASK                                   ,
DT_OFFSET_FROM                          ,
REVIEWERS_CMTS                          ,
ASSIGNEE_SET_DUE_DT               ,
DW_LOAD_DATE                             ,
DW_CREATED_BY                            ,
DW_UPDATED_DATE                     ,
DW_UPDATED_BY                           
)

SELECT 
RELATION_ID                     ,
FROM_ID                            ,
FROM_TYPE                       ,
FROM_NAME                                    ,
FROM_REVISION                             ,
FROM_VAULT                                   ,
TO_ID                                   ,
TO_TYPE                              ,
TO_NAME                           ,
TO_REVISION                   ,
TO_VAULT                          ,
FROZEN_IND                    ,
CREATED_BY                      ,
CREATION_DATE                              ,
LAST_UPDATED_BY                        ,
LAST_UPDATE_DATE                      ,
SOURCE_MODIFIED_DATE                          ,
SOURCE_ORIGINATED_DATE                     ,
OWNER                                ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ROUTE_TASK_USER_COMPANY               ,
CMTS                                    ,
ACTUAL_COMPLETION_DT                         ,
APPROVERS_RESPONSIBILITY                    ,
ROUTE_ACTION                               ,
ALLOW_DELEGATION                    ,
ROUTE_TASK_USER                        ,
ROUTE_SEQUENCE                         ,
APPROVAL_STATUS                       ,
REVIEW_CMTS_NEEDED               ,
PARALLEL_NODE_PROCESSION_RULE    ,
SCHEDULED_COMPLETION_DT                  ,
TITLE1                                   ,
ROUTE_NODE_ID                            ,
ROUTE_INSTRUCTIONS                 ,
TMPLT_TASK                    ,
TASK_REQUIREMENT                     ,
ROUTE_BRANCH                              ,
DUE_DT_OFFSET                              ,
REVIEW_TASK                                   ,
DT_OFFSET_FROM                          ,
REVIEWERS_CMTS                          ,
ASSIGNEE_SET_DUE_DT               ,
DW_LOAD_DATE                             ,
DW_CREATED_BY                            ,
DW_UPDATED_DATE                     ,
DW_UPDATED_BY                           

FROM GEEDW_PLP_S.CDR_ODS_R_ROUTE_NODE_S
MINUS
SELECT 
RELATION_ID                     ,
FROM_ID                            ,
FROM_TYPE                       ,
FROM_NAME                                    ,
FROM_REVISION                             ,
FROM_VAULT                                   ,
TO_ID                                   ,
TO_TYPE                              ,
TO_NAME                           ,
TO_REVISION                   ,
TO_VAULT                          ,
FROZEN_IND                    ,
CREATED_BY                      ,
CREATION_DATE                              ,
LAST_UPDATED_BY                        ,
LAST_UPDATE_DATE                      ,
SOURCE_MODIFIED_DATE                          ,
SOURCE_ORIGINATED_DATE                     ,
OWNER                                ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ROUTE_TASK_USER_COMPANY               ,
CMTS                                    ,
ACTUAL_COMPLETION_DT                         ,
APPROVERS_RESPONSIBILITY                    ,
ROUTE_ACTION                               ,
ALLOW_DELEGATION                    ,
ROUTE_TASK_USER                        ,
ROUTE_SEQUENCE                         ,
APPROVAL_STATUS                       ,
REVIEW_CMTS_NEEDED               ,
PARALLEL_NODE_PROCESSION_RULE    ,
SCHEDULED_COMPLETION_DT                  ,
TITLE1                                   ,
ROUTE_NODE_ID                            ,
ROUTE_INSTRUCTIONS                 ,
TMPLT_TASK                    ,
TASK_REQUIREMENT                     ,
ROUTE_BRANCH                              ,
DUE_DT_OFFSET                              ,
REVIEW_TASK                                   ,
DT_OFFSET_FROM                          ,
REVIEWERS_CMTS                          ,
ASSIGNEE_SET_DUE_DT               ,
DW_LOAD_DATE                             ,
DW_CREATED_BY                            ,
DW_UPDATED_DATE                     ,
DW_UPDATED_BY                           

FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_R_ROUTE_NODE;               




-- Table: VT_CDR_ODS_R_ROUTE_NODE : Processing : Populate Stage table with CDC data only for mLDM processing     

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_R_ROUTE_NODE_S;  

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_ODS_R_ROUTE_NODE_S
(              
RELATION_ID                     ,
FROM_ID                            ,
FROM_TYPE                       ,
FROM_NAME                                    ,
FROM_REVISION                             ,
FROM_VAULT                                   ,
TO_ID                                   ,
TO_TYPE                              ,
TO_NAME                           ,
TO_REVISION                   ,
TO_VAULT                          ,
FROZEN_IND                     ,
CREATED_BY                      ,
CREATION_DATE                              ,
LAST_UPDATED_BY                        ,
LAST_UPDATE_DATE                      ,
SOURCE_MODIFIED_DATE                          ,
SOURCE_ORIGINATED_DATE                     ,
OWNER                                ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ROUTE_TASK_USER_COMPANY               ,
CMTS                                    ,
ACTUAL_COMPLETION_DT                         ,
APPROVERS_RESPONSIBILITY                    ,
ROUTE_ACTION                               ,
ALLOW_DELEGATION                    ,
ROUTE_TASK_USER                        ,
ROUTE_SEQUENCE                         ,
APPROVAL_STATUS                       ,
REVIEW_CMTS_NEEDED               ,
PARALLEL_NODE_PROCESSION_RULE    ,
SCHEDULED_COMPLETION_DT                  ,
TITLE1                                   ,
ROUTE_NODE_ID                            ,
ROUTE_INSTRUCTIONS                 ,
TMPLT_TASK                    ,
TASK_REQUIREMENT                     ,
ROUTE_BRANCH                              ,
DUE_DT_OFFSET                              ,
REVIEW_TASK                                   ,
DT_OFFSET_FROM                          ,
REVIEWERS_CMTS                          ,
ASSIGNEE_SET_DUE_DT               ,
DW_LOAD_DATE                             ,
DW_CREATED_BY                            ,
DW_UPDATED_DATE                     ,
DW_UPDATED_BY                           
)
SELECT  
RELATION_ID                     ,
FROM_ID                            ,
FROM_TYPE                       ,
FROM_NAME                                    ,
FROM_REVISION                             ,
FROM_VAULT                                   ,
TO_ID                                   ,
TO_TYPE                              ,
TO_NAME                           ,
TO_REVISION                   ,
TO_VAULT                          ,
FROZEN_IND                    ,
CREATED_BY                      ,
CREATION_DATE                              ,
LAST_UPDATED_BY                        ,
LAST_UPDATE_DATE                      ,
SOURCE_MODIFIED_DATE                          ,
SOURCE_ORIGINATED_DATE                     ,
OWNER                                ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ROUTE_TASK_USER_COMPANY               ,
CMTS                                    ,
ACTUAL_COMPLETION_DT                         ,
APPROVERS_RESPONSIBILITY                    ,
ROUTE_ACTION                               ,
ALLOW_DELEGATION                    ,
ROUTE_TASK_USER                        ,
ROUTE_SEQUENCE                         ,
APPROVAL_STATUS                       ,
REVIEW_CMTS_NEEDED               ,
PARALLEL_NODE_PROCESSION_RULE    ,
SCHEDULED_COMPLETION_DT                  ,
TITLE1                                   ,
ROUTE_NODE_ID                            ,
ROUTE_INSTRUCTIONS                 ,
TMPLT_TASK                    ,
TASK_REQUIREMENT                     ,
ROUTE_BRANCH                              ,
DUE_DT_OFFSET                              ,
REVIEW_TASK                                   ,
DT_OFFSET_FROM                          ,
REVIEWERS_CMTS                          ,
ASSIGNEE_SET_DUE_DT               ,
CURRENT_DATE,                
'CDR'   ,              
CURRENT_DATE  ,               
'CDR'                
                  
  
             
            

FROM VT_CDR_ODS_R_ROUTE_NODE; 


-- Table: CDR_ODS_R_ROUTE_NODE : End
