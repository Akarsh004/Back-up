#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_EP6_Shell_GENERIC_SESS_WFLW_DTLS.sh
# Creation Date:31/10/2012
# Last Modified: 31/10/12
# Purpose:Collection of session details from stage session of turbine for GVL.
# Created By: Rajasekhar Pola
# 
# This Script:
# 1) This script will move all the source files to archive
#
# 
# ----------------------------------------------------------------------------	

##################### VARIABLE PATHS DECLARATIONS STARTS##################
server_path=/data/informatica/ETCOE/EEDW01
tempdir=$server_path//TempDir
srcpath=$server_path/SrcFiles/INFA/BELFORT/
arcpath=$srcpath/Archive

trbn_path=$srcpath/TRBN
untrtr_path=$srcpath/UNTRTR
trbnrtr_path=$srcpath/TRBNRTR
bkt_path=$srcpath/BKT
set_nzle_path=$srcpath/SET_NZZLE
set_shrd_path=$srcpath/SET_SHRD
nzzle_path=$srcpath/NOZZLE
shrd_path=$srcpath/SHROUD
tp_path=$srcpath/TP
liner_path=$srcpath/LINER
fn_path=$srcpath/FN
caps_path=$srcpath/CAPS
################### VARIABLE PATHS DECLARATIONS END ##################


# CHANGE TO THE TRBN FOLDER 
cd $trbn_path/
mv *.* $arcpath

# CHANGE TO UNIT ROTOR FOLDER
cd $untrtr_path/
mv *.* $arcpath

# CHANGE TO TURBINE ROTOR FOLDER
cd $trbnrtr_path
mv *.* $arcpath

# CHANGE TO BUCKET FOLDER
cd $bkt_path
mv *.* $arcpath

# CHANGE SET NOZZLE FOLDER
cd $set_nzle_path
mv *.* $arcpath

# CHANGE SET SHROUD DIRECTORY 
cd $set_shrd_path
mv *.* $arcpath

# CHANGE TO NOZZLE FOLDER
cd $nzzle_path
mv *.* $arcpath

# CHANGE TO SHROUD FOLDER
cd $shrd_path
mv *.* $arcpath

# CHANGE TO THE TP FOLDER
cd $tp_path
mv *.* $arcpath

# CHANGE TO LINER FOLDER
cd $liner_path
mv *.* $arcpath

# CHANGE TO FN FOLDER
cd $fn_path
mv *.* $arcpath

# CHANGE TO CAPS FOLDER
cd $caps_path
mv *.* $arcpath

# change to archive path
cd $$arcpath

## ftp the files to the archive server
ftp -i -n gpsdba58.corporate.ge.com << EOF
user ftppubd chalupa99
cd /EP6/Archive/
mput *.dat
mput *.dar
mput *.arb
quit
EOF

