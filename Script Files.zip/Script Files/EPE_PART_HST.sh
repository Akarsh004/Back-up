. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
fastload<<eof

dateform ANSIDATE;

errlimit 1000000;
tenacity 4;        
sessions 1;
sleep 6;

RUN '/apps/informatica/product/pc/bin/td_geedw_plp.mlbt';

DROP TABLE ${Stg_database}.ET_CDR_ESPL_ITEM_EPE_HST  ; 
DROP TABLE ${Stg_database}.UV_CDR_ESPL_ITEM_EPE_HST   ; 
DROP TABLE ${Stg_database}.CDR_ESPL_ITEM_DETAILS_EPE_HST  ;
CREATE MULTISET TABLE ${Stg_database}.CDR_ESPL_ITEM_DETAILS_EPE_HST ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      PART_CLASS VARCHAR(19) CHARACTER SET LATIN CASESPECIFIC TITLE 'PART_CLASS',
      STATUS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'STATUS',
      DRAWING_NUMBER VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DRAWING_NUMBER' NOT NULL,
      DESCRIPTION VARCHAR(150) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DESCRIPTION',
      SUPERSEDED VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'SUPERSEDED',
      REVISION VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'REVISION',
      EFFECTIVE_DATE VARCHAR(20) CHARACTER SET LATIN CASESPECIFIC TITLE 'EFFECTIVE_DATE',
      HIST_FLG VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'HIST_FLG',
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_LOAD_DATE' NOT NULL,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_CREATED_BY' NOT NULL,
      DW_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_UPDATE_DATE' NOT NULL,
      DW_UPDATE_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_UPDATE_BY' NOT NULL)
PRIMARY INDEX XIE1ESPL_ITEM_DETAILS_EPE ( DRAWING_NUMBER );
SET RECORD VARTEXT "|";
RECORD 2;

define

 PART_CLASS                  (VARCHAR(19)),
 STATUS                      (VARCHAR(100)),
 DRAWING_NUMBER              (VARCHAR(30)),
 DESCRIPTION                 (VARCHAR(150)),
 SUPERSEDED                  (VARCHAR(30)),
 REVISION                    (VARCHAR(15)),
 EFFECTIVE_DATE              (VARCHAR(20))


 file=/data/informatica/ETCOE/EEDW01/SrcFiles/EPE_PART_frozen.lst;

show;

begin loading ${Stg_database}.CDR_ESPL_ITEM_DETAILS_EPE_HST  errorfiles ${Stg_database}.ET_CDR_ESPL_ITEM_EPE_HST , ${Stg_database}.UV_CDR_ESPL_ITEM_EPE_HST 
checkpoint 0 ;

INSERT INTO ${Stg_database}.CDR_ESPL_ITEM_DETAILS_EPE_HST  ( 
 PART_CLASS                       ,
 STATUS                           ,
 DRAWING_NUMBER                   ,
 DESCRIPTION                      ,
 SUPERSEDED                       ,
 REVISION                         ,
 EFFECTIVE_DATE                   ,
DW_LOAD_DATE                            , 
DW_CREATED_BY                           , 
DW_UPDATE_DATE                          , 
DW_UPDATE_BY                            
) VALUES ( 
 :PART_CLASS                       ,
 :STATUS                           ,
 :DRAWING_NUMBER                   ,
 :DESCRIPTION                      ,
 :SUPERSEDED                       ,
 :REVISION                         ,
 :EFFECTIVE_DATE                   , 
date                           , 
'CDR'                          , 
date                           , 
'CDR'                          
) ; 


end loading;

logoff;
eof
