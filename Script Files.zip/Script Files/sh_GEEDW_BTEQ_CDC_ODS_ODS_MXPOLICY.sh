sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_CDC_ODS_ODS_MXPOLICY1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/LoggingScripts/sh_GEEDW_BTEQ_CDC_ODS_ODS_MXPOLICY1_LOG.txt 2>&1
