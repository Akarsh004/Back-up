# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DEPART_TRANSITION.sh 
# Creation Date: 10/28/2011 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_DEPART_TRANSITION : Start	

---- DROP TABLE VT_CDR_PLP_DEPART_TRANSITION;	

CREATE VOLATILE TABLE VT_CDR_PLP_DEPART_TRANSITION,NO LOG (
      DEPART_FORM_SEQ_ID INTEGER ,
      NPI_DEPEND VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NPI_DATE DATE FORMAT 'MM/DD/YYYY' ,
      CSTI_MEMBER INTEGER ,
      TRANSITION_TYPE INTEGER ,
      APPROVER_ID INTEGER ,
      APPROVAL_FLAG INTEGER ,
      APPROVAL_DATE DATE FORMAT 'MM/DD/YYYY' ,
      CONTRACT_DATE DATE FORMAT 'MM/DD/YYYY',
      NPI_NAME_ENPP VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PORTFOLIO_LEADER INTEGER ,
      CPM INTEGER ,
      OPERATIONS_MANAGER INTEGER ,
      CREATION_DATE DATE FORMAT 'MM/DD/YYYY',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'MM/DD/YYYY' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( DEPART_FORM_SEQ_ID ) ON COMMIT PRESERVE ROWS;

INSERT INTO VT_CDR_PLP_DEPART_TRANSITION
(
DEPART_FORM_SEQ_ID            
,NPI_DEPEND                    
,NPI_DATE                      
,CSTI_MEMBER                   
,TRANSITION_TYPE               
,APPROVER_ID                   
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,CONTRACT_DATE                 
,NPI_NAME_ENPP                 
,PORTFOLIO_LEADER              
,CPM                           
,OPERATIONS_MANAGER            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                                           
)
SELECT
DEPART_FORM_SEQ_ID            
,NPI_DEPEND                    
,NPI_DATE                      
,CSTI_MEMBER                   
,TRANSITION_TYPE               
,APPROVER_ID                   
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,CONTRACT_DATE                 
,NPI_NAME_ENPP                 
,PORTFOLIO_LEADER              
,CPM                           
,OPERATIONS_MANAGER            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY 
FROM GEEDW_PLP_S.CDR_PLP_DEPART_TRANSITION_S
MINUS
SELECT	
DEPART_FORM_SEQ_ID            
,NPI_DEPEND                    
,NPI_DATE                      
,CSTI_MEMBER                   
,TRANSITION_TYPE               
,APPROVER_ID                   
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,CONTRACT_DATE                 
,NPI_NAME_ENPP                 
,PORTFOLIO_LEADER              
,CPM                           
,OPERATIONS_MANAGER            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY          
FROM GEEDW_PLP_BULK_T.CDR_PLP_DEPART_TRANSITION;

-- Table: VT_CDR_PLP_DEPART_TRANSITION  : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_DEPART_TRANSITION_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_DEPART_TRANSITION_S
(	
DEPART_FORM_SEQ_ID            
,NPI_DEPEND                    
,NPI_DATE                      
,CSTI_MEMBER                   
,TRANSITION_TYPE               
,APPROVER_ID                   
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,CONTRACT_DATE                 
,NPI_NAME_ENPP                 
,PORTFOLIO_LEADER              
,CPM                           
,OPERATIONS_MANAGER            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY 
)	
SELECT 
DEPART_FORM_SEQ_ID            
,NPI_DEPEND                    
,NPI_DATE                      
,CSTI_MEMBER                   
,TRANSITION_TYPE               
,APPROVER_ID                   
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,CONTRACT_DATE                 
,NPI_NAME_ENPP                 
,PORTFOLIO_LEADER              
,CPM                           
,OPERATIONS_MANAGER            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE               
,'CDR' 
FROM VT_CDR_PLP_DEPART_TRANSITION;		

-- Table: CDR_PLP_DEPART_TRANSITION : End




