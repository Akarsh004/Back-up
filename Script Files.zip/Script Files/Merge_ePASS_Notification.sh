workflowname=wflw_GEEDW_EPASS_BULK
workflowname=`(echo $workflowname |tr '[:lower:]' '[:upper:]')`
DL=tanwir.shaikh@ge.com,akarsh.singh@ge.com,Chandana.Ray@ge.com
set heading off;
set feedback off;
DL=`echo "$DL"| tr -d '\040\'`
echo "$DL"
VAR_1=`cat /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_EPASS_MERGE_LOG.txt | grep -i "FAILURE"`
XYZ=$?
if [ $XYZ = 0 ]
then
echo "Error"
(echo -e "Hi, \n This is an auto generated email for Merge execution failure. \n\nPlease take necessary steps to rectify the error.
\n\n Regards, \n ePASS - ETL Team") | mailx -s "Merge Execution Failed!!" $DL 
else
(echo -e "Hi, \n This is an auto generated email for ETL Workflow Completion Notification. \n\n $workflowname completed successfully \n\n If you observe data quality issue on EEDW views, please raise INC#  using http://helpdesk.ge.com  route to team CI = EEDW
\n\n Regards, \n Informatica server \n\n ======================================================\n ePASS - ETL Team \n\n Email process issues to ETCOE EEDW Support  etcoe.eedw.support@ge.com ") | mailx -s "ePASS Data Sync Completed" $DL 
fi