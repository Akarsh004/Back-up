sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BAAN_MERGE1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BAAN_MERGE_LOG.txt 2>&1
