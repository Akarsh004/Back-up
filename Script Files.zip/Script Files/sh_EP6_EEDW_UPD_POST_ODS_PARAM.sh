#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_EP6_EEDW_UPD_POST_ODS_PARAM.sh
# Creation Date:15/10/12
# Last Modified: 15/10/12
# Purpose:Updating the Last_Load_Date in the Parameter File
# Created By: Subhashree
#
# ----------------------------------------------------------------------------

######################################################################
##################      LOCAL VARIABLES       ########################
######################################################################

SRCPATH=/data/informatica/ETCOE/EEDW01/Config/
SESSLOGPATH=/data/informatica/ETCOE/EEDW01/SessLogs/
Workflow_name=$1
Parameter_File_name=$1".txt"
Log_File=$SESSLOGPATH"Parameter_File_Update.log"
######################################################################
####################       Main Code         #########################
######################################################################

echo "INFO :" `date`  ":SCRIPT Parameter_File_Update PROCESSING STARTED"   >> $Log_File
################ CHECK FOR THE Config PATH##############
if [ -d $SRCPATH ]; then
        cd $SRCPATH
        if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$SRCPATH}" successful "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Path change" {$SRCPATH}" failed "  >> $Log_File
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$SRCPATH} " Not Found "  >> $Log_File
        exit 1
fi
################ CHECK FOR THE PAARMETER FILE############
if test -f $Parameter_File_name
        then
                echo "INFO :" `date`  ":Parameter File " $Parameter_File_name " Found"   >> $Log_File
        else
                echo "ERROR :" `date`  ":Parameter File " $Parameter_File_name " Not Found"   >> $Log_File
                exit 1
fi
############## CURRENT SYSTEM DATE AND TIME############
Current_Date=`date +'%Y/%m/%d %H:%M:%S'`
Current_Date="'"$Current_Date"'"
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Current Date  "$Current_Date" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Date function failed "  >> $Log_File
                    exit 1
         fi
################ FIND THE LINE CONTAING IN Load_Date IN THE PAARAMETER FILE #################
Load_Date=`grep LAST_LOAD_DATE $Parameter_File_name |head -1`
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date  "$Load_Date" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load date not found "  >> $Log_File
                    exit 1
         fi
################ FIND THE DATE VALUE FROM THE FILE ###################
Date_Value=`echo $Load_Date |awk -F= '{print $2}'`
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date  value "$Date_Value" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load Date Value not found "  >> $Log_File
                    exit 1
         fi
##########REPLACE THE DATE VALUE IN THE PARAMETER FILE WITH THE CURRENT SYSTEM DATE AND TIME AND STORE IN A TEMP FILE #######
###
sed "s@$Date_Value@$Current_Date@" $Parameter_File_name > tempfile
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date replaced "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load Date replace failed"  >> $Log_File
                    exit 1
         fi
##########RENAME THE TEMP FILE TO PARAMETER FILE NAME ############
mv tempfile $Parameter_File_name
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":File renamed "   >> $Log_File
         else
                    echo "ERROR:" `date` ":File renaming failed "  >> $Log_File
                    exit 1
         fi
######## CHANGE THE PERMISSION OF THE FILE ###########
chmod 777 $Parameter_File_name
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":File permission Changed "   >> $Log_File
         else
                    echo "ERROR:" `date` ":File permission can not be changed  "  >> $Log_File
                    exit 1
         fi

exit 0
