. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
fastload<<eof

dateform ANSIDATE;

errlimit 1000000;
tenacity 4;        
sessions 1;
sleep 6;

RUN '/apps/informatica/product/pc/bin/td_geedw_plp.mlbt';

DROP TABLE ${Stg_database}.ET_CDR_ESPL_EPE_GT_LIST_S  ; 
DROP TABLE ${Stg_database}.UV_CDR_ESPL_EPE_GT_LIST_S   ; 
DROP TABLE ${Stg_database}.CDR_ESPL_EPE_GT_LIST_S  ;
CREATE multiSET TABLE ${Stg_database}.CDR_ESPL_EPE_GT_LIST_S1 ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      PARENT_CLASS VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'PARENT_CLASS',
      PARENT_DRAWING_NO VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'PARENT_DRAWING_NO',
      UNIT_NO VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'UNIT_NO',
      REVISION VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'REVISION',
      STATUS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'STATUS',
      HIST_FLG VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'HIST_FLG',
      DW_UPDATE_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_UPDATE_BY' NOT NULL,
      DW_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_UPDATE_DATE' NOT NULL,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_CREATED_BY' NOT NULL,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_LOAD_DATE' NOT NULL)
PRIMARY INDEX XIE1ESPL_EPE_GT_LIST ( PARENT_DRAWING_NO ,UNIT_NO );
SET RECORD VARTEXT "|";
RECORD 2;

define

 PARENT_CLASS                  (VARCHAR(19)),
 STATUS                        (VARCHAR(100)),
 PARENT_DRAWING_NO             (VARCHAR(30)),
 REVISION                      (VARCHAR(10)),
 UNIT_NO                       (VARCHAR(30))


 file=/data/informatica/ETCOE/EEDW01/SrcFiles/GT.lst;

show;

begin loading ${Stg_database}.CDR_ESPL_EPE_GT_LIST_S1  errorfiles ${Stg_database}.ET_CDR_ESPL_EPE_GT_LIST_S , ${Stg_database}.UV_CDR_ESPL_EPE_GT_LIST_S 
checkpoint 0 ;

INSERT INTO ${Stg_database}.CDR_ESPL_EPE_GT_LIST_S1  ( 
PARENT_CLASS                            ,
PARENT_DRAWING_NO                       ,
UNIT_NO                                ,
REVISION                             ,
STATUS                       ,
DW_LOAD_DATE                            , 
DW_CREATED_BY                           , 
DW_UPDATE_DATE                          , 
DW_UPDATE_BY                            
) VALUES ( 
:PARENT_CLASS                             , 
:PARENT_DRAWING_NO                            , 
:UNIT_NO                            , 
:REVISION                          , 
:STATUS                             , 
date                           , 
'CDR'                          , 
date                           , 
'CDR'                          
) ; 


end loading;

logoff;
eof
