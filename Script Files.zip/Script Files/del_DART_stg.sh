/* This is used for deleting records in stage tables for DART */
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq  << eof 
/*.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;*/
/*.RUN File = ${SrcDir}/td_plp.mlbt*/

delete from GEEDW_PLP_S.CDR_DART_DOCMASTER;

.logoff            
.QUIT
eof