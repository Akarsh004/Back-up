#!/bin/ksh 

# Path of ftp executable 
ftp="/ftp.corporate.ge.com/cdr/" 

# Give port or mention server name 
IP="3.184.76.31" 

#User ID to login into remote server 
user="cdr_twd" 

#Password to login in remote server 
pass="cDgy_rtwP" 

#Mention the path where the file to FTP is lying in the current server 
ifile="/data/informatica/ETCOE/EEDW01/SrcFiles/BUYER_DATA.TXT" 

#Mention the path where the FILE need to FTPied in the remote server 
ofile="cdr/BUYER_DATA.TXT" 

#Mention type of data transfer "asc" or "bin" 
type="asc" 
# this will take the name of your file 
myname=`basename $0` 

#selects the mode 
verbose="verbose" 

#date of FTP - Current date 
dd=`date +%d` 

exit 0 
