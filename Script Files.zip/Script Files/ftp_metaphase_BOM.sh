/* This is used for connecting to server and fetching files using FTP */
#bin bash
HOST='gpsdba58.corporate.ge.com'
USER='ftppubd'
PASSWD='chalupa99'
DT=`date +%m%y`
ftp -v -n <<EOF
open $HOST
user $USER $PASSWD
cd /dba58/d036/infa6qa/powertst/SrcFiles/STFNT01/INFA
echo $DT
lcd /data/informatica/ETCOE/EEDW01/SrcFiles
get EPE_BOM_frozen.lst
quit
chmod 777
# mv /data/informatica/ETCOE/EEDW01/SrcFiles/EPE_BOM_frozen.lst  /data/informatica/ETCOE/EEDW01/SrcFiles/EPE_BOM_frozen_new.lst
EOF