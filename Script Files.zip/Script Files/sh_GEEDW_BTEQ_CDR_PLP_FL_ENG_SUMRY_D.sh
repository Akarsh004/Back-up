# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_FL_ENGINE_SUMMARY_D.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_FL_ENG_SUMRY_D : Start	

---- DROP TABLE VT_CDR_PLP_FL_ENG_SUMRY_D;	

CREATE VOLATILE TABLE VT_CDR_PLP_FL_ENG_SUMRY_D ,NO LOG (
      FLCASE_ENG_SMRY1_SEQ_ID INTEGER ,
      EXPOSURE_TYPE CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ENGINE_SERIAL_NUM VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
      ENGINE_FRAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      ENGINE_TECHNOLOGY VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      SITE_SEQ_ID INTEGER,
      NEXT_OUTAGE_TYPE VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      NEXT_OUTAGE_DATE DATE FORMAT 'YY/MM/DD',
      FAC_EXPOSURE_TYPE VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      ENGINE_DUTY_CLASS VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      CASE_TYPE VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PART_TYPE_CNT INTEGER ,
      END_COVER VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      FUEL_NOZZLE VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      LIQUID_CART_RIDGES VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      LINER_CAP VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      LINER_RANK VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      TRANSITION_PIECE VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      STAGE_1_NOZZLE VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_1_SHROUD VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_1_BUCKET VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_2_NOZZLE VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_2_SHROUD VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_2_BUCKET VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_3_NOZZLE VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_3_SHROUD VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STAGE_3_BUCKET VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      ROTOR_RANK VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATED_DATE DATE FORMAT 'YY/MM/DD',
      NEXT_OUTAGE_SOURCE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
 PRIMARY INDEX(FLCASE_ENG_SMRY1_SEQ_ID);


INSERT INTO VT_CDR_PLP_FL_ENG_SUMRY_D
(
FLCASE_ENG_SMRY1_SEQ_ID,       
EXPOSURE_TYPE,                 
ENGINE_SERIAL_NUM,             
ENGINE_FRAME,                  
ENGINE_TECHNOLOGY,             
SITE_SEQ_ID,                   
NEXT_OUTAGE_TYPE,              
NEXT_OUTAGE_DATE,              
FAC_EXPOSURE_TYPE ,            
ENGINE_DUTY_CLASS,             
CASE_TYPE,                     
PART_TYPE_CNT,                 
END_COVER,                     
FUEL_NOZZLE,                   
LIQUID_CART_RIDGES,            
LINER_CAP,                     
LINER_RANK,                    
TRANSITION_PIECE,              
STAGE_1_NOZZLE,                
STAGE_1_SHROUD ,               
STAGE_1_BUCKET,                
STAGE_2_NOZZLE,                
STAGE_2_SHROUD,                
STAGE_2_BUCKET,                
STAGE_3_NOZZLE,                
STAGE_3_SHROUD,                
STAGE_3_BUCKET,                
ROTOR_RANK,                    
CREATED_DATE,                  
NEXT_OUTAGE_SOURCE,                                                                      
CREATION_DATE,
CREATED_BY,
LAST_UPDATED_DATE,
LAST_UPDATED_BY,
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
FLCASE_ENG_SMRY1_SEQ_ID,       
EXPOSURE_TYPE,                 
ENGINE_SERIAL_NUM,             
ENGINE_FRAME,                  
ENGINE_TECHNOLOGY,             
SITE_SEQ_ID,                   
NEXT_OUTAGE_TYPE,              
NEXT_OUTAGE_DATE,              
FAC_EXPOSURE_TYPE ,            
ENGINE_DUTY_CLASS,             
CASE_TYPE,                     
PART_TYPE_CNT,                 
END_COVER,                     
FUEL_NOZZLE,                   
LIQUID_CART_RIDGES,            
LINER_CAP,                     
LINER_RANK,                    
TRANSITION_PIECE,              
STAGE_1_NOZZLE,                
STAGE_1_SHROUD ,               
STAGE_1_BUCKET,                
STAGE_2_NOZZLE,                
STAGE_2_SHROUD,                
STAGE_2_BUCKET,                
STAGE_3_NOZZLE,                
STAGE_3_SHROUD,                
STAGE_3_BUCKET,                
ROTOR_RANK,                    
CREATED_DATE,                  
NEXT_OUTAGE_SOURCE,                                                            
CREATION_DATE,
CREATED_BY,
LAST_UPDATED_DATE,
LAST_UPDATED_BY,
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_FL_ENG_SUMRY_D_S
MINUS
SELECT	
FLCASE_ENG_SMRY1_SEQ_ID,       
EXPOSURE_TYPE,                 
ENGINE_SERIAL_NUM,             
ENGINE_FRAME,                  
ENGINE_TECHNOLOGY,             
SITE_SEQ_ID,                   
NEXT_OUTAGE_TYPE,              
NEXT_OUTAGE_DATE,              
FAC_EXPOSURE_TYPE ,            
ENGINE_DUTY_CLASS,             
CASE_TYPE,                     
PART_TYPE_CNT,                 
END_COVER,                     
FUEL_NOZZLE,                   
LIQUID_CART_RIDGES,            
LINER_CAP,                     
LINER_RANK,                    
TRANSITION_PIECE,              
STAGE_1_NOZZLE,                
STAGE_1_SHROUD ,               
STAGE_1_BUCKET,                
STAGE_2_NOZZLE,                
STAGE_2_SHROUD,                
STAGE_2_BUCKET,                
STAGE_3_NOZZLE,                
STAGE_3_SHROUD,                
STAGE_3_BUCKET,                
ROTOR_RANK,                    
CREATED_DATE,                  
NEXT_OUTAGE_SOURCE,                                                            
CREATION_DATE,
CREATED_BY,
LAST_UPDATED_DATE,
LAST_UPDATED_BY,
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_FL_ENG_SUMRY_D;

-- Table: VT_CDR_PLP_FL_ENG_SUMRY_D : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_FL_ENG_SUMRY_D_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_FL_ENG_SUMRY_D_S
(	
FLCASE_ENG_SMRY1_SEQ_ID,       
EXPOSURE_TYPE,                 
ENGINE_SERIAL_NUM,             
ENGINE_FRAME,                  
ENGINE_TECHNOLOGY,             
SITE_SEQ_ID,                   
NEXT_OUTAGE_TYPE,              
NEXT_OUTAGE_DATE,              
FAC_EXPOSURE_TYPE ,            
ENGINE_DUTY_CLASS,             
CASE_TYPE,                     
PART_TYPE_CNT,                 
END_COVER,                     
FUEL_NOZZLE,                   
LIQUID_CART_RIDGES,            
LINER_CAP,                     
LINER_RANK,                    
TRANSITION_PIECE,              
STAGE_1_NOZZLE,                
STAGE_1_SHROUD ,               
STAGE_1_BUCKET,                
STAGE_2_NOZZLE,                
STAGE_2_SHROUD,                
STAGE_2_BUCKET,                
STAGE_3_NOZZLE,                
STAGE_3_SHROUD,                
STAGE_3_BUCKET,                
ROTOR_RANK,                    
CREATED_DATE,                  
NEXT_OUTAGE_SOURCE,                                                            
CREATION_DATE,
CREATED_BY,
LAST_UPDATED_DATE,
LAST_UPDATED_BY,
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
FLCASE_ENG_SMRY1_SEQ_ID,       
EXPOSURE_TYPE,                 
ENGINE_SERIAL_NUM,             
ENGINE_FRAME,                  
ENGINE_TECHNOLOGY,             
SITE_SEQ_ID,                   
NEXT_OUTAGE_TYPE,              
NEXT_OUTAGE_DATE,              
FAC_EXPOSURE_TYPE ,            
ENGINE_DUTY_CLASS,             
CASE_TYPE,                     
PART_TYPE_CNT,                 
END_COVER,                     
FUEL_NOZZLE,                   
LIQUID_CART_RIDGES,            
LINER_CAP,                     
LINER_RANK,                    
TRANSITION_PIECE,              
STAGE_1_NOZZLE,                
STAGE_1_SHROUD ,               
STAGE_1_BUCKET,                
STAGE_2_NOZZLE,                
STAGE_2_SHROUD,                
STAGE_2_BUCKET,                
STAGE_3_NOZZLE,                
STAGE_3_SHROUD,                
STAGE_3_BUCKET,                
ROTOR_RANK,                    
CREATED_DATE,                  
NEXT_OUTAGE_SOURCE,                                                            
CREATION_DATE,
CREATED_BY,
LAST_UPDATED_DATE,
LAST_UPDATED_BY,
CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_FL_ENG_SUMRY_D;	

-- Table: CDR_PLP_FL_ENG_SUMRY_D : End




