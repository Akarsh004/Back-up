# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_ORG_HIERARCHY.sh 
# Creation Date: 08/27/10 
# Last Modified: 08/27/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: RAGINI
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};


INSERT INTO GEEDW_PLP_S.CDR_GIB_ORG_HIERARCHY
(	
PARENT_ORGANIZATION_CODE,      
CHILD_ORGANIZATION_CODE,       
PARENT_ORGANIZATION_TYPE,      
CHILD_ORGANIZATION_TYPE,       
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
PARENT_ORGANIZATION_CODE,      
CHILD_ORGANIZATION_CODE,       
PARENT_ORGANIZATION_TYPE,      
CHILD_ORGANIZATION_TYPE,       
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY
FROM GEEDW_PLP_BULK_T.CDR_GIB_ORG_HIERARCHY;	


-- Table: CDR_GIB_ORG_HIERARCHY : End




