# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_EMPOFFICE.sh 
# Creation Date: 08/27/10 
# Last Modified: 08/27/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};


INSERT INTO GEEDW_PLP_S.CDR_GIB_EMPOFFICE 
(	
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE,                 
DW_LOAD_DATE,                  
DW_CREATED_BY,                
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE,                 
DW_LOAD_DATE,                  
DW_CREATED_BY,                
DW_UPDATED_DATE,               
DW_UPDATED_BY
FROM GEEDW_PLP_BULK_T.CDR_GIB_EMPOFFICE;	


-- Table: CDR_GIB_EMPOFFICE : End




