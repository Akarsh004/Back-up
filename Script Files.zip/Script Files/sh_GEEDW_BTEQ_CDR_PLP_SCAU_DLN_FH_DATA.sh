# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_DLN_FH_DATA.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Deepika
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_DLN_FH_DATA : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_DLN_FH_DATA;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_DLN_FH_DATA ,NO LOG (


      DLN_FH_DATA_SEQ_ID INTEGER ,
      DLN_FH_AS_OF_DATE DATE FORMAT 'YY/MM/DD' ,
      NON_FIRED_9FA_NOZZLES DECIMAL(18,2) ,
      FIRED_9FA_NOZZLES DECIMAL(18,2) ,
      NON_FIRED_7FA_NOZZLES DECIMAL(18,2),
      FIRED_7FA_NOZZLES DECIMAL(18,2) ,
      DLN_6FA_UNITS DECIMAL(18,2) ,
      DLN_6FA_ALL_UNITS DECIMAL(18,2),
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX  ( DLN_FH_DATA_SEQ_ID )ON COMMIT PRESERVE ROWS;



INSERT INTO VT_CDR_PLP_SCAUTO_DLN_FH_DATA
(

DLN_FH_DATA_SEQ_ID,            
DLN_FH_AS_OF_DATE,             
NON_FIRED_9FA_NOZZLES ,        
FIRED_9FA_NOZZLES,             
NON_FIRED_7FA_NOZZLES,         
FIRED_7FA_NOZZLES,             
DLN_6FA_UNITS,                 
DLN_6FA_ALL_UNITS,             
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)

SELECT	

DLN_FH_DATA_SEQ_ID,            
DLN_FH_AS_OF_DATE,             
NON_FIRED_9FA_NOZZLES ,        
FIRED_9FA_NOZZLES,             
NON_FIRED_7FA_NOZZLES,         
FIRED_7FA_NOZZLES,             
DLN_6FA_UNITS,                 
DLN_6FA_ALL_UNITS,            
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY 

FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_DLN_FH_DATA_S

MINUS

SELECT	

DLN_FH_DATA_SEQ_ID,            
DLN_FH_AS_OF_DATE,             
NON_FIRED_9FA_NOZZLES ,        
FIRED_9FA_NOZZLES,             
NON_FIRED_7FA_NOZZLES,         
FIRED_7FA_NOZZLES,             
DLN_6FA_UNITS,                 
DLN_6FA_ALL_UNITS,          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_DLN_FH_DATA;

-- Table: VT_CDR_PLP_SCAUTO_DLN_FH_DATA : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_DLN_FH_DATA_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_DLN_FH_DATA_S
(	
DLN_FH_DATA_SEQ_ID,            
DLN_FH_AS_OF_DATE,             
NON_FIRED_9FA_NOZZLES ,        
FIRED_9FA_NOZZLES,             
NON_FIRED_7FA_NOZZLES,         
FIRED_7FA_NOZZLES,             
DLN_6FA_UNITS,                 
DLN_6FA_ALL_UNITS,          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 

DLN_FH_DATA_SEQ_ID,            
DLN_FH_AS_OF_DATE,             
NON_FIRED_9FA_NOZZLES ,        
FIRED_9FA_NOZZLES,             
NON_FIRED_7FA_NOZZLES,         
FIRED_7FA_NOZZLES,             
DLN_6FA_UNITS,                 
DLN_6FA_ALL_UNITS,           
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,  
CURRENT_DATE,       
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_DLN_FH_DATA ;	

-- Table: CDR_PLP_SCAUTO_DLN_FH_DATA : End




