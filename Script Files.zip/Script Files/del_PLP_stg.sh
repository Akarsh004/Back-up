/* This is used for deleting records in stage tables for PLP */
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq  << eof 

/*.RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;
delete from GEEDW_PLP_S.CDR_PLP_ACTION_LOOKUP;
delete from GEEDW_PLP_S.CDR_PLP_AREA_GROUP;
delete from GEEDW_PLP_S.CDR_PLP_COND_GROUP_DTL;
delete from GEEDW_PLP_S.CDR_PLP_EPIP_INSPECTION_JOB;
delete from GEEDW_PLP_S.CDR_PLP_OUTAGE_DETAILS;
delete from GEEDW_PLP_S.CDR_PLP_PART_DETAILS;
delete from GEEDW_PLP_S.CDR_PLP_PART_LIFE_AREA;
delete from GEEDW_PLP_S.CDR_PLP_PART_LIFE_DETAILS;
delete from GEEDW_PLP_S.CDR_PLP_PART_TYPE_LOOKUP;
delete from GEEDW_PLP_S.CDR_PLP_SHOP_LOOKUP;
delete from GEEDW_PLP_S.CDR_PLP_AREA_LOOKUP;
delete from GEEDW_PLP_S.CDR_PLP_GIB;
delete from GEEDW_PLP_S.CDR_PLP_PART_CONDITION_LKP;
.logoff            
.QUIT
eof