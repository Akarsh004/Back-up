# ---------------------------------------------------------------------------- 
# File: sh_GEEDW_BTEQ_CDR_PLP_CYCLE_TYPE.sh
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
 /* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_PLP_CYCLE_TYPE  : Start

 DROP TABLE VT_CDR_PLP_CYCLE_TYPE ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */
 CREATE VOLATILE TABLE VT_CDR_PLP_CYCLE_TYPE,NO LOG (
      CYCLE_SEQ_ID INTEGER  NOT NULL,
      CYCLE_TYPE VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CYCLE_DESC VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD'  NOT NULL,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD'  NOT NULL,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX  ( CYCLE_SEQ_ID );

---Table: CDR_PLP_CYCLE_TYPE : Processing : Populate GT table with CDC data 

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_CYCLE_TYPE
(
CYCLE_SEQ_ID                  ,
CYCLE_TYPE                    ,
CYCLE_DESC                    ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATE_DATE              ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
CYCLE_SEQ_ID                  ,
CYCLE_TYPE                    ,
CYCLE_DESC                    ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATE_DATE              ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_PLP_CYCLE_TYPE_S
MINUS
SELECT 
CYCLE_SEQ_ID                  ,
CYCLE_TYPE                    ,
CYCLE_DESC                    ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATE_DATE              ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_BULK_T.CDR_PLP_CYCLE_TYPE;


----Table: VT_CDR_GIB_CUSTOMER : Processing : Populate Stage table with CDC data only for mLDM processing  

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_CYCLE_TYPE_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_CYCLE_TYPE_S
(
CYCLE_SEQ_ID                  ,
CYCLE_TYPE                    ,
CYCLE_DESC                    ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATE_DATE              ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
CYCLE_SEQ_ID                  ,
CYCLE_TYPE                    ,
CYCLE_DESC                    ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATE_DATE              ,
LAST_UPDATED_BY               ,
CURRENT_DATE,                  
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_CYCLE_TYPE;


---Table: CDR_PLP_CYCLE_TYPE : End

