workflowname=wflw_GEEDW_TC5_BULK
workflowname=`(echo $workflowname |tr '[:lower:]' '[:upper:]')`
DL=ishan.sahoo@ge.com,prashant.chaubey@ge.com,sumanta.bhujabal@ge.com
set heading off;
set feedback off;
DL=`echo "$DL"| tr -d '\040\'`
echo "$DL"

(echo -e "Hi, \n This is an auto generated email for ETL Workflow Completion Notification. \n\n $workflowname completed successfully \n\n If you observe data quality issue on EEDW views, please raise INC#  using http://helpdesk.ge.com  route to team CI = EEDW
\n\n Regards, \n Informatica server \n\n ======================================================\n TC5 - ETL Team \n\n Email process issues to ETCOE EEDW Support  etcoe.eedw.support@ge.com ") | mailx -s "TC5 Data Sync Completed" $DL 