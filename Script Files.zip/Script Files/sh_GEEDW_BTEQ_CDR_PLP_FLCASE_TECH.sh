# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_FLCASE_TECHNOLOGY.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_FLCASE_TECH : Start	

---- DROP TABLE VT_CDR_PLP_FLCASE_TECH;	

CREATE VOLATILE TABLE VT_CDR_PLP_FLCASE_TECH,NO LOG (
      CASE_ID INTEGER,
      TECHNOLOGY VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
 PRIMARY INDEX(CASE_ID,TECHNOLOGY)ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_FLCASE_TECH
(
CASE_ID,                       
TECHNOLOGY ,                                                         
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                       
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
CASE_ID,                       
TECHNOLOGY ,                                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_FLCASE_TECH_S
MINUS
SELECT	
CASE_ID,                       
TECHNOLOGY ,                                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_FLCASE_TECH;

-- Table: VT_CDR_PLP_FLCASE_TECH : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_FLCASE_TECH_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_FLCASE_TECH_S
(	
CASE_ID,                       
TECHNOLOGY ,                                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
CASE_ID,                       
TECHNOLOGY ,                                    
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,   
CURRENT_DATE,               
'PLP',                         
CURRENT_DATE,
'PLP'
FROM VT_CDR_PLP_FLCASE_TECH;	

-- Table: CDR_PLP_FLCASE_TECH: End




