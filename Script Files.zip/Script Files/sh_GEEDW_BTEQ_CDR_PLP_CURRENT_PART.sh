# ---------------------------------------------------------------------------- 
# File: sh_GEEDW_BTEQ_CDR_PLP_CURRENT_PART.sh 
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
 /* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_CDR_PLP_CURRENT_PART  : Start

 DROP TABLE VT_CDR_PLP_CURRENT_PART ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */
 CREATE VOLATILE TABLE VT_CDR_PLP_CURRENT_PART,NO LOG (
      CURRENT_PARTS_SEQ_ID INTEGER  NOT NULL,
      UNIT_SERIAL_NUM VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      TECHNOLOGY_CODE VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_DRAWING_NUM VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PART_SERIAL_NUM VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PART_POSITION INTEGER ,
      PARENT_DRAWING_NUM VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PARENT_SERIAL_NUM VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DRAWING_DESCRIPTOR INTEGER ,
      BUCKET_WEIGHT INTEGER,
      DATE_UPDATED DATE FORMAT 'YYYY-MM-DD' ,
      UPDATED_BY VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DATA_SOURCE VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' NOT NULL,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD'  NOT NULL,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX  ( CURRENT_PARTS_SEQ_ID );

---Table: CDR_PLP_CURRENT_PART : Processing : Populate GT table with CDC data 

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_CURRENT_PART
(
CURRENT_PARTS_SEQ_ID          ,
UNIT_SERIAL_NUM               ,
TECHNOLOGY_CODE               ,
PART_DRAWING_NUM              ,
PART_SERIAL_NUM               ,
PART_POSITION                 ,
PARENT_DRAWING_NUM            ,
PARENT_SERIAL_NUM             ,
DRAWING_DESCRIPTOR            ,
BUCKET_WEIGHT                 ,
DATE_UPDATED                  ,
UPDATED_BY                    ,
DATA_SOURCE                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
CURRENT_PARTS_SEQ_ID          ,
UNIT_SERIAL_NUM               ,
TECHNOLOGY_CODE               ,
PART_DRAWING_NUM              ,
PART_SERIAL_NUM               ,
PART_POSITION                 ,
PARENT_DRAWING_NUM            ,
PARENT_SERIAL_NUM             ,
DRAWING_DESCRIPTOR            ,
BUCKET_WEIGHT                 ,
DATE_UPDATED                  ,
UPDATED_BY                    ,
DATA_SOURCE                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_PLP_CURRENT_PART_S
MINUS
SELECT 
CURRENT_PARTS_SEQ_ID          ,
UNIT_SERIAL_NUM               ,
TECHNOLOGY_CODE               ,
PART_DRAWING_NUM              ,
PART_SERIAL_NUM               ,
PART_POSITION                 ,
PARENT_DRAWING_NUM            ,
PARENT_SERIAL_NUM             ,
DRAWING_DESCRIPTOR            ,
BUCKET_WEIGHT                 ,
DATE_UPDATED                  ,
UPDATED_BY                    ,
DATA_SOURCE                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_BULK_T.CDR_PLP_CURRENT_PART;


----Table: VT_CDR_GIB_CUSTOMER : Processing : Populate Stage table with CDC data only for mLDM processing  

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_CURRENT_PART_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_CURRENT_PART_S
(
CURRENT_PARTS_SEQ_ID          ,
UNIT_SERIAL_NUM               ,
TECHNOLOGY_CODE               ,
PART_DRAWING_NUM              ,
PART_SERIAL_NUM               ,
PART_POSITION                 ,
PARENT_DRAWING_NUM            ,
PARENT_SERIAL_NUM             ,
DRAWING_DESCRIPTOR            ,
BUCKET_WEIGHT                 ,
DATE_UPDATED                  ,
UPDATED_BY                    ,
DATA_SOURCE                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
CURRENT_PARTS_SEQ_ID          ,
UNIT_SERIAL_NUM               ,
TECHNOLOGY_CODE               ,
PART_DRAWING_NUM              ,
PART_SERIAL_NUM               ,
PART_POSITION                 ,
PARENT_DRAWING_NUM            ,
PARENT_SERIAL_NUM             ,
DRAWING_DESCRIPTOR            ,
BUCKET_WEIGHT                 ,
DATE_UPDATED                  ,
UPDATED_BY                    ,
DATA_SOURCE                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
CURRENT_DATE,                  
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_CURRENT_PART;


---Table: CDR_PLP_CURRENT_PART : End

