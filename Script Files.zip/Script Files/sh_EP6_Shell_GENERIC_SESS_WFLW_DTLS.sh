#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_EP6_Shell_GENERIC_SESS_WFLW_DTLS.sh
# Creation Date:31/10/2012
# Last Modified: 31/10/12
# Purpose:Collection of session details from stage session of turbine for GVL.
# Created By: Rajasekhar Pola
# 
# This Script:
# 1) This script will collect the session run details and stoore in one file
# 2) This script takes 2paremeters as aruguments 
#
#  Arg 1: Log file name
#  
# ----------------------------------------------------------------------------	

#############   VARIABLE DECLARATIONS  ###############
sesslog_files=$1
server_path=/data/informatica/ETCOE/EEDW01
tempdir=/data/informatica/ETCOE/EEDW01/TempDir/
sesslog_files_list=$server_path/SrcFiles/SD/$sesslog_files
inf_sess_dtls=$server_path/SrcFiles/SD/EP6_SESS_LOG_RUN_DTLS.csv
inf_wflw_dtls=$server_path/SrcFiles/SD/EP6_WFLW_LOG_RUN_DTLS.csv
sess_start_date=$tempdir/sess_start_date2.txt
sess_end_date=$tempdir/sess_end_date2.txt
############# VARIABLE DECLARATIONS END ##############
cd $server_path/SrcFiles/SD/
rm -f EP6_SESS_LOG_RUN_DTLS.csv
cd $server_path/SessLogs/
pwd
touch $inf_sess_dtls
echo "$sesslog_files_list"
echo "$1"

for i in `cat $sesslog_files_list`
do
log_file=$i
cd $server_path/SessLogs/
pwd

ls -l $log_file

fl_avlblty=`ls $log_file|wc -l`
echo $fl_avlblty
if [ $fl_avlblty -ne 0 ] ; then
echo "$log_file"
############################## SESSLOG RUN DETAILS FUNCTION START #######################
workflow_name=`grep Workflow $log_file| head -1|awk -F " " '{print $4}'| cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ] ; then
exho "working"
echo $workflow_name
else 
echo "not working"
fi

workflow_name=`cat $log_file | grep Workflow: | head -1|awk -F " " '{print $4}'| cut -d"[" -f2 | cut -d"]" -f1`
echo $workflow_name
session_name=`cat $log_file | grep session | head -1 | awk -F " " '{print $5}' | cut -d"[" -f2 | cut -d"]" -f1`
echo $session_name

# SEARCH AND GET THE SESSION START MONTH
session_start_mon=`cat $log_file | grep "Initializing session" | head -1 | awk -F " " '{print $8}'`
echo $session_start_mon

session_start_Day=`cat $log_file | grep "Initializing session" | head -1 | awk -F " " '{print $9}'`
echo $session_start_Day

# SEARCH AND GET THE SESSION START YEAR
session_start_year=`cat $log_file | grep "Initializing session" | head -1 | awk -F " " '{print $11}' | cut -d"]" -f1`
echo $session_start_year

# SEARCH AND GET THE SESSION START TIME
session_start_time=`cat $log_file | grep "Initializing session" | head -1 | awk -F " " '{print $10}'`
echo $session_start_time

# SEARCH AND GET THE SESSION END MONTH
session_end_mon=`cat $log_file | grep "completed at" | head -1 | awk -F " " '{print $8}'`
echo $session_end_mon

session_end_Day=`cat $log_file | grep "completed at" | head -1 | awk -F " " '{print $9}'`
echo $session_end_Day

# SEARCH AND GET THE SESSION END YEAR
session_end_year=`cat $log_file | grep "completed at" | head -1 | awk -F " " '{print $11}' | cut -d"]" -f1`
echo $session_end_year

# SEARCH AND GET THE SESSION START TIME
session_end_time=`cat $log_file | grep "completed at" | head -1 | awk -F " " '{print $10}'`
echo $session_end_time

# FIND THE SESSION STATUS
status_sess=`cat $log_file |grep "Execution failed" |wc -l`

if [ $status_sess -ne 0 ]; then
stts=failed
else
stts=succeeded
fi
echo $stts


# COMBINED THE VALUES OF SESSION START DATE , MONTH ,YEAR AND TIME

date -d "`echo $session_start_mon $session_start_Day $session_start_year $session_start_time`" +'%d-%m-%Y %r' > $sess_start_date
corr_start_date=`cat $sess_start_date|head -1`
echo $corr_start_date

# COMBINED THE VALUES OF SESSION END DATE , MONTH ,YEAR AND TIME
date -d "`echo $session_end_mon $session_end_Day $session_end_year $session_end_time`" +'%d-%m-%Y %r' > $sess_end_date
corr_end_date=`cat $sess_end_date|head -1`
echo $corr_end_date

# CREATE THE FILE WITH LIST OF ALL THE VALUES IN THE TARGET FILE
echo $workflow_name","$session_name","$corr_start_date","$corr_end_date","$stts >> $inf_sess_dtls


echo $workflow_name","$session_name","$corr_start_date","$corr_end_date","$stts > $inf_wflw_dtls

else 
echo "$log_file"
fi

done
