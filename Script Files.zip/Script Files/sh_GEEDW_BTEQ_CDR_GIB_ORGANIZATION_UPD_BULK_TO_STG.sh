# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_ORGANIZATION.sh 
# Creation Date: 08/27/10 
# Last Modified: 08/27/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};


INSERT INTO GEEDW_PLP_S.CDR_GIB_ORGANIZATION 
(	
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY
FROM GEEDW_PLP_BULK_T.CDR_GIB_ORGANIZATION;	


-- Table: CDR_GIB_ORGANIZATION : End




