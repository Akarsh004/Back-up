# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_FH_FS_UNIT.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Deepika
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_FH_FS_UNITS : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_FH_FS_UNITS;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_FH_FS_UNITS ,NO LOG (

      UNIT_ID VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TURBINE_MODEL VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TURBINE_NUMBER VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FIRED_HOURS INTEGER ,
      FIRED_STARTS INTEGER ,
      EMERG_TRIPS INTEGER ,
      AS_OF_DATE DATE FORMAT 'YY/MM/DD' ,
      PROJ_FIRED_HOURS INTEGER ,
      PROJ_FIRED_STARTS INTEGER ,
      STANDARD_ERR DECIMAL(7,2),
      TRIPS_HOURS_FLAG INTEGER ,
      FLEET_PEAK_DUTY INTEGER ,
      FLEET_CYCLE_DUTY INTEGER ,
      FLEET_BASE_LOAD INTEGER ,
      FLEET_TOTAL INTEGER ,
      TRIP_RATE DECIMAL(7,2) ,
      EXP_FIRED_HOURS INTEGER ,
      EXP_FIRED_STS INTEGER ,
      EXP_TRIPS INTEGER ,
      EXP_DATE DATE FORMAT 'YY/MM/DD' ,
      LISTED INTEGER ,
      WITH_DATA INTEGER ,
      TURBINE_FRAME VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD' ,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  )
PRIMARY INDEX  ( TURBINE_NUMBER , AS_OF_DATE )ON COMMIT PRESERVE ROWS;





INSERT INTO VT_CDR_PLP_SCAUTO_FH_FS_UNITS
(

UNIT_ID,                       
TURBINE_MODEL,                 
TURBINE_NUMBER,                
FIRED_HOURS,                   
FIRED_STARTS,                  
EMERG_TRIPS,                   
AS_OF_DATE,                    
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
STANDARD_ERR,                  
TRIPS_HOURS_FLAG,              
FLEET_PEAK_DUTY,               
FLEET_CYCLE_DUTY,              
FLEET_BASE_LOAD,               
FLEET_TOTAL,                   
TRIP_RATE,                     
EXP_FIRED_HOURS,               
EXP_FIRED_STS,                 
EXP_TRIPS,                     
EXP_DATE,                      
LISTED,                        
WITH_DATA,                     
TURBINE_FRAME,                    
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)

SELECT	

UNIT_ID,                       
TURBINE_MODEL,                 
TURBINE_NUMBER,                
FIRED_HOURS,                   
FIRED_STARTS,                  
EMERG_TRIPS,                   
AS_OF_DATE,                    
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
STANDARD_ERR,                  
TRIPS_HOURS_FLAG,              
FLEET_PEAK_DUTY,               
FLEET_CYCLE_DUTY,              
FLEET_BASE_LOAD,               
FLEET_TOTAL,                   
TRIP_RATE,                     
EXP_FIRED_HOURS,               
EXP_FIRED_STS,                 
EXP_TRIPS,                     
EXP_DATE,                      
LISTED,                        
WITH_DATA,                     
TURBINE_FRAME,            
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY 

FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_FH_FS_UNIT_S

MINUS

SELECT	

UNIT_ID,                       
TURBINE_MODEL,                 
TURBINE_NUMBER,                
FIRED_HOURS,                   
FIRED_STARTS,                  
EMERG_TRIPS,                   
AS_OF_DATE,                    
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
STANDARD_ERR,                  
TRIPS_HOURS_FLAG,              
FLEET_PEAK_DUTY,               
FLEET_CYCLE_DUTY,              
FLEET_BASE_LOAD,               
FLEET_TOTAL,                   
TRIP_RATE,                     
EXP_FIRED_HOURS,               
EXP_FIRED_STS,                 
EXP_TRIPS,                     
EXP_DATE,                      
LISTED,                        
WITH_DATA,                     
TURBINE_FRAME,                 
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_FH_FS_UNIT;

-- Table: VT_CDR_PLP_SCAUTO_FH_FS_UNITS : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_FH_FS_UNIT_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_FH_FS_UNIT_S
(	
UNIT_ID,                       
TURBINE_MODEL,                 
TURBINE_NUMBER,                
FIRED_HOURS,                   
FIRED_STARTS,                  
EMERG_TRIPS,                   
AS_OF_DATE,                    
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
STANDARD_ERR,                  
TRIPS_HOURS_FLAG,              
FLEET_PEAK_DUTY,               
FLEET_CYCLE_DUTY,              
FLEET_BASE_LOAD,               
FLEET_TOTAL,                   
TRIP_RATE,                     
EXP_FIRED_HOURS,               
EXP_FIRED_STS,                 
EXP_TRIPS,                     
EXP_DATE,                      
LISTED,                        
WITH_DATA,                     
TURBINE_FRAME,                  
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 

UNIT_ID,                       
TURBINE_MODEL,                 
TURBINE_NUMBER,                
FIRED_HOURS,                   
FIRED_STARTS,                  
EMERG_TRIPS,                   
AS_OF_DATE,                    
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
STANDARD_ERR,                  
TRIPS_HOURS_FLAG,              
FLEET_PEAK_DUTY,               
FLEET_CYCLE_DUTY,              
FLEET_BASE_LOAD,               
FLEET_TOTAL,                   
TRIP_RATE,                     
EXP_FIRED_HOURS,               
EXP_FIRED_STS,                 
EXP_TRIPS,                     
EXP_DATE,                      
LISTED,                        
WITH_DATA,                     
TURBINE_FRAME,                  
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,
CURRENT_DATE,         
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_FH_FS_UNITS ;	

-- Table: CDR_PLP_SCAUTO_FH_FS_UNITS : End




