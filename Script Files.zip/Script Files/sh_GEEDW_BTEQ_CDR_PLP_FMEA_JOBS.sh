# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_FMEA_JOBS.sh 
# Creation Date: 07/17/11 
# Last Modified: 07/17/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_FMEA_JOBS  : Start	

---- DROP TABLE VT_CDR_PLP_FMEA_JOBS ;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_PLP_FMEA_JOBS,NO LOG (
      JOB_ID INTEGER ,
      USER_NAME VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FRAME INTEGER,
      SERIES VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      SYSTEM_TYPE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      SHOP VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FIELD_DATA_ENGNR VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      PLA_DB_ID INTEGER ,
      STATUS VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NOTIFY VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      SUBMIT_TIME DATE FORMAT 'YYYY-MM-DD',
      LAST_RUN_TIME DATE FORMAT 'YYYY-MM-DD' ,
      END_TIME DATE FORMAT 'YYYY-MM-DD',
      COMMENTS VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      JOB_OCCUR VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      JOB_DATE VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_RUN_STATUS VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DATA_FILE_ID INTEGER  ,
      JOB_TYPE INTEGER,
      EXP_TYPE VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      DEL_STATUS VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX  ( JOB_ID ) ON COMMIT PRESERVE ROWS;
-- Table: CDR_PLP_FMEA_JOBS : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_PLP_FMEA_JOBS
(
JOB_ID                        
,USER_NAME                     
,FRAME                         
,SERIES                        
,SYSTEM_TYPE                   
,SHOP                          
,FIELD_DATA_ENGNR              
,PLA_DB_ID                     
,STATUS                        
,NOTIFY                        
,SUBMIT_TIME                   
,LAST_RUN_TIME                 
,END_TIME                      
,COMMENTS                      
,JOB_OCCUR                     
,JOB_DATE                      
,LAST_RUN_STATUS               
,DATA_FILE_ID                  
,JOB_TYPE                      
,EXP_TYPE                      
,DEL_STATUS                    
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
 )
SELECT 
JOB_ID                        
,USER_NAME                     
,FRAME                         
,SERIES                        
,SYSTEM_TYPE                   
,SHOP                          
,FIELD_DATA_ENGNR              
,PLA_DB_ID                     
,STATUS                        
,NOTIFY                        
,SUBMIT_TIME                   
,LAST_RUN_TIME                 
,END_TIME                      
,COMMENTS                      
,JOB_OCCUR                     
,JOB_DATE                      
,LAST_RUN_STATUS               
,DATA_FILE_ID                  
,JOB_TYPE                      
,EXP_TYPE                      
,DEL_STATUS                    
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY           
FROM GEEDW_PLP_S.CDR_PLP_FMEA_JOBS_S
MINUS
SELECT 
JOB_ID                        
,USER_NAME                     
,FRAME                         
,SERIES                        
,SYSTEM_TYPE                   
,SHOP                          
,FIELD_DATA_ENGNR              
,PLA_DB_ID                     
,STATUS                        
,NOTIFY                        
,SUBMIT_TIME                   
,LAST_RUN_TIME                 
,END_TIME                      
,COMMENTS                      
,JOB_OCCUR                     
,JOB_DATE                      
,LAST_RUN_STATUS               
,DATA_FILE_ID                  
,JOB_TYPE                      
,EXP_TYPE                      
,DEL_STATUS                    
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY           
FROM GEEDW_PLP_BULK_T.CDR_PLP_FMEA_JOBS;	




-- Table: VT_CDR_PLP_FMEA_JOBS : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_FMEA_JOBS_S;	

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_PLP_FMEA_JOBS_S
(	
JOB_ID                        
,USER_NAME                     
,FRAME                         
,SERIES                        
,SYSTEM_TYPE                   
,SHOP                          
,FIELD_DATA_ENGNR              
,PLA_DB_ID                     
,STATUS                        
,NOTIFY                        
,SUBMIT_TIME                   
,LAST_RUN_TIME                 
,END_TIME                      
,COMMENTS                      
,JOB_OCCUR                     
,JOB_DATE                      
,LAST_RUN_STATUS               
,DATA_FILE_ID                  
,JOB_TYPE                      
,EXP_TYPE                      
,DEL_STATUS                    
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY           
)	
SELECT 
JOB_ID                        
,USER_NAME                     
,FRAME                         
,SERIES                        
,SYSTEM_TYPE                   
,SHOP                          
,FIELD_DATA_ENGNR              
,PLA_DB_ID                     
,STATUS                        
,NOTIFY                        
,SUBMIT_TIME                   
,LAST_RUN_TIME                 
,END_TIME                      
,COMMENTS                      
,JOB_OCCUR                     
,JOB_DATE                      
,LAST_RUN_STATUS               
,DATA_FILE_ID                  
,JOB_TYPE                      
,EXP_TYPE                      
,DEL_STATUS                    
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,CURRENT_DATE                
,'CDR'              
,CURRENT_DATE               
,'CDR'        
              
FROM VT_CDR_PLP_FMEA_JOBS;	


-- Table: CDR_PLP_FMEA_JOBS : End

