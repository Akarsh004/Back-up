# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_QMI_OPS_CENTR_RPT_C.sh 
# Creation Date: 07/20/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_QMI_OPS_CENTR_RPT_C : Start	

---- DROP CDR_PLP_QMI_OPS_CENTR_RPT_C;	

CREATE VOLATILE TABLE VT_CDR_PLP_QMI_OPS_CENTR_RPT_C,NO LOG (
      QMI_OPS_CENTER_SEQ_ID INTEGER,
      DEPART_FORM_SEQ_ID INTEGER,
      CASE_ID VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      SITE_ID VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      OWNER VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      PRIORITY VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      EQUIP_ID VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      SITE_NAME VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      STATUS VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      TITLE_COL VARCHAR(55) CHARACTER SET LATIN NOT CASESPECIFIC,
      NOTES VARCHAR(2000) CHARACTER SET LATIN NOT CASESPECIFIC,
      REPORT_TYPE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CUSTOMER VARCHAR(150) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( QMI_OPS_CENTER_SEQ_ID ) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_QMI_OPS_CENTR_RPT_C
(
QMI_OPS_CENTER_SEQ_ID,         
DEPART_FORM_SEQ_ID,            
CASE_ID,                       
SITE_ID,                       
OWNER,                         
PRIORITY,                      
EQUIP_ID,                      
SITE_NAME,                     
STATUS,                        
TITLE_COL,                        
NOTES,                        
REPORT_TYPE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
CUSTOMER,                      
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                 )
SELECT	
QMI_OPS_CENTER_SEQ_ID,         
DEPART_FORM_SEQ_ID,            
CASE_ID,                       
SITE_ID,                       
OWNER,                         
PRIORITY,                      
EQUIP_ID,                      
SITE_NAME,                     
STATUS,                        
TITLE_COL,                        
NOTES,                        
REPORT_TYPE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
CUSTOMER,                      
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                        
FROM	 GEEDW_PLP_S.CDR_PLP_QMI_OP_CENTR_RPTC_S
MINUS
SELECT	
QMI_OPS_CENTER_SEQ_ID,         
DEPART_FORM_SEQ_ID,            
CASE_ID,                       
SITE_ID,                       
OWNER,                         
PRIORITY,                      
EQUIP_ID,                      
SITE_NAME,                     
STATUS,                        
TITLE_COL,                        
NOTES,                        
REPORT_TYPE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
CUSTOMER,                      
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                    
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_QMI_OPS_CENTR_RPT_C;

-- Table: VT_CDR_PLP_QMI_OPS_CENTR_RPT_C : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_QMI_OP_CENTR_RPTC_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_QMI_OP_CENTR_RPTC_S
(	
QMI_OPS_CENTER_SEQ_ID,         
DEPART_FORM_SEQ_ID,            
CASE_ID,                       
SITE_ID,                       
OWNER,                         
PRIORITY,                      
EQUIP_ID,                      
SITE_NAME,                     
STATUS,                        
TITLE_COL,                        
NOTES,                        
REPORT_TYPE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
CUSTOMER,                      
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                    
)	
SELECT 
QMI_OPS_CENTER_SEQ_ID,         
DEPART_FORM_SEQ_ID,            
CASE_ID,                       
SITE_ID,                       
OWNER,                         
PRIORITY,                      
EQUIP_ID,                      
SITE_NAME,                     
STATUS,                        
TITLE_COL,                        
NOTES,                        
REPORT_TYPE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
CUSTOMER,
CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_QMI_OPS_CENTR_RPT_C;	

-- Table: CDR_PLP_QMI_OPS_CENTR_RPT_C : End