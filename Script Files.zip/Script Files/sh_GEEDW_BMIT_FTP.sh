sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BMIT_FTP1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BMIT_FTP1_LOG.txt 2>&1
