// ---------------------------------------------------------------------------- 
//			
// File: sh_GEEDW_BTEQ_CDR_PEG_TCCE_APPROVER.sh 
// Creation Date: 04/12/10 
// Last Modified: 04/12/10
// Purpose:CDC Implementation on the Staging and Bulk databases
// Created By: Smruti/Tarkesh
//
// ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/*.RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;  

	
CREATE VOLATILE TABLE VT_LXSTATE_398850F1 ,NO LOG (
                      LXSTATE_ID VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
                      BUS_OBJ_OID INTEGER,
              	 MXSTATEREQ_OID INTEGER,
                      ACTUAL_DT_GMT TIMESTAMP(0),
                      START_DT_GMT TIMESTAMP(0),
                      END_DT_GMT TIMESTAMP(0),
                      CHECKSUMTEXT VARCHAR(40))
                PRIMARY INDEX ( LXSTATE_ID, CHECKSUMTEXT ) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_LXSTATE_398850F1 
(
LXSTATE_ID  
,BUS_OBJ_OID 
,MXSTATEREQ_OID  
,ACTUAL_DT_GMT  
,START_DT_GMT  
,END_DT_GMT  
,CHECKSUMTEXT 

)
SELECT
LXSTATE_ID  
,BUS_OBJ_OID 
,MXSTATEREQ_OID  
,ACTUAL_DT_GMT  
,START_DT_GMT  
,END_DT_GMT  
,CHECKSUMTEXT 

FROM GEEDW_PLP_S.CDR_ODS_LXSTATE_398850F1_S	 CDR_ODS_LXSTATE_398850F1_S
WHERE NOT EXISTS(SELECT 1 FROM  GEEDW_PLM_ODS_BULK_T.CDR_ODS_LXSTATE_398850F1 CDR_ODS_LXSTATE_398850F1
WHERE CDR_ODS_LXSTATE_398850F1_S.CHECKSUMTEXT=CDR_ODS_LXSTATE_398850F1.CHECKSUMTEXT
AND CDR_ODS_LXSTATE_398850F1_S.BUS_OBJ_OID=CDR_ODS_LXSTATE_398850F1.BUS_OBJ_OID);


DELETE GEEDW_PLP_S.CDR_ODS_LXSTATE_398850F1_S;	

INSERT INTO GEEDW_PLP_S.CDR_ODS_LXSTATE_398850F1_S
(
LXSTATE_ID,                    
BUS_OBJ_OID,                   
MXSTATEREQ_OID,                
ACTUAL_DT_GMT,                 
START_DT_GMT,                  
END_DT_GMT,  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY,
CHECKSUMTEXT
)	
SELECT 
LXSTATE_ID,                    
BUS_OBJ_OID,                   
MXSTATEREQ_OID,                
ACTUAL_DT_GMT,                 
START_DT_GMT,                  
END_DT_GMT,  
CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR',
CHECKSUMTEXT
FROM VT_LXSTATE_398850F1;

