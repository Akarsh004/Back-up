# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_T_ORG.sh 
# Creation Date: 06/10/11 
# Last Modified: 06/10/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_ORG : Start	

---- DROP TABLE VT_CDR_ODS_T_ORG;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_ORG,NO LOG (
      ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      ALTERNATE_NM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      FILE_SITE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DUNS_NUM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ORIG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ST_REGION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FILE_STORE_SYMBOLIC_NM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_NM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POSTAL_CD VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DEFAULT_POLICY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      MEETING_SITE_NM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      MEETING_SITE_ID VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      COUNTRY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CITY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      CAGE_CD VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_FAX_NUM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DISTINGUISHED_NM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      WEB_SITE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ORG_ID VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DIVISION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ADDR VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FTP_DIRECTORY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_PHONE_NUM VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PRIMARY_KEY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FTP_HOST VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )

PRIMARY INDEX ( ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_T_ORG : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_ORG
(
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTERNATE_NM                  
,FILE_SITE                     
,DUNS_NUM                      
,ORIG                          
,ST_REGION                     
,FILE_STORE_SYMBOLIC_NM        
,ORG_NM                        
,POSTAL_CD                     
,DEFAULT_POLICY                
,MEETING_SITE_NM               
,MEETING_SITE_ID               
,COUNTRY                       
,CITY                          
,CAGE_CD                       
,ORG_FAX_NUM                   
,DISTINGUISHED_NM              
,WEB_SITE                      
,ORG_ID                        
,DIVISION                      
,ADDR                          
,FTP_DIRECTORY                 
,ORG_PHONE_NUM                 
,PRIMARY_KEY                   
,FTP_HOST                      
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
             
            
           
                
)

SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTERNATE_NM                  
,FILE_SITE                     
,DUNS_NUM                      
,ORIG                          
,ST_REGION                     
,FILE_STORE_SYMBOLIC_NM        
,ORG_NM                        
,POSTAL_CD                     
,DEFAULT_POLICY                
,MEETING_SITE_NM               
,MEETING_SITE_ID               
,COUNTRY                       
,CITY                          
,CAGE_CD                       
,ORG_FAX_NUM                   
,DISTINGUISHED_NM              
,WEB_SITE                      
,ORG_ID                        
,DIVISION                      
,ADDR                          
,FTP_DIRECTORY                 
,ORG_PHONE_NUM                 
,PRIMARY_KEY                   
,FTP_HOST                      
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
                
                
               
FROM GEEDW_PLP_S.CDR_ODS_T_ORG_S
MINUS
SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTERNATE_NM                  
,FILE_SITE                     
,DUNS_NUM                      
,ORIG                          
,ST_REGION                     
,FILE_STORE_SYMBOLIC_NM        
,ORG_NM                        
,POSTAL_CD                     
,DEFAULT_POLICY                
,MEETING_SITE_NM               
,MEETING_SITE_ID               
,COUNTRY                       
,CITY                          
,CAGE_CD                       
,ORG_FAX_NUM                   
,DISTINGUISHED_NM              
,WEB_SITE                      
,ORG_ID                        
,DIVISION                      
,ADDR                          
,FTP_DIRECTORY                 
,ORG_PHONE_NUM                 
,PRIMARY_KEY                   
,FTP_HOST                      
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
             
              


FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_ORG;	




-- Table: VT_CDR_ODS_T_ORG : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_ORG_S;	

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_ORG_S
(	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTERNATE_NM                  
,FILE_SITE                     
,DUNS_NUM                      
,ORIG                          
,ST_REGION                     
,FILE_STORE_SYMBOLIC_NM        
,ORG_NM                        
,POSTAL_CD                     
,DEFAULT_POLICY                
,MEETING_SITE_NM               
,MEETING_SITE_ID               
,COUNTRY                       
,CITY                          
,CAGE_CD                       
,ORG_FAX_NUM                   
,DISTINGUISHED_NM              
,WEB_SITE                      
,ORG_ID                        
,DIVISION                      
,ADDR                          
,FTP_DIRECTORY                 
,ORG_PHONE_NUM                 
,PRIMARY_KEY                   
,FTP_HOST                      
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
                
               


)
SELECT	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTERNATE_NM                  
,FILE_SITE                     
,DUNS_NUM                      
,ORIG                          
,ST_REGION                     
,FILE_STORE_SYMBOLIC_NM        
,ORG_NM                        
,POSTAL_CD                     
,DEFAULT_POLICY                
,MEETING_SITE_NM               
,MEETING_SITE_ID               
,COUNTRY                       
,CITY                          
,CAGE_CD                       
,ORG_FAX_NUM                   
,DISTINGUISHED_NM              
,WEB_SITE                      
,ORG_ID                        
,DIVISION                      
,ADDR                          
,FTP_DIRECTORY                 
,ORG_PHONE_NUM                 
,PRIMARY_KEY                   
,FTP_HOST                      
,CURRENT_DATE                 
,'CDR'                 
,CURRENT_DATE                 
,'CDR'                
                  
  
             
            

FROM VT_CDR_ODS_T_ORG;	


-- Table: CDR_ODS_T_ORG : End
