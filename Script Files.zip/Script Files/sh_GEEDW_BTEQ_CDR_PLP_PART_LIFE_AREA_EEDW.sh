# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PART_LIFE_AREA_EEDW.sh
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_PART_LIFE_AREA : Start	

---- DROP TABLE VT_CDR_PLP_PART_LIFE_AREA;	

CREATE VOLATILE TABLE VT_CDR_PLP_PART_LIFE_AREA,NO LOG (
      PART_LIFE_AREA_SEQ_ID INTEGER,
      PART_LIFE_SEQ_ID INTEGER,
      AREA_COND_ID INTEGER,
      AREA_SEQ_ID INTEGER,
      PART_COND_SEQ_ID INTEGER,
      MEASUREMENT INTEGER,
      ENGLISH_UNIT_SEQ_ID INTEGER,
      USER_COMMENT VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC,
      DATE_ENTERED DATE FORMAT 'YY/MM/DD',
      COLOR INTEGER,
      ANGLE INTEGER,
      ZERO_PLUG INTEGER,
      MEAS VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DATA_TYPE_LKP_ID INTEGER,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PART_LIFE_SEQ_ID ,AREA_SEQ_ID ,PART_COND_SEQ_ID ,ENGLISH_UNIT_SEQ_ID );





INSERT INTO VT_CDR_PLP_PART_LIFE_AREA
(
PART_LIFE_AREA_SEQ_ID,         
PART_LIFE_SEQ_ID,              
AREA_COND_ID,                  
AREA_SEQ_ID,                   
PART_COND_SEQ_ID,              
MEASUREMENT,                   
ENGLISH_UNIT_SEQ_ID,           
USER_COMMENT,                  
DATE_ENTERED,                  
COLOR,                         
ANGLE,                         
ZERO_PLUG,                     
MEAS,                          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DATA_TYPE_LKP_ID,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                              
)
SELECT	
PART_LIFE_AREA_SEQ_ID,         
PART_LIFE_SEQ_ID,              
AREA_COND_ID,                  
AREA_SEQ_ID,                   
PART_COND_SEQ_ID,              
MEASUREMENT,                   
ENGLISH_UNIT_SEQ_ID,           
USER_COMMENT,                  
DATE_ENTERED,                  
COLOR,                         
ANGLE,                         
ZERO_PLUG,                     
MEAS,                          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DATA_TYPE_LKP_ID,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY       
FROM	 GEEDW_PLP_S.CDR_PLP_PART_LIFE_AREA_S
MINUS
SELECT	
PART_LIFE_AREA_SEQ_ID,         
PART_LIFE_SEQ_ID,              
AREA_COND_ID,                  
AREA_SEQ_ID,                   
PART_COND_SEQ_ID,              
MEASUREMENT,                   
ENGLISH_UNIT_SEQ_ID,           
USER_COMMENT,                  
DATE_ENTERED,                  
COLOR,                         
ANGLE,                         
ZERO_PLUG,                     
MEAS,                          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DATA_TYPE_LKP_ID,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY       
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PART_LIFE_AREA_EEDW;

-- Table: VT_CDR_PLP_PART_LIFE_AREA : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PART_LIFE_AREA_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PART_LIFE_AREA_S
(	
PART_LIFE_AREA_SEQ_ID,         
PART_LIFE_SEQ_ID,              
AREA_COND_ID,                  
AREA_SEQ_ID,                   
PART_COND_SEQ_ID,              
MEASUREMENT,                   
ENGLISH_UNIT_SEQ_ID,           
USER_COMMENT,                  
DATE_ENTERED,                  
COLOR,                         
ANGLE,                         
ZERO_PLUG,                     
MEAS,                          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DATA_TYPE_LKP_ID,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY       
)	
SELECT 
PART_LIFE_AREA_SEQ_ID,         
PART_LIFE_SEQ_ID,              
AREA_COND_ID,                  
AREA_SEQ_ID,                   
PART_COND_SEQ_ID,              
MEASUREMENT,                   
ENGLISH_UNIT_SEQ_ID,           
USER_COMMENT,                  
DATE_ENTERED,                  
COLOR,                         
ANGLE,                         
ZERO_PLUG,                     
MEAS,                          
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DATA_TYPE_LKP_ID,                                                                                                             CURRENT_DATE,                                                              
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PART_LIFE_AREA;	

-- Table: CDR_PLP_PART_LIFE_AREA : End




