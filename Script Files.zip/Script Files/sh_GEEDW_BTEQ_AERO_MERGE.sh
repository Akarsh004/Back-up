sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_AERO_MERGE1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_AERO_MERGE_LOG.txt 2>&1
