#!/bin/ksh
if [ `date +%d` = 01 ] ;
then 
        cd  /data/informatica/ETCOE/EEDW01/PLMDrwgHeaderData/  
	mv -f /data/informatica/ETCOE/EEDW01/PLMDrwgHeaderData/*ug_issue.rpt-* /data/informatica/ETCOE/EEDW01/TgtFiles/*ug_issue.rpt-*
fi
