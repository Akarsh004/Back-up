# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_R_TASK_DELIVRBLE.sh 
# Creation Date: 07/29/10 
# Last Modified: 10/01/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_R_TASK_DELIVRBLE_S : Start	

---- DROP TABLE VT_CDR_ODS_R_TASK_DELIVRBLE;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_R_TASK_DELIVRBLE,NO LOG (
RELATION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FROM_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FROM_TYPE VARCHAR(128)	CHARACTER SET LATIN NOT CASESPECIFIC,
FROM_NAME VARCHAR (128) CHARACTER SET LATIN NOT CASESPECIFIC,
FROM_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FROM_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
TO_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
TO_TYPE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
TO_NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
TO_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
TO_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FROZEN_IND VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATED_BY VARCHAR(20)	CHARACTER SET LATIN NOT CASESPECIFIC,
CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD',
SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD',
SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD',
OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
ACTUAL_CUST_DISPOSITION_DT DATE	FORMAT 'YYYY-MM-DD',
DD250_APPROVAL_DT DATE FORMAT 'YYYY-MM-DD',
RESUBMITTAL_DT DATE FORMAT 'YYYY-MM-DD',
REPLAN_DT_DISPOSITION_TO_DM DATE FORMAT 'YYYY-MM-DD',
CUST_DISPOSITION_DT	DATE FORMAT 'YYYY-MM-DD',
REPLAN_CUST_DISPOSITION_DT DATE	FORMAT 'YYYY-MM-DD',
START_ST VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
SCHD_DATA_MGR_DISPOSITION_DT DATE FORMAT 'YYYY-MM-DD',
ACTUAL_DT_DISPOSITION_TO_DM DATE FORMAT 'YYYY-MM-DD',
CUST_REPLY_LETTER_NUM VARCHAR(300)	CHARACTER SET LATIN NOT CASESPECIFIC,
SCHD_DT_DISPOSITION_TO_DM DATE FORMAT 'YYYY-MM-DD',
RESUBMITTAL_REQUIRED VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
REVIEWERS_DISPOSITION_CMTS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
END_ST VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
ACTUAL_DATA_MGR_DISPOSITION_DT DATE FORMAT 'YYYY-MM-DD',
DOC_STATUS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
REPLAN_DATA_MGR_DISPOSITION_DT DATE FORMAT 'YYYY-MM-DD',
DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX  ( RELATION_ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_GIB_CUSTOMER : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_R_TASK_DELIVRBLE
(
RELATION_ID,                   
FROM_ID ,                      
FROM_TYPE,                     
FROM_NAME,                     
FROM_REVISION,                 
FROM_VAULT,                    
TO_ID,                         
TO_TYPE ,                      
TO_NAME ,                      
TO_REVISION,                   
TO_VAULT,                      
FROZEN_IND,                    
CREATED_BY,                    
CREATION_DATE,                
LAST_UPDATED_BY,               
LAST_UPDATE_DATE ,             
SOURCE_MODIFIED_DATE,          
SOURCE_ORIGINATED_DATE,        
OWNER,                         
ALTOWNER1,                     
ALTOWNER2,                     
ACTUAL_CUST_DISPOSITION_DT ,   
DD250_APPROVAL_DT,             
RESUBMITTAL_DT,                
REPLAN_DT_DISPOSITION_TO_DM ,  
CUST_DISPOSITION_DT,           
REPLAN_CUST_DISPOSITION_DT,    
START_ST,                      
SCHD_DATA_MGR_DISPOSITION_DT , 
ACTUAL_DT_DISPOSITION_TO_DM,   
CUST_REPLY_LETTER_NUM,         
SCHD_DT_DISPOSITION_TO_DM,     
RESUBMITTAL_REQUIRED ,         
REVIEWERS_DISPOSITION_CMTS,    
END_ST,                        
ACTUAL_DATA_MGR_DISPOSITION_DT,
DOC_STATUS,                    
REPLAN_DATA_MGR_DISPOSITION_DT,
DW_LOAD_DATE,                  
DW_CREATED_BY ,                
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                                                                                                                                        
)
SELECT 
RELATION_ID,                   
FROM_ID ,                      
FROM_TYPE,                     
FROM_NAME,                     
FROM_REVISION,                 
FROM_VAULT,                    
TO_ID,                         
TO_TYPE ,                      
TO_NAME ,                      
TO_REVISION,                   
TO_VAULT,                      
FROZEN_IND,                    
CREATED_BY,                    
CREATION_DATE,                
LAST_UPDATED_BY,               
LAST_UPDATE_DATE ,             
SOURCE_MODIFIED_DATE,          
SOURCE_ORIGINATED_DATE,        
OWNER,                         
ALTOWNER1,                     
ALTOWNER2,                     
ACTUAL_CUST_DISPOSITION_DT ,   
DD250_APPROVAL_DT,             
RESUBMITTAL_DT,                
REPLAN_DT_DISPOSITION_TO_DM ,  
CUST_DISPOSITION_DT,           
REPLAN_CUST_DISPOSITION_DT,    
START_ST,                      
SCHD_DATA_MGR_DISPOSITION_DT , 
ACTUAL_DT_DISPOSITION_TO_DM,   
CUST_REPLY_LETTER_NUM,         
SCHD_DT_DISPOSITION_TO_DM,     
RESUBMITTAL_REQUIRED ,         
REVIEWERS_DISPOSITION_CMTS,    
END_ST,                        
ACTUAL_DATA_MGR_DISPOSITION_DT,
DOC_STATUS,                    
REPLAN_DATA_MGR_DISPOSITION_DT,
DW_LOAD_DATE,                  
DW_CREATED_BY ,                
DW_UPDATED_DATE,               
DW_UPDATED_BY 
FROM GEEDW_PLP_S.CDR_ODS_R_TASK_DELIVRBLE_S
MINUS
SELECT
RELATION_ID,                   
FROM_ID ,                      
FROM_TYPE,                     
FROM_NAME,                     
FROM_REVISION,                 
FROM_VAULT,                    
TO_ID,                         
TO_TYPE ,                      
TO_NAME ,                      
TO_REVISION,                   
TO_VAULT,                      
FROZEN_IND,                    
CREATED_BY,                    
CREATION_DATE,                
LAST_UPDATED_BY,               
LAST_UPDATE_DATE ,             
SOURCE_MODIFIED_DATE,          
SOURCE_ORIGINATED_DATE,        
OWNER,                         
ALTOWNER1,                     
ALTOWNER2,                     
ACTUAL_CUST_DISPOSITION_DT ,   
DD250_APPROVAL_DT,             
RESUBMITTAL_DT,                
REPLAN_DT_DISPOSITION_TO_DM ,  
CUST_DISPOSITION_DT,           
REPLAN_CUST_DISPOSITION_DT,    
START_ST,                      
SCHD_DATA_MGR_DISPOSITION_DT , 
ACTUAL_DT_DISPOSITION_TO_DM,   
CUST_REPLY_LETTER_NUM,         
SCHD_DT_DISPOSITION_TO_DM,     
RESUBMITTAL_REQUIRED ,         
REVIEWERS_DISPOSITION_CMTS,    
END_ST,                        
ACTUAL_DATA_MGR_DISPOSITION_DT,
DOC_STATUS,                    
REPLAN_DATA_MGR_DISPOSITION_DT,
DW_LOAD_DATE,                  
DW_CREATED_BY ,                
DW_UPDATED_DATE,               
DW_UPDATED_BY 
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_R_TASK_DELIVRBLE;	




-- Table: VT_CDR_GIB_CUSTOMER : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_R_TASK_DELIVRBLE_S;	

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_ODS_R_TASK_DELIVRBLE_S
(	
RELATION_ID,                   
FROM_ID ,                      
FROM_TYPE,                     
FROM_NAME,                     
FROM_REVISION,                 
FROM_VAULT,                    
TO_ID,                         
TO_TYPE ,                      
TO_NAME ,                      
TO_REVISION,                   
TO_VAULT,                      
FROZEN_IND,                    
CREATED_BY,                    
CREATION_DATE,                
LAST_UPDATED_BY,               
LAST_UPDATE_DATE ,             
SOURCE_MODIFIED_DATE,          
SOURCE_ORIGINATED_DATE,        
OWNER,                         
ALTOWNER1,                     
ALTOWNER2,                     
ACTUAL_CUST_DISPOSITION_DT ,   
DD250_APPROVAL_DT,             
RESUBMITTAL_DT,                
REPLAN_DT_DISPOSITION_TO_DM ,  
CUST_DISPOSITION_DT,           
REPLAN_CUST_DISPOSITION_DT,    
START_ST,                      
SCHD_DATA_MGR_DISPOSITION_DT , 
ACTUAL_DT_DISPOSITION_TO_DM,   
CUST_REPLY_LETTER_NUM,         
SCHD_DT_DISPOSITION_TO_DM,     
RESUBMITTAL_REQUIRED ,         
REVIEWERS_DISPOSITION_CMTS,    
END_ST,                        
ACTUAL_DATA_MGR_DISPOSITION_DT,
DOC_STATUS,                    
REPLAN_DATA_MGR_DISPOSITION_DT,
DW_LOAD_DATE,                  
DW_CREATED_BY ,                
DW_UPDATED_DATE,               
DW_UPDATED_BY 
)	
SELECT 
RELATION_ID,                   
FROM_ID ,                      
FROM_TYPE,                     
FROM_NAME,                     
FROM_REVISION,                 
FROM_VAULT,                    
TO_ID,                         
TO_TYPE ,                      
TO_NAME ,                      
TO_REVISION,                   
TO_VAULT,                      
FROZEN_IND,                    
CREATED_BY,                    
CREATION_DATE,                
LAST_UPDATED_BY,               
LAST_UPDATE_DATE ,             
SOURCE_MODIFIED_DATE,          
SOURCE_ORIGINATED_DATE,        
OWNER,                         
ALTOWNER1,                     
ALTOWNER2,                     
ACTUAL_CUST_DISPOSITION_DT ,   
DD250_APPROVAL_DT,             
RESUBMITTAL_DT,                
REPLAN_DT_DISPOSITION_TO_DM ,  
CUST_DISPOSITION_DT,           
REPLAN_CUST_DISPOSITION_DT,    
START_ST,                      
SCHD_DATA_MGR_DISPOSITION_DT , 
ACTUAL_DT_DISPOSITION_TO_DM,   
CUST_REPLY_LETTER_NUM,         
SCHD_DT_DISPOSITION_TO_DM,     
RESUBMITTAL_REQUIRED ,         
REVIEWERS_DISPOSITION_CMTS,    
END_ST,                        
ACTUAL_DATA_MGR_DISPOSITION_DT,
DOC_STATUS,                    
REPLAN_DATA_MGR_DISPOSITION_DT,
CURRENT_DATE,                
'CDR'   ,              
CURRENT_DATE  ,               
'CDR'                
         
FROM VT_CDR_ODS_R_TASK_DELIVRBLE;	


-- Table: CDR_ODS_R_TASK_DELIVRBLE : End
