
DL=tanwir.shaikh@ge.com,akarsh.singh@ge.com,Chandana.Ray@ge.com
set heading off;
set feedback off;
DL=`echo "$DL"| tr -d '\040\'`
echo "$DL"
VAR_1=`cat /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_TC5_MERGE1_LOG.txt | grep -i "FAILURE"`
XYZ=$?
if [ $XYZ = 0 ]
then
echo "Error"
(echo -e "Hi, \n This is an auto generated email for Merge execution failure. \n\nPlease take necessary steps to rectify the error.
\n\n Regards, \n TC5 - ETL Team") | mailx -s "Merge Execution Failed!!" $DL 
else
echo "No Error"
fi