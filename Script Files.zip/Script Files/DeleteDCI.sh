. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq  << eof
/*.RUN File = ${SrcDir}/td_plp.mlbt;*/
.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;

delete from GEEDW_PLP_BULK_T.CDR_AN_DETAIL;
delete from GEEDW_PLP_BULK_T.CDR_AN_AUTH;
delete from GEEDW_PLP_BULK_T.CDR_AN_HEADER;
delete from GEEDW_PLP_BULK_T.CDR_DCI_COST;
delete from GEEDW_PLP_BULK_T.CDR_DCI_ORDER_NUMBER;
/*--delete from GEEDW_PLP_BULK_T.CDR_GIB_EMPLOYEE;*/
/*--delete from GEEDW_PLP_BULK_T.CDR_GIB_ORG_HIERARCHY;*/
/*--DELETE FROM GEEDW_PLP_BULK_T.CDR_GIB_CUSTOMER;*/
DELETE FROM GEEDW_PLP_BULK_T.CDR_PLP_OUTAGE_DETAILS;
DELETE FROM GEEDW_PLP_BULK_T.CDR_PLP_UNIT_DETAILS;
DELETE FROM GEEDW_PLP_BULK_T.CDR_PLP_OUTAGE_TYPE_LOOKUP;
.logoff
.quit
eof