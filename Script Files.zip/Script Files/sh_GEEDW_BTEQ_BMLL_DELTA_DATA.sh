sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BMLL_DELTA_DATA1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BMLL_DELTA_DATA1_LOG.txt 2>&1
