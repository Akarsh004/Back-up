# ---------------------------------------------------------------------------- 
#
# File: sh_GEEDW_BTEQ_CDR_ODS_T_GE_COST.sh 
# Creation Date: 09/20/11  
# Last Modified: 09/20/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
.RUN File = ${SrcDir}/td_plp.mlbt 

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;  */

database ${Stg_database};

-- Table: CDR_ODS_T_GE_COST : Start

---- DROP TABLE VT_CDR_ODS_T_GE_COST ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_GE_COST ,NO LOG (
      ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      OWNER_COL VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD',
      SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      GE_ENGRG_HOURS DECIMAL(26,8),
      GE_TRANSPORTATION_COST DECIMAL(26,8) ,
      GE_MFGG_PLANNED_LEAD_TIME DECIMAL(26,8) ,
      GE_REFERENCE_CODE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_CURRENCY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_LOC_NAME VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_COST_TYPE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_DRAFTING_HOURS DECIMAL(26,8) ,
      GE_SUB_TOTAL_ENG_FIELD_TRN_CST DECIMAL(26,8) ,
      GE_MFGG_LABOR_HOURS DECIMAL(26,8) ,
      GE_ENGRG_EFFORT DECIMAL(26,8) ,
      GE_UNITOF_MEASURE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      GE_COST_DESCRIPTION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      GE_MFGG_MATERIAL_LEAD_TIME DECIMAL(26,8) ,
      GE_ENG_TOTAL_COST DECIMAL(26,8) ,
      GE_PART_NAME VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      GE_MAKE_BUY_CODE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_ENGRG_DURATION DECIMAL(26,8) ,
      GE_VENDOR_QUOTES_DATA DECIMAL(26,8) ,
      GE_APPLIED_DIRECT_LABOR DECIMAL(26,8) ,
      GE_RAW_IN_PROCESS_COST DECIMAL(26,8) ,
      GE_PRDT_COST DECIMAL(26,8) ,
      GE_SHOP_WORKAND_LAB DECIMAL(26,8),
      GE_MATERIAL_SHIP_DIRECT_COST DECIMAL(26,8) ,
      GE_FIELD_INSTALLATION_COST DECIMAL(26,8),
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC 

      )

 



PRIMARY INDEX (ID) ON COMMIT PRESERVE ROWS;
-- Table: CDR_ODS_T_GE_COST  : Processing : Populate GT table with CDC data

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_GE_COST
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
GE_ENGRG_HOURS                ,
GE_TRANSPORTATION_COST        ,
GE_MFGG_PLANNED_LEAD_TIME     ,
GE_REFERENCE_CODE             ,
GE_CURRENCY                   ,
GE_LOC_NAME                   ,
GE_COST_TYPE                  ,
GE_DRAFTING_HOURS             ,
GE_SUB_TOTAL_ENG_FIELD_TRN_CST,
GE_MFGG_LABOR_HOURS           ,
GE_ENGRG_EFFORT               ,
GE_UNITOF_MEASURE             ,
GE_COST_DESCRIPTION           ,
GE_MFGG_MATERIAL_LEAD_TIME    ,
GE_ENG_TOTAL_COST             ,
GE_PART_NAME                  ,
GE_MAKE_BUY_CODE              ,
GE_ENGRG_DURATION             ,
GE_VENDOR_QUOTES_DATA         ,
GE_APPLIED_DIRECT_LABOR       ,
GE_RAW_IN_PROCESS_COST        ,
GE_PRDT_COST                  ,
GE_SHOP_WORKAND_LAB           ,
GE_MATERIAL_SHIP_DIRECT_COST  ,
GE_FIELD_INSTALLATION_COST    ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 


 
                

)

    select
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
GE_ENGRG_HOURS                ,
GE_TRANSPORTATION_COST        ,
GE_MFGG_PLANNED_LEAD_TIME     ,
GE_REFERENCE_CODE             ,
GE_CURRENCY                   ,
GE_LOC_NAME                   ,
GE_COST_TYPE                  ,
GE_DRAFTING_HOURS             ,
GE_SUB_TOTAL_ENG_FIELD_TRN_CST,
GE_MFGG_LABOR_HOURS           ,
GE_ENGRG_EFFORT               ,
GE_UNITOF_MEASURE             ,
GE_COST_DESCRIPTION           ,
GE_MFGG_MATERIAL_LEAD_TIME    ,
GE_ENG_TOTAL_COST             ,
GE_PART_NAME                  ,
GE_MAKE_BUY_CODE              ,
GE_ENGRG_DURATION             ,
GE_VENDOR_QUOTES_DATA         ,
GE_APPLIED_DIRECT_LABOR       ,
GE_RAW_IN_PROCESS_COST        ,
GE_PRDT_COST                  ,
GE_SHOP_WORKAND_LAB           ,
GE_MATERIAL_SHIP_DIRECT_COST  ,
GE_FIELD_INSTALLATION_COST    ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 

FROM GEEDW_PLP_S.CDR_ODS_T_GE_COST_S
MINUS
SELECT

ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
GE_ENGRG_HOURS                ,
GE_TRANSPORTATION_COST        ,
GE_MFGG_PLANNED_LEAD_TIME     ,
GE_REFERENCE_CODE             ,
GE_CURRENCY                   ,
GE_LOC_NAME                   ,
GE_COST_TYPE                  ,
GE_DRAFTING_HOURS             ,
GE_SUB_TOTAL_ENG_FIELD_TRN_CST,
GE_MFGG_LABOR_HOURS           ,
GE_ENGRG_EFFORT               ,
GE_UNITOF_MEASURE             ,
GE_COST_DESCRIPTION           ,
GE_MFGG_MATERIAL_LEAD_TIME    ,
GE_ENG_TOTAL_COST             ,
GE_PART_NAME                  ,
GE_MAKE_BUY_CODE              ,
GE_ENGRG_DURATION             ,
GE_VENDOR_QUOTES_DATA         ,
GE_APPLIED_DIRECT_LABOR       ,
GE_RAW_IN_PROCESS_COST        ,
GE_PRDT_COST                  ,
GE_SHOP_WORKAND_LAB           ,
GE_MATERIAL_SHIP_DIRECT_COST  ,
GE_FIELD_INSTALLATION_COST    ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_GE_COST ;



-- Table: VT_CDR_ODS_T_GE_COST  : Processing : Populate Stage table with CDC data only for mLDM processing

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_GE_COST_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_GE_COST_S
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
GE_ENGRG_HOURS                ,
GE_TRANSPORTATION_COST        ,
GE_MFGG_PLANNED_LEAD_TIME     ,
GE_REFERENCE_CODE             ,
GE_CURRENCY                   ,
GE_LOC_NAME                   ,
GE_COST_TYPE                  ,
GE_DRAFTING_HOURS             ,
GE_SUB_TOTAL_ENG_FIELD_TRN_CST,
GE_MFGG_LABOR_HOURS           ,
GE_ENGRG_EFFORT               ,
GE_UNITOF_MEASURE             ,
GE_COST_DESCRIPTION           ,
GE_MFGG_MATERIAL_LEAD_TIME    ,
GE_ENG_TOTAL_COST             ,
GE_PART_NAME                  ,
GE_MAKE_BUY_CODE              ,
GE_ENGRG_DURATION             ,
GE_VENDOR_QUOTES_DATA         ,
GE_APPLIED_DIRECT_LABOR       ,
GE_RAW_IN_PROCESS_COST        ,
GE_PRDT_COST                  ,
GE_SHOP_WORKAND_LAB           ,
GE_MATERIAL_SHIP_DIRECT_COST  ,
GE_FIELD_INSTALLATION_COST    ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
GE_ENGRG_HOURS                ,
GE_TRANSPORTATION_COST        ,
GE_MFGG_PLANNED_LEAD_TIME     ,
GE_REFERENCE_CODE             ,
GE_CURRENCY                   ,
GE_LOC_NAME                   ,
GE_COST_TYPE                  ,
GE_DRAFTING_HOURS             ,
GE_SUB_TOTAL_ENG_FIELD_TRN_CST,
GE_MFGG_LABOR_HOURS           ,
GE_ENGRG_EFFORT               ,
GE_UNITOF_MEASURE             ,
GE_COST_DESCRIPTION           ,
GE_MFGG_MATERIAL_LEAD_TIME    ,
GE_ENG_TOTAL_COST             ,
GE_PART_NAME                  ,
GE_MAKE_BUY_CODE              ,
GE_ENGRG_DURATION             ,
GE_VENDOR_QUOTES_DATA         ,
GE_APPLIED_DIRECT_LABOR       ,
GE_RAW_IN_PROCESS_COST        ,
GE_PRDT_COST                  ,
GE_SHOP_WORKAND_LAB           ,
GE_MATERIAL_SHIP_DIRECT_COST  ,
GE_FIELD_INSTALLATION_COST    ,
 CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE                 
,'CDR'          
         



             
FROM VT_CDR_ODS_T_GE_COST ;


-- Table: CDR_ODS_T_GE_COST  : End



























