# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_T_ECR.sh 
# Creation Date: 06/10/11 
# Last Modified: 06/10/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
.RUN File = ${SrcDir}/td_plp.mlbt

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_ECR  : Start	

---- DROP TABLE VT_CDR_ODS_T_ECR ;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_ECR ,NO LOG (
ID VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
NAME VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
REVISION VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
VAULT VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
OWNER VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
DESCRIPTION VARCHAR(4000) CHARACTER  SET LATIN NOT CASESPECIFIC,
POLICY VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
STATE VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
NEXT_REVISION_ID VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
FIRST_REVISION_ID VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
LATEST_REVISION_ID VARCHAR(128) CHARACTER  SET LATIN NOT CASESPECIFIC,
CREATED_BY VARCHAR(20) CHARACTER  SET LATIN NOT CASESPECIFIC,
CREATION_DATE DATE FORMAT  'YYYY-MM-DD'   ,
LAST_UPDATED_BY VARCHAR(20) CHARACTER  SET LATIN NOT CASESPECIFIC,
LAST_UPDATE_DATE DATE FORMAT  'YYYY-MM-DD'   ,
SOURCE_MODIFIED_DATE DATE FORMAT  'YYYY-MM-DD'   ,
SOURCE_ORIGINATED_DATE DATE FORMAT  'YYYY-MM-DD'   ,
REASON_FOR_CHANGE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
END_DT DATE FORMAT  'YYYY-MM-DD'   ,
ORIG VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
BRANCH_TO VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
CATEGORY_CHANGE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
SEVERITY VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
REASON_FOR_CANCEL VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GENERAL_DESCR_CHANGE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
RSP_DESIGN_ENGR VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
SECONDARY_KEYS VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
ECR_EVALUATOR VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
PRIMARY_KEY VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
START_DT DATE FORMAT  'YYYY-MM-DD'   ,
IS_DEVIATION VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
REVIEWERS_CMTS VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_SOURCE_ID VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_RAM VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_CHANGE_SUMMARY VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_PRDT_SAFETY VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_PART_LIFE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_SUBSTANTIATION VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_SOURCE_SYSTEM VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_PERFORMANCE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_INTRCHNGBLTY VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_INTERFACE VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_RSPB_CCB_CHAIRMAN VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_IMPACT_TO_TECH_RGLTNS_STDS VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
GE_CLS_I_IMPACT_STATEMENT VARCHAR(300) CHARACTER  SET LATIN NOT CASESPECIFIC,
DW_LOAD_DATE DATE FORMAT  'YY/MM/DD'   ,
DW_CREATED_BY VARCHAR(20) CHARACTER  SET LATIN NOT CASESPECIFIC,
DW_UPDATED_DATE DATE FORMAT  'YY/MM/DD'   ,
DW_UPDATED_BY VARCHAR(20) CHARACTER  SET LATIN NOT CASESPECIFIC
)

PRIMARY INDEX ( ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_T_ECR  : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_ECR 
(
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,REASON_FOR_CHANGE             
,END_DT                        
,ORIG                          
,BRANCH_TO                     
,CATEGORY_CHANGE               
,SEVERITY                      
,REASON_FOR_CANCEL             
,GENERAL_DESCR_CHANGE          
,RSP_DESIGN_ENGR               
,SECONDARY_KEYS                
,ECR_EVALUATOR                 
,PRIMARY_KEY                   
,START_DT                      
,IS_DEVIATION                  
,REVIEWERS_CMTS                
 ,GE_SOURCE_ID                  
,GE_IMPACT_TO_RAM              
,GE_CHANGE_SUMMARY             
,GE_IMPACT_TO_PRDT_SAFETY      
,GE_IMPACT_TO_PART_LIFE        
,GE_SUBSTANTIATION             
,GE_SOURCE_SYSTEM              
,GE_IMPACT_TO_PERFORMANCE      
,GE_IMPACT_TO_INTRCHNGBLTY     
,GE_IMPACT_TO_INTERFACE        
,GE_RSPB_CCB_CHAIRMAN          
,GE_IMPACT_TO_TECH_RGLTNS_STDS 
,GE_CLS_I_IMPACT_STATEMENT     
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
                
)

SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,REASON_FOR_CHANGE             
,END_DT                        
,ORIG                          
,BRANCH_TO                     
,CATEGORY_CHANGE               
,SEVERITY                      
,REASON_FOR_CANCEL             
,GENERAL_DESCR_CHANGE          
,RSP_DESIGN_ENGR               
,SECONDARY_KEYS                
,ECR_EVALUATOR                 
,PRIMARY_KEY                   
,START_DT                      
,IS_DEVIATION                  
,REVIEWERS_CMTS                
,GE_SOURCE_ID                  
,GE_IMPACT_TO_RAM              
,GE_CHANGE_SUMMARY             
,GE_IMPACT_TO_PRDT_SAFETY      
,GE_IMPACT_TO_PART_LIFE        
,GE_SUBSTANTIATION             
,GE_SOURCE_SYSTEM              
,GE_IMPACT_TO_PERFORMANCE      
,GE_IMPACT_TO_INTRCHNGBLTY     
,GE_IMPACT_TO_INTERFACE        
,GE_RSPB_CCB_CHAIRMAN          
,GE_IMPACT_TO_TECH_RGLTNS_STDS 
,GE_CLS_I_IMPACT_STATEMENT     
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                              
FROM GEEDW_PLP_S.CDR_ODS_T_ECR_S
MINUS
SELECT
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,REASON_FOR_CHANGE             
,END_DT                        
,ORIG                          
,BRANCH_TO                     
,CATEGORY_CHANGE               
,SEVERITY                      
,REASON_FOR_CANCEL             
,GENERAL_DESCR_CHANGE          
,RSP_DESIGN_ENGR               
,SECONDARY_KEYS                
,ECR_EVALUATOR                 
,PRIMARY_KEY                   
,START_DT                      
,IS_DEVIATION                  
,REVIEWERS_CMTS                
,GE_SOURCE_ID                  
,GE_IMPACT_TO_RAM              
,GE_CHANGE_SUMMARY             
,GE_IMPACT_TO_PRDT_SAFETY      
,GE_IMPACT_TO_PART_LIFE        
,GE_SUBSTANTIATION             
,GE_SOURCE_SYSTEM              
,GE_IMPACT_TO_PERFORMANCE      
,GE_IMPACT_TO_INTRCHNGBLTY     
,GE_IMPACT_TO_INTERFACE        
,GE_RSPB_CCB_CHAIRMAN          
,GE_IMPACT_TO_TECH_RGLTNS_STDS 
,GE_CLS_I_IMPACT_STATEMENT     
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 

FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_ECR ;	




-- Table: VT_CDR_ODS_T_ECR  : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_ECR_S;	

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_ECR_S
(	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,REASON_FOR_CHANGE             
,END_DT                        
,ORIG                          
,BRANCH_TO                     
,CATEGORY_CHANGE               
,SEVERITY                      
,REASON_FOR_CANCEL             
,GENERAL_DESCR_CHANGE          
,RSP_DESIGN_ENGR               
,SECONDARY_KEYS                
,ECR_EVALUATOR                 
,PRIMARY_KEY                   
,START_DT                      
,IS_DEVIATION                  
,REVIEWERS_CMTS                
,GE_SOURCE_ID                  
,GE_IMPACT_TO_RAM              
,GE_CHANGE_SUMMARY             
,GE_IMPACT_TO_PRDT_SAFETY      
,GE_IMPACT_TO_PART_LIFE        
,GE_SUBSTANTIATION             
,GE_SOURCE_SYSTEM              
,GE_IMPACT_TO_PERFORMANCE      
,GE_IMPACT_TO_INTRCHNGBLTY     
,GE_IMPACT_TO_INTERFACE        
,GE_RSPB_CCB_CHAIRMAN          
,GE_IMPACT_TO_TECH_RGLTNS_STDS 
,GE_CLS_I_IMPACT_STATEMENT     
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 


)
SELECT	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                     
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,REASON_FOR_CHANGE             
,END_DT                        
,ORIG                          
,BRANCH_TO                     
,CATEGORY_CHANGE               
,SEVERITY                      
,REASON_FOR_CANCEL             
,GENERAL_DESCR_CHANGE          
,RSP_DESIGN_ENGR               
,SECONDARY_KEYS                
,ECR_EVALUATOR                 
,PRIMARY_KEY                   
,START_DT                      
,IS_DEVIATION                  
,REVIEWERS_CMTS                         
,GE_SOURCE_ID                  
,GE_IMPACT_TO_RAM              
,GE_CHANGE_SUMMARY             
,GE_IMPACT_TO_PRDT_SAFETY      
,GE_IMPACT_TO_PART_LIFE        
,GE_SUBSTANTIATION             
,GE_SOURCE_SYSTEM              
,GE_IMPACT_TO_PERFORMANCE      
,GE_IMPACT_TO_INTRCHNGBLTY     
,GE_IMPACT_TO_INTERFACE        
,GE_RSPB_CCB_CHAIRMAN          
,GE_IMPACT_TO_TECH_RGLTNS_STDS 
,GE_CLS_I_IMPACT_STATEMENT     
,CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE                  
,'CDR' 

             
FROM VT_CDR_ODS_T_ECR ;	


-- Table: CDR_ODS_T_ECR  : End
