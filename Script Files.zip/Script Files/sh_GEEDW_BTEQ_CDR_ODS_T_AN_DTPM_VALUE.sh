# ---------------------------------------------------------------------------- 
#
# File: sh_GEEDW_BTEQ_CDR_ODS_T_AN_DTPM_VALUE.sh 
# Creation Date: 09/20/11  
# Last Modified: 09/20/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */ 

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_AN_DTPM_VALUE : Start

---- DROP TABLE VT_CDR_ODS_T_AN_DTPM_VALUE ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_AN_DTPM_VALUE ,NO LOG (
 ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OWNER_COL VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TPM_CURRENT_VALUE_EFCTIV_DATE DATE FORMAT 'YYYY-MM-DD' ,
      STATUS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TPM_CURRENT_UNCERTAINTY_VALUE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORIG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TPM_CURRENT_VALUE DECIMAL(26,8) ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC 


      )

 



PRIMARY INDEX (ID) ON COMMIT PRESERVE ROWS;
-- Table: CDR_ODS_T_AN_DTPM_VALUE  : Processing : Populate GT table with CDC data

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_AN_DTPM_VALUE
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
TPM_CURRENT_VALUE_EFCTIV_DATE ,
STATUS                        ,
TPM_CURRENT_UNCERTAINTY_VALUE ,
ORIG                          ,
TPM_CURRENT_VALUE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 


 
                

)
select

ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
TPM_CURRENT_VALUE_EFCTIV_DATE ,
STATUS                        ,
TPM_CURRENT_UNCERTAINTY_VALUE ,
ORIG                          ,
TPM_CURRENT_VALUE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
            
FROM GEEDW_PLP_S.CDR_ODS_T_AN_DTPM_VALUE_S
MINUS
SELECT
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
TPM_CURRENT_VALUE_EFCTIV_DATE ,
STATUS                        ,
TPM_CURRENT_UNCERTAINTY_VALUE ,
ORIG                          ,
TPM_CURRENT_VALUE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_AN_DTPM_VALUE ;



-- Table: VT_CDR_ODS_T_AN_DTPM_VALUE  : Processing : Populate Stage table with CDC data only for mLDM processing

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_AN_DTPM_VALUE_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_AN_DTPM_VALUE_S
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
TPM_CURRENT_VALUE_EFCTIV_DATE ,
STATUS                        ,
TPM_CURRENT_UNCERTAINTY_VALUE ,
ORIG                          ,
TPM_CURRENT_VALUE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 

)
SELECT
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
TPM_CURRENT_VALUE_EFCTIV_DATE ,
STATUS                        ,
TPM_CURRENT_UNCERTAINTY_VALUE ,
ORIG                          ,
TPM_CURRENT_VALUE             ,
CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE                 
,'CDR'          
         



             
FROM VT_CDR_ODS_T_AN_DTPM_VALUE ;


-- Table: CDR_ODS_T_AN_DTPM_VALUE  : End



























