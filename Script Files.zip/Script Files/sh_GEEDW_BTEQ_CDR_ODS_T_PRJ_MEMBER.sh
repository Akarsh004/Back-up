# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_T_PRJ_MEMBER.sh 
# Creation Date: 07/28/11 
# Last Modified: 07/28/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_PRJ_MEMBER : Start	

---- DROP TABLE VT_CDR_ODS_T_PRJ_MEMBER;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_PRJ_MEMBER,NO LOG (
SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD',
SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD',
ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATE_VAULT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATE_ROUTE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
ORIG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
HOST_MEETINGS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATE_FOLDER VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
PROJECT_ROLE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
PROJECT_ACCESS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATION_DATE DATE FORMAT 'YYYY-MM-DD'   ,
LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD'   ,
DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
)

PRIMARY INDEX ( ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_T_PRJ_MEMBER : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_PRJ_MEMBER
(
SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,CREATE_VAULT                  
,CREATE_ROUTE                  
,ORIG                          
,HOST_MEETINGS                 
,CREATE_FOLDER                 
,PROJECT_ROLE                  
,PROJECT_ACCESS                
,ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
               
             
            
           
                
)

SELECT 
SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,CREATE_VAULT                  
,CREATE_ROUTE                  
,ORIG                          
,HOST_MEETINGS                 
,CREATE_FOLDER                 
,PROJECT_ROLE                  
,PROJECT_ACCESS                
,ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
               
                
FROM GEEDW_PLP_S.CDR_ODS_T_PRJ_MEMBER_S
MINUS
SELECT 
SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,CREATE_VAULT                  
,CREATE_ROUTE                  
,ORIG                          
,HOST_MEETINGS                 
,CREATE_FOLDER                 
,PROJECT_ROLE                  
,PROJECT_ACCESS                
,ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
              
             
              


FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_PRJ_MEMBER;	




-- Table: VT_CDR_ODS_T_PRJ_MEMBER : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_PRJ_MEMBER_S;	

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_PRJ_MEMBER_S
(	
SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,CREATE_VAULT                  
,CREATE_ROUTE                  
,ORIG                          
,HOST_MEETINGS                 
,CREATE_FOLDER                 
,PROJECT_ROLE                  
,PROJECT_ACCESS                
,ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
            
                
               


)
SELECT	
SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,CREATE_VAULT                  
,CREATE_ROUTE                  
,ORIG                          
,HOST_MEETINGS                 
,CREATE_FOLDER                 
,PROJECT_ROLE                  
,PROJECT_ACCESS                
,ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,CURRENT_DATE                 
,'CDR'                 
,CURRENT_DATE                 
,'CDR'                
          
               
        
  
             
            

FROM VT_CDR_ODS_T_PRJ_MEMBER;	


-- Table: CDR_ODS_T_PRJ_MEMBER : End
