. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
fastload<<eof

dateform ANSIDATE;

errlimit 1000000;
tenacity 4;        
sessions 1;
sleep 6;

RUN /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;

DROP TABLE ${Stg_database}.ET_CDR_ESPL_BOM_EPE_HST  ; 
DROP TABLE ${Stg_database}.UV_CDR_ESPL_BOM_EPE_HST   ; 
DROP TABLE ${Stg_database}.CDR_ESPL_BOM_EPE_HST  ;
CREATE MULTISET TABLE ${Stg_database}.CDR_ESPL_BOM_EPE_HST ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      PARENT_CLASS VARCHAR(19) CHARACTER SET LATIN CASESPECIFIC TITLE 'PARENT_CLASS',
      PARENT_DRAWING_NO VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'PARENT_DRAWING_NO',
      REVISION VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'REVISION',
      CHILD_CLASS VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CHILD_CLASS',
      MEMBER_DRAWING_NO VARCHAR(30) CHARACTER SET LATIN CASESPECIFIC TITLE 'MEMBER_DRAWING_NO',
      ITEM_NO VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'ITEM_NO',
      DWG_AREA VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DWG_AREA',
      LINK_CLASS VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'LINK_CLASS',
      QUANTITY FLOAT TITLE 'QUANTITY',
      UOM VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'UOM',
      HIST_FLG VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'HIST_FLG',
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_LOAD_DATE' NOT NULL,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_CREATED_BY' NOT NULL,
      DW_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' TITLE 'DW_UPDATE_DATE' NOT NULL,
      DW_UPDATE_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'DW_UPDATE_BY' NOT NULL)
PRIMARY INDEX XPKTBSPLESPL_BOM_EPE ( PARENT_DRAWING_NO ,MEMBER_DRAWING_NO );
SET RECORD VARTEXT "|";
RECORD 2;

define

 PARENT_CLASS                  (VARCHAR(19)),
 PARENT_DRAWING_NO             (VARCHAR(30)),
 REVISION                      (VARCHAR(10)),
 CHILD_CLASS                   (VARCHAR(19)),
 MEMBER_DRAWING_NO             (VARCHAR(30)),
 ITEM_NO                       (VARCHAR(10)),
 DWG_AREA                      (VARCHAR(10)),
 LINK_CLASS                    (VARCHAR(19)),
 QUANTITY                      (VARCHAR(19)),
 UOM                           (VARCHAR(10))


 file=/data/informatica/ETCOE/EEDW01/SrcFiles/EPE_BOM_frozen.lst;

show;

begin loading ${Stg_database}.CDR_ESPL_BOM_EPE_HST  errorfiles ${Stg_database}.ET_CDR_ESPL_BOM_EPE_HST , ${Stg_database}.UV_CDR_ESPL_BOM_EPE_HST 
checkpoint 0 ;

INSERT INTO ${Stg_database}.CDR_ESPL_BOM_EPE_HST  ( 
 PARENT_CLASS                          ,
 PARENT_DRAWING_NO                     ,
 REVISION                              ,
 CHILD_CLASS                           ,
 MEMBER_DRAWING_NO                     ,
 ITEM_NO                               ,
 DWG_AREA                              ,
 LINK_CLASS                            ,
 QUANTITY                              ,
 UOM                                   ,
 HIST_FLG                        ,
DW_LOAD_DATE                            , 
DW_CREATED_BY                           , 
DW_UPDATE_DATE                          , 
DW_UPDATE_BY                            
) VALUES ( 
 :PARENT_CLASS                          ,
 :PARENT_DRAWING_NO                     ,
 :REVISION                              ,
 :CHILD_CLASS                           ,
 :MEMBER_DRAWING_NO                     ,
 :ITEM_NO                               ,
 :DWG_AREA                              ,
 :LINK_CLASS                            ,
 :QUANTITY                              ,
 :UOM                                    , 
'Y'                                ,
date                           , 
'CDR'                          , 
date                           , 
'CDR'                          
) ; 


end loading;

logoff;
eof
