##################################################################################################################################
##																		    ##	
##																		    ##	
##	This script																    ##
##	1) This Script takes specified Hrs. prior to the current date value and puts the resulting value in the parameter file.  ##
##																		    ##	
##	  																           ##			
##################################################################################################################################


# DECLARING A VARIABLE WHICH TAKES THE DESIRED BUFFER TIME #
hour_value='30' 
# GETTING CURRENT SYSTEM DATE MINUS BUFFER TIME #
DT=`date --date="$hour_value hours ago" +'%m/%d/%Y %r'`
# GETTING THE NEW STRING WITH CURRENT DATE WITH BUFFER VALUE #
new_dt="\$\$LAST_RUN_DATE="$DT
# REPLACING THE LINES WHICH CONTAIN THE STRING "LAST_RUN_DATE=" WITH NEW DATE #
sed -i "/LAST_RUN_DATE=/ c $new_dt" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_BAAN_STAGE.txt
exit 0;











