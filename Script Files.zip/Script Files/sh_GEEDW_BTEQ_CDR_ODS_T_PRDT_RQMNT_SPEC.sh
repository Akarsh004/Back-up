# ---------------------------------------------------------------------------- 
#
# File: sh_GEEDW_BTEQ_CDR_ODS_T_PRDT_RQMNT_SPEC.sh 
# Creation Date: 09/20/11  
# Last Modified: 09/20/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */ 

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;    */

database ${Stg_database};

-- Table: CDR_ODS_T_PRDT_RQMNT_SPEC : Start

---- DROP TABLE VT_CDR_ODS_T_PRDT_RQMNT_SPEC ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_PRDT_RQMNT_SPEC ,NO LOG (
      ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OWNER_COL VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD' ,
      SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD',
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ACCESS_TYPE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GE_SHEET_SIZE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      MOVE_FILES_TO_VERSION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FILE_VERSION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      ORIG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DESIGNATED_USER VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      VERSION_DT DATE FORMAT 'YYYY-MM-DD',
      TITLE_COL VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      NOTES VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      SUSPEND_VERSIONING VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      LANG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      SYNOPSIS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      VERSION VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OBJECTIVE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      CHECKIN_REASON VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
      IS_VERSION_OBJECT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CLAU VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC 
      )

 



PRIMARY INDEX (ID) ON COMMIT PRESERVE ROWS;
-- Table: CDR_ODS_T_PRDT_RQMNT_SPEC  : Processing : Populate GT table with CDC data

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_PRDT_RQMNT_SPEC
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ACCESS_TYPE                   ,
GE_SHEET_SIZE                 ,
MOVE_FILES_TO_VERSION         ,
FILE_VERSION                  ,
ORIG                          ,
DESIGNATED_USER               ,
VERSION_DT                    ,
TITLE_COL                     ,
NOTES                         ,
SUSPEND_VERSIONING            ,
LANG                          ,
SYNOPSIS                      ,
VERSION                       ,
OBJECTIVE                     ,
CHECKIN_REASON                ,
IS_VERSION_OBJECT             ,
CLAU                          ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 

)
       select
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ACCESS_TYPE                   ,
GE_SHEET_SIZE                 ,
MOVE_FILES_TO_VERSION         ,
FILE_VERSION                  ,
ORIG                          ,
DESIGNATED_USER               ,
VERSION_DT                    ,
TITLE_COL                     ,
NOTES                         ,
SUSPEND_VERSIONING            ,
LANG                          ,
SYNOPSIS                      ,
VERSION                       ,
OBJECTIVE                     ,
CHECKIN_REASON                ,
IS_VERSION_OBJECT             ,
CLAU                          ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_ODS_T_PRDT_RQMNT_SPEC_S
MINUS
SELECT

ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ACCESS_TYPE                   ,
GE_SHEET_SIZE                 ,
MOVE_FILES_TO_VERSION         ,
FILE_VERSION                  ,
ORIG                          ,
DESIGNATED_USER               ,
VERSION_DT                    ,
TITLE_COL                     ,
NOTES                         ,
SUSPEND_VERSIONING            ,
LANG                          ,
SYNOPSIS                      ,
VERSION                       ,
OBJECTIVE                     ,
CHECKIN_REASON                ,
IS_VERSION_OBJECT             ,
CLAU                          ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_PRDT_RQMNT_SPEC ;



-- Table: VT_CDR_ODS_T_PRDT_RQMNT_SPEC  : Processing : Populate Stage table with CDC data only for mLDM processing

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_PRDT_RQMNT_SPEC_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_PRDT_RQMNT_SPEC_S
(
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ACCESS_TYPE                   ,
GE_SHEET_SIZE                 ,
MOVE_FILES_TO_VERSION         ,
FILE_VERSION                  ,
ORIG                          ,
DESIGNATED_USER               ,
VERSION_DT                    ,
TITLE_COL                     ,
NOTES                         ,
SUSPEND_VERSIONING            ,
LANG                          ,
SYNOPSIS                      ,
VERSION                       ,
OBJECTIVE                     ,
CHECKIN_REASON                ,
IS_VERSION_OBJECT             ,
CLAU                          ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT
                       
ID                            ,
NAME                          ,
REVISION                      ,
VAULT                         ,
OWNER_COL                     ,
DESCRIPTION                   ,
POLICY                        ,
STATE                         ,
PREVIOUS_REVISION_ID          ,
NEXT_REVISION_ID              ,
FIRST_REVISION_ID             ,
LATEST_REVISION_ID            ,
CREATED_BY                    ,
CREATION_DATE                 ,
LAST_UPDATED_BY               ,
LAST_UPDATE_DATE              ,
SOURCE_MODIFIED_DATE          ,
SOURCE_ORIGINATED_DATE        ,
ALTOWNER1                     ,
ALTOWNER2                     ,
ACCESS_TYPE                   ,
GE_SHEET_SIZE                 ,
MOVE_FILES_TO_VERSION         ,
FILE_VERSION                  ,
ORIG                          ,
DESIGNATED_USER               ,
VERSION_DT                    ,
TITLE_COL                     ,
NOTES                         ,
SUSPEND_VERSIONING            ,
LANG                          ,
SYNOPSIS                      ,
VERSION                       ,
OBJECTIVE                     ,
CHECKIN_REASON                ,
IS_VERSION_OBJECT             ,
CLAU                          ,
CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE                 
,'CDR'          
         



             
FROM VT_CDR_ODS_T_PRDT_RQMNT_SPEC ;


-- Table: CDR_ODS_T_PRDT_RQMNT_SPEC  : End



























