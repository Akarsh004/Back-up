		#######################################   SCRIPT NAME : sh_wflw_EEDW09_GVL_PCF_STG_ksh.sh   ####################################
		#					Developer: MSAT							#
		#					Date : 9/10/2012						#
		#########################################################################################################	

### DEFAULT SERVER PATH
ServerPath=/data/informatica/ETCOE/EEDW01

#SCRIPT PATH
Scriptpath=$ServerPath/ScriptFiles/

#PARAM DIRECTORY
parampath=$ServerPath/Config/

#CHANGE TO CONFIG DIRECTORY
cd $parampath

#DATE STORING IN VARIABLE
sys_date=`date +'%d'`

# DECLARATION OF 
PARAM=$parampath/PARAM_EP6_STG_BASE.txt
PARAM_temp=$parampath/PARAM_EP6_STG_BASE_temp.txt

# CONNECT TO DB TO GET THE MAX BTCH_LD_ID

CONNECT()
{
db_connectstring=SSO502129233/tke59Svq@EUEOLTP9	## PROD
pr_chk=$Scriptpath/pr_chk.txt
try=`sqlplus -s  $db_connectstring<<!
        set heading  off
        spool $pr_chk
select  max(BTCH_SEQ_ID)||','||max(to_char(CRTN_DT,'mm/dd/yyyy')) from FCD_BTCH;
        spool out;
!`
}

# CALL DB FUNCTION
CONNECT

# GET THE CURREBT BTCH_LD_ID VALUE
CURNT_BTCH_LD_ID=`cat $pr_chk|tr -d ' '|tr -d '\n'`
echo "CURNT_BTCH_LD_ID=$CURNT_BTCH_LD_ID"

#VALUE OF BTCH_LD_ID
date_var=`echo $CURNT_BTCH_LD_ID|awk -F"," '{print $1}'`
echo "date_var=$date_var"

#LAST LOAD DATE OF THE BTCH_LD_ID
date_tab1=`echo $CURNT_BTCH_LD_ID|awk -F"," '{print $2}'`
echo "date_tab1=$date_tab1"

#EXACT DATE VALUE
date_tab=`echo $date_tab1|awk -F"/" '{print $2}'`
echo "date_tab=$date_tab"

#EXISTING VALUES OF BTCH_LD_ID FROM PARAM FILE
TXT1=`cat $PARAM | grep "BTCH_LD_ID=" | head -1` 
FTXT1=`cat $PARAM | grep "BTCH_LD_ID=" | awk -F"=" '{print $1}' | head -1` 
FTXT2=`cat $PARAM | grep "BTCH_LD_ID=" | awk -F"=" '{print $2}' | head -1` 

#COMPARING THE DATES AND DO THE MODIFICATIONS IN PARAM FILE WITH NEW BTCH_LD_ID
if [ $date_tab != "" ] ; then
echo "1.date_tab=$date_tab"
if [ $date_tab -ne $sys_date ] ; then
NTXT=`expr ${date_var} + 1`	
echo "$NTXT"
sed "s/$TXT1/$FTXT1"="$NTXT/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM
else 
NTXT=$date_var
sed "s/$TXT1/$FTXT1"="$NTXT/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM
fi
else 
NTXT=1
sed "s/$TXT1/$FTXT1"="$NTXT/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM
fi

#DATE VARIABLE
dt=`date +'%d-%m-%Y %r'`

#GET THE EXISTING VALYE OF THE START DATE
Last_date_var=`cat $PARAM|grep START_DATE`
echo "$Last_date_var"
curn_lst_val=`echo $Last_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_val"
date_lst_tab1=`echo $Last_date_var|awk -F"=" '{print $2}'`

#REPLACING THE START DATE WITH NEW DATE
sed "s/$Last_date_var/$curn_lst_val"="$dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM
