.RUN File '/apps/informatica/product/pc/bin/td_plp.mlbt';
DATABASE plp_t;
BEGIN LOADING IMSSTATS ERRORFILES IMSSTATS_errors1, IMSSTATS_errors2 INDICATORS;
AXSMOD Oledb_Axsmod "noprompt";
DEFINE STATID	(VARCHAR(30)),
       TYPE	(CHAR(1)),
       VERSION	(DECIMAL(9,0)),
       FLAGS	(DECIMAL(9,0)),
       C1	(VARCHAR(30)),
       C2	(VARCHAR(30)),
       C3	(VARCHAR(30)),
       C4	(VARCHAR(30)),
       C5	(VARCHAR(30)),
       N1	(DECIMAL(9,0)),
       N2	(DECIMAL(9,0)),
       N3	(DECIMAL(9,0)),
       N4	(DECIMAL(9,0)),
       N5	(DECIMAL(9,0)),
       N6	(DECIMAL(9,0)),
       N7	(DECIMAL(9,0)),
       N8	(DECIMAL(9,0)),
       N9	(DECIMAL(9,0)),
       N10	(DECIMAL(9,0)),
       N11	(DECIMAL(9,0)),
       N12	(DECIMAL(9,0)) 
       FILE=/data/plp/informatica/ScriptFiles/IMSSTATS.txt;
INSERT INTO IMSSTATS ( STATID, TYPE, VERSION, FLAGS, C1, C2, C3, C4, C5, N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, DW_LOAD_DATE, DW_CREATED_BY, DW_UPDATED_DATE, DW_UPDATED_BY)
 VALUES ( :STATID, :TYPE, :VERSION, :FLAGS, :C1, :C2, :C3, :C4, :C5, :N1, :N2, :N3, :N4, :N5, :N6, :N7, :N8, :N9, :N10, :N11, :N12,DATE,'CDR', DATE,'CDR') ;
END LOADING ;
LOGOFF ;