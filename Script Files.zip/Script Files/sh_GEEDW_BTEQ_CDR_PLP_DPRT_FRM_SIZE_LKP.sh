# ---------------------------------------------------------------------------- 
# File: sh_GEEDW_BTEQ_CDR_PLP_DPRT_FRM_SIZE_LKP.sh 
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
 /* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_PLP_DPRT_FRM_SIZE_LKP  : Start

 DROP TABLE VT_CDR_PLP_DPRT_FRM_SIZE_LKP ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */
 CREATE VOLATILE TABLE VT_CDR_PLP_DPRT_FRM_SIZE_LKP,NO LOG (
      FRAME_SIZE_SEQ_ID INTEGER  NOT NULL,
      FRAME_SIZE VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC ,
      COMB CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      HGP CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
      GEN CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
      STEAM CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
      FLEXIFIELD1 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'MM/DD/YYYY'  NOT NULL,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      LAST_UPDATED_DATE DATE FORMAT 'MM/DD/YYYY' NOT NULL,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX  ( FRAME_SIZE_SEQ_ID );

---Table: CDR_PLP_DPRT_FRM_SIZE_LKP : Processing : Populate GT table with CDC data 

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_DPRT_FRM_SIZE_LKP
(
FRAME_SIZE_SEQ_ID             ,
FRAME_SIZE                    ,
COMB                          ,
HGP                           ,
GEN                           ,
STEAM                         ,
FLEXIFIELD1                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
FRAME_SIZE_SEQ_ID             ,
FRAME_SIZE                    ,
COMB                          ,
HGP                           ,
GEN                           ,
STEAM                         ,
FLEXIFIELD1                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_PLP_DPRT_FRM_SIZE_LKP_S
MINUS
SELECT 
FRAME_SIZE_SEQ_ID             ,
FRAME_SIZE                    ,
COMB                          ,
HGP                           ,
GEN                           ,
STEAM                         ,
FLEXIFIELD1                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_BULK_T.CDR_PLP_DPRT_FRM_SIZE_LKP;


----Table: CDR_PLP_DPRT_FRM_SIZE_LKP : Processing : Populate Stage table with CDC data only for mLDM processing  

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_DPRT_FRM_SIZE_LKP_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_DPRT_FRM_SIZE_LKP_S
(
FRAME_SIZE_SEQ_ID             ,
FRAME_SIZE                    ,
COMB                          ,
HGP                           ,
GEN                           ,
STEAM                         ,
FLEXIFIELD1                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
FRAME_SIZE_SEQ_ID             ,
FRAME_SIZE                    ,
COMB                          ,
HGP                           ,
GEN                           ,
STEAM                         ,
FLEXIFIELD1                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
CURRENT_DATE,                  
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_DPRT_FRM_SIZE_LKP;


---Table: CDR_PLP_DPRT_FRM_SIZE_LKP : End

