// ---------------------------------------------------------------------------- 
//			
// File: sh_GEEDW_BTEQ_CDR_PEG_TCCE_APPROVER.sh 
// Creation Date: 04/12/10 
// Last Modified: 04/12/10
// Purpose:CDC Implementation on the Staging and Bulk databases
// Created By: Smruti/Tarkesh
//
// ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/*.RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

	
CREATE VOLATILE TABLE VT_CDR_ODS_MXSTATEREQ ,NO LOG (
	              MXSTATEREQ VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
		      MXSTATEREQ_OID INTEGER,
		      POLICY_OID INTEGER,
		      STATE_SEQUENCE INTEGER)
	PRIMARY INDEX ( MXSTATEREQ ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_MXPOLICY : Processing : Populate GT table with CDC data	



INSERT INTO VT_CDR_ODS_MXSTATEREQ
(	
MXSTATEREQ,                    
MXSTATEREQ_OID,                
POLICY_OID,                    
STATE_SEQUENCE              
)
SELECT 
MXSTATEREQ,                    
MXSTATEREQ_OID,                
POLICY_OID,                    
STATE_SEQUENCE                
FROM GEEDW_PLP_S.CDR_ODS_MXSTATEREQ_S	
MINUS
SELECT
MXSTATEREQ,                    
MXSTATEREQ_OID,                
POLICY_OID,                    
STATE_SEQUENCE                
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_MXSTATEREQ;	


DELETE GEEDW_PLP_S.CDR_ODS_MXSTATEREQ_S;	


INSERT INTO GEEDW_PLP_S.CDR_ODS_MXSTATEREQ_S
(	
MXSTATEREQ,                    
MXSTATEREQ_OID,                
POLICY_OID,                    
STATE_SEQUENCE, 
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY
)	
SELECT 
MXSTATEREQ,                    
MXSTATEREQ_OID,                
POLICY_OID,                    
STATE_SEQUENCE,   
CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_ODS_MXSTATEREQ;	

