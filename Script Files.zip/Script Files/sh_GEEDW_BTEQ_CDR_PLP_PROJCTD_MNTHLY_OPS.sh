# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PROJCTD_MNTHLY_OPS.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_PROJCTD_MNTHLY_OPS : Start	

---- DROP TABLE VT_CDR_PLP_PROJCTD_MNTHLY_OPS;	

CREATE VOLATILE TABLE VT_CDR_PLP_PROJCTD_MNTHLY_OPS,NO LOG (
      TURBINE_NUMBER VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      PROJECTIONS_AS_OF_DATE DATE FORMAT 'YYYY-MM-DD',
      HOURS DECIMAL(26,8),
      OIL_HRS DECIMAL(26,8),
      STARTS DECIMAL(26,8),
      TRIPS DECIMAL(26,8),
      SERVICE_FACTOR DECIMAL(26,8),
      CODE INTEGER,
      PROJECTED_HRS DECIMAL(26,8),
      PROJECTED_OIL_HRS DECIMAL(26,8),
      PROJECTED_STARTS DECIMAL(26,8),
      PROEJECTED_TRIPS DECIMAL(26,8),
      PROJECTED_DAYS_OF_TRIP INTEGER,
      PROJECTED_DATE DATE FORMAT 'YYYY-MM-DD',
      FIRED_HRS DECIMAL(26,8),
      FIRED_STARTS DECIMAL(26,8),
      N_HOURS DECIMAL(26,8),
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PROJECTIONS_AS_OF_DATE ) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_PROJCTD_MNTHLY_OPS
(
TURBINE_NUMBER,                
PROJECTIONS_AS_OF_DATE,        
HOURS,                         
OIL_HRS,                       
STARTS,                        
TRIPS,                         
SERVICE_FACTOR,                
CODE,                          
PROJECTED_HRS,                 
PROJECTED_OIL_HRS,             
PROJECTED_STARTS,              
PROEJECTED_TRIPS,              
PROJECTED_DAYS_OF_TRIP,        
PROJECTED_DATE,                
FIRED_HRS,                     
FIRED_STARTS,                  
N_HOURS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                 
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                 
)
SELECT	
TURBINE_NUMBER,                
PROJECTIONS_AS_OF_DATE,        
HOURS,                         
OIL_HRS,                       
STARTS,                        
TRIPS,                         
SERVICE_FACTOR,                
CODE,                          
PROJECTED_HRS,                 
PROJECTED_OIL_HRS,             
PROJECTED_STARTS,              
PROEJECTED_TRIPS,              
PROJECTED_DAYS_OF_TRIP,        
PROJECTED_DATE,                
FIRED_HRS,                     
FIRED_STARTS,                  
N_HOURS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                 
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY  
FROM	 GEEDW_PLP_S.CDR_PLP_PROJCTD_MNTHLY_OP_S
MINUS
SELECT	
TURBINE_NUMBER,                
PROJECTIONS_AS_OF_DATE,        
HOURS,                         
OIL_HRS,                       
STARTS,                        
TRIPS,                         
SERVICE_FACTOR,                
CODE,                          
PROJECTED_HRS,                 
PROJECTED_OIL_HRS,             
PROJECTED_STARTS,              
PROEJECTED_TRIPS,              
PROJECTED_DAYS_OF_TRIP,        
PROJECTED_DATE,                
FIRED_HRS,                     
FIRED_STARTS,                  
N_HOURS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                 
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY  
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PROJCTD_MNTHLY_OPS;

-- Table: VT_CDR_PLP_PROJCTD_MNTHLY_OPS : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PROJCTD_MNTHLY_OP_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PROJCTD_MNTHLY_OP_S
(	
TURBINE_NUMBER,                
PROJECTIONS_AS_OF_DATE,        
HOURS,                         
OIL_HRS,                       
STARTS,                        
TRIPS,                         
SERVICE_FACTOR,                
CODE,                          
PROJECTED_HRS,                 
PROJECTED_OIL_HRS,             
PROJECTED_STARTS,              
PROEJECTED_TRIPS,              
PROJECTED_DAYS_OF_TRIP,        
PROJECTED_DATE,                
FIRED_HRS,                     
FIRED_STARTS,                  
N_HOURS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                 
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY  
)	
SELECT 
TURBINE_NUMBER,                
PROJECTIONS_AS_OF_DATE,        
HOURS,                         
OIL_HRS,                       
STARTS,                        
TRIPS,                         
SERVICE_FACTOR,                
CODE,                          
PROJECTED_HRS,                 
PROJECTED_OIL_HRS,             
PROJECTED_STARTS,              
PROEJECTED_TRIPS,              
PROJECTED_DAYS_OF_TRIP,        
PROJECTED_DATE,                
FIRED_HRS,                     
FIRED_STARTS,                  
N_HOURS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                                                                            CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PROJCTD_MNTHLY_OPS;	

-- Table: CDR_PLP_PROJCTD_MNTHLY_OPS : End




