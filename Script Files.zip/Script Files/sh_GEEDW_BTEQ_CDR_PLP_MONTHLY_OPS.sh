# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_MONTHLY_OPS.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_MONTHLY_OPS : Start	

---- DROP TABLE VT_CDR_PLP_MONTHLY_OPS;	

CREATE VOLATILE TABLE VT_CDR_PLP_MONTHLY_OPS,NO LOG (
      TURBINE_NUMBER VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OPERATIONS_DATE DATE FORMAT 'YY/MM/DD',
      TURBINE_HOURS FLOAT,
      STARTS INTEGER,
      PERIOD_HRS FLOAT,
      PERIOD_STARTS INTEGER,
      SERVICE_FACTOR FLOAT,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( TURBINE_NUMBER ,OPERATIONS_DATE ) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_MONTHLY_OPS 
(
TURBINE_NUMBER,                
OPERATIONS_DATE,               
TURBINE_HOURS,                 
STARTS,                        
PERIOD_HRS,                    
PERIOD_STARTS,                 
SERVICE_FACTOR,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                        
)
SELECT	
TURBINE_NUMBER,                
OPERATIONS_DATE,               
TURBINE_HOURS,                 
STARTS,                        
PERIOD_HRS,                    
PERIOD_STARTS,                 
SERVICE_FACTOR,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY         
FROM	 GEEDW_PLP_S.CDR_PLP_MONTHLY_OPS_S
MINUS
SELECT	
TURBINE_NUMBER,                
OPERATIONS_DATE,               
TURBINE_HOURS,                 
STARTS,                        
PERIOD_HRS,                    
PERIOD_STARTS,                 
SERVICE_FACTOR,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY  
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_MONTHLY_OPS;

-- Table: VT_CDR_PLP_MONTHLY_OPS : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_MONTHLY_OPS_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_MONTHLY_OPS_S 
(	
TURBINE_NUMBER,                
OPERATIONS_DATE,               
TURBINE_HOURS,                 
STARTS,                        
PERIOD_HRS,                    
PERIOD_STARTS,                 
SERVICE_FACTOR,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                        
)	
SELECT 
TURBINE_NUMBER,                
OPERATIONS_DATE,               
TURBINE_HOURS,                 
STARTS,                        
PERIOD_HRS,                    
PERIOD_STARTS,                 
SERVICE_FACTOR,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
CURRENT_DATE,                                                                                                  
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_MONTHLY_OPS;	

-- Table: CDR_PLP_MONTHLY_OPS : End




