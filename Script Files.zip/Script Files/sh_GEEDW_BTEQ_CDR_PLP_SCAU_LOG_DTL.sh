# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_LOG_DTL.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Deepika
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_LOG_DTL : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_LOG_DTL;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_LOG_DTL ,NO LOG (

      PLP_SCAUTO_LOG_SEQ INTEGER ,
      LOGGIN_DATE DATE FORMAT 'YY/MM/DD' ,
      REQUESTED_VALUES INTEGER  ,
      RECIEVED_VALUES INTEGER  ,
      OSM_LISTED_VALUES INTEGER  ,
      OSM_POSSIBLE_VALUES INTEGER  ,
      OSM_REPORTING_VALUES INTEGER ,
      OSM_FIRED_HOURS INTEGER ,
      OSM_STARTS INTEGER ,
      OSM_TRIPS INTEGER ,
      BAD_FIRED_HOURS INTEGER ,
      BAD_STARTS INTEGER ,
      BAD_TRIPS INTEGER,
      CREATION_DATE DATE FORMAT 'YY/MM/DD' ,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC   )
PRIMARY INDEX  ( PLP_SCAUTO_LOG_SEQ )ON COMMIT PRESERVE ROWS;





INSERT INTO VT_CDR_PLP_SCAUTO_LOG_DTL
(

PLP_SCAUTO_LOG_SEQ,            
LOGGIN_DATE,                   
REQUESTED_VALUES ,             
RECIEVED_VALUES,               
OSM_LISTED_VALUES,             
OSM_POSSIBLE_VALUES,           
OSM_REPORTING_VALUES ,         
OSM_FIRED_HOURS,               
OSM_STARTS ,                   
OSM_TRIPS,                     
BAD_FIRED_HOURS,               
BAD_STARTS,                    
BAD_TRIPS,                         
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)

SELECT	

PLP_SCAUTO_LOG_SEQ,            
LOGGIN_DATE,                   
REQUESTED_VALUES ,             
RECIEVED_VALUES,               
OSM_LISTED_VALUES,             
OSM_POSSIBLE_VALUES,           
OSM_REPORTING_VALUES ,         
OSM_FIRED_HOURS,               
OSM_STARTS ,                   
OSM_TRIPS,                     
BAD_FIRED_HOURS,               
BAD_STARTS,                    
BAD_TRIPS,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY 

FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_LOG_DTL_S

MINUS

SELECT	

PLP_SCAUTO_LOG_SEQ,            
LOGGIN_DATE,                   
REQUESTED_VALUES ,             
RECIEVED_VALUES,               
OSM_LISTED_VALUES,             
OSM_POSSIBLE_VALUES,           
OSM_REPORTING_VALUES ,         
OSM_FIRED_HOURS,               
OSM_STARTS ,                   
OSM_TRIPS,                     
BAD_FIRED_HOURS,               
BAD_STARTS,                    
BAD_TRIPS,                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_LOG_DTL;

-- Table: VT_CDR_PLP_SCAUTO_LOG_DTL : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_LOG_DTL_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_LOG_DTL_S
(	
PLP_SCAUTO_LOG_SEQ,            
LOGGIN_DATE,                   
REQUESTED_VALUES ,             
RECIEVED_VALUES,               
OSM_LISTED_VALUES,             
OSM_POSSIBLE_VALUES,           
OSM_REPORTING_VALUES ,         
OSM_FIRED_HOURS,               
OSM_STARTS ,                   
OSM_TRIPS,                     
BAD_FIRED_HOURS,               
BAD_STARTS,                    
BAD_TRIPS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 

PLP_SCAUTO_LOG_SEQ,            
LOGGIN_DATE,                   
REQUESTED_VALUES ,             
RECIEVED_VALUES,               
OSM_LISTED_VALUES,             
OSM_POSSIBLE_VALUES,           
OSM_REPORTING_VALUES ,         
OSM_FIRED_HOURS,               
OSM_STARTS ,                   
OSM_TRIPS,                     
BAD_FIRED_HOURS,               
BAD_STARTS,                    
BAD_TRIPS,                           
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,  
CURRENT_DATE,       
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_LOG_DTL ;	

-- Table: CDR_PLP_SCAUTO_LOG_DTL : End




