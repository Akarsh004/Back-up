# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PLA_MAIN_DTL.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_PLA_MAIN_DTL : Start	

---- DROP TABLE VT_CDR_PLP_PLA_MAIN_DTL;	

CREATE VOLATILE TABLE VT_CDR_PLP_PLA_MAIN_DTL,NO LOG (
      PLA_MAIN_SEQ_ID INTEGER,
      CREATED_DATE_OF_RECORD DATE FORMAT 'YYYY-MM-DD',
      GRAPH_NAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      GRAPH_TYPE VARCHAR(21) CHARACTER SET LATIN NOT CASESPECIFIC,
      ANALYSIS_TYPE INTEGER,
      USER_NAME VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_TYPE VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      REPAIR_ORDER_NUM VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      DRAWING_NUM VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      AREA_NAME VARCHAR(700) CHARACTER SET LATIN NOT CASESPECIFIC,
      CONDITION_NAME VARCHAR(700) CHARACTER SET LATIN NOT CASESPECIFIC,
      UNINT_NAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      FRAME_NAME VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      SERIES_NAME VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      ENGINE_TECHNOLOGY VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      SERVICE_DATE VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      EXPOSURE_TYPE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CALC_TYPE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DATA_VALUE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      COMPONENT_FIELD VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      COMPONENT_TYPE VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      SITE_NAME VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PLA_MAIN_SEQ_ID ) ON COMMIT PRESERVE ROWS;

INSERT INTO VT_CDR_PLP_PLA_MAIN_DTL
(
PLA_MAIN_SEQ_ID,               
CREATED_DATE_OF_RECORD,        
GRAPH_NAME,                    
GRAPH_TYPE,                    
ANALYSIS_TYPE,                 
USER_NAME,                     
PART_TYPE,                     
REPAIR_ORDER_NUM,              
DRAWING_NUM,                   
AREA_NAME,                     
CONDITION_NAME,                
UNINT_NAME,                    
FRAME_NAME,                   
SERIES_NAME,                   
ENGINE_TECHNOLOGY,             
SERVICE_DATE,                  
EXPOSURE_TYPE,                 
CALC_TYPE,                     
DATA_VALUE,                    
COMPONENT_FIELD,               
COMPONENT_TYPE,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                                                     
)
SELECT	
PLA_MAIN_SEQ_ID,               
CREATED_DATE_OF_RECORD,        
GRAPH_NAME,                    
GRAPH_TYPE,                    
ANALYSIS_TYPE,                 
USER_NAME,                     
PART_TYPE,                     
REPAIR_ORDER_NUM,              
DRAWING_NUM,                   
AREA_NAME,                     
CONDITION_NAME,                
UNINT_NAME,                    
FRAME_NAME,                   
SERIES_NAME,                   
ENGINE_TECHNOLOGY,             
SERVICE_DATE,                  
EXPOSURE_TYPE,                 
CALC_TYPE,                     
DATA_VALUE,                    
COMPONENT_FIELD,               
COMPONENT_TYPE,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY        
FROM	 GEEDW_PLP_S.CDR_PLP_PLA_MAIN_DTL_S
MINUS
SELECT	
PLA_MAIN_SEQ_ID,               
CREATED_DATE_OF_RECORD,        
GRAPH_NAME,                    
GRAPH_TYPE,                    
ANALYSIS_TYPE,                 
USER_NAME,                     
PART_TYPE,                     
REPAIR_ORDER_NUM,              
DRAWING_NUM,                   
AREA_NAME,                     
CONDITION_NAME,                
UNINT_NAME,                    
FRAME_NAME,                   
SERIES_NAME,                   
ENGINE_TECHNOLOGY,             
SERVICE_DATE,                  
EXPOSURE_TYPE,                 
CALC_TYPE,                     
DATA_VALUE,                    
COMPONENT_FIELD,               
COMPONENT_TYPE,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY        
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PLA_MAIN_DTL;

-- Table: VT_CDR_PLP_PLA_MAIN_DTL : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PLA_MAIN_DTL_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PLA_MAIN_DTL_S
(	
PLA_MAIN_SEQ_ID,               
CREATED_DATE_OF_RECORD,        
GRAPH_NAME,                    
GRAPH_TYPE,                    
ANALYSIS_TYPE,                 
USER_NAME,                     
PART_TYPE,                     
REPAIR_ORDER_NUM,              
DRAWING_NUM,                   
AREA_NAME,                     
CONDITION_NAME,                
UNINT_NAME,                    
FRAME_NAME,                   
SERIES_NAME,                   
ENGINE_TECHNOLOGY,             
SERVICE_DATE,                  
EXPOSURE_TYPE,                 
CALC_TYPE,                     
DATA_VALUE,                    
COMPONENT_FIELD,               
COMPONENT_TYPE,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY        
)	
SELECT 
PLA_MAIN_SEQ_ID,               
CREATED_DATE_OF_RECORD,        
GRAPH_NAME,                    
GRAPH_TYPE,                    
ANALYSIS_TYPE,                 
USER_NAME,                     
PART_TYPE,                     
REPAIR_ORDER_NUM,              
DRAWING_NUM,                   
AREA_NAME,                     
CONDITION_NAME,                
UNINT_NAME,                    
FRAME_NAME,                   
SERIES_NAME,                   
ENGINE_TECHNOLOGY,             
SERVICE_DATE,                  
EXPOSURE_TYPE,                 
CALC_TYPE,                     
DATA_VALUE,                    
COMPONENT_FIELD,               
COMPONENT_TYPE,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                                                                                                                    CURRENT_DATE,                                                                                            
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PLA_MAIN_DTL;	

-- Table: CDR_PLP_PLA_MAIN_DTL : End




