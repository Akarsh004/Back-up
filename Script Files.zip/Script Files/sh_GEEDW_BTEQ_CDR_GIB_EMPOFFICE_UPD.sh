# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_EMPOFFICE.sh 
# Creation Date: 07/29/10 
# Last Modified: 07/29/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_GIB_EMPOFFICE : Start	

---- DROP TABLE VT_CDR_GIB_EMPOFFICE;	


CREATE VOLATILE TABLE VT_CDR_GIB_EMPOFFICE ,NO LOG (
	      USERID VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ORGANIZATION_CODE VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
	      EMPLOYEE_CODE VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
	      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
	      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
	      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
	      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX ( USERID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_GIB_EMPOFFICE : Processing : Populate GT table with CDC data	

INSERT INTO VT_CDR_GIB_EMPOFFICE 
(
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE
)
SELECT 
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE
FROM GEEDW_PLP_S.CDR_GIB_EMPOFFICE	
MINUS
SELECT 
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE
FROM GEEDW_PLP_BULK_T.CDR_GIB_EMPOFFICE;	


-- Table: VT_CDR_GIB_EMPOFFICE : Processing : Populate Stage table with CDC data only for mLDM processing	

DELETE GEEDW_PLP_S.CDR_GIB_EMPOFFICE;	


INSERT INTO GEEDW_PLP_S.CDR_GIB_EMPOFFICE 
(	
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE,                 
DW_LOAD_DATE,                  
DW_CREATED_BY,                
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
USERID,                        
ORGANIZATION_CODE,             
EMPLOYEE_CODE,                 
CURRENT_DATE,
'GIB',
CURRENT_DATE,
'GIB'
FROM VT_CDR_GIB_EMPOFFICE;	


-- Table: CDR_GIB_EMPOFFICE : End




