##########################################################################################
##############################created by Mahindra Satyam #################################
##############################created date : 27th Oct 2010 ##############################
##############################Reviewed by :Smruti Patnaik ################################
##############################Purpose : Appending Flat Files #############################
########################################################################################## 

cd /data/informatica/ETCOE/EEDW01/SrcFiles/
rm -f BMIT.txt
cat /data/informatica/ETCOE/EEDW01/SrcFiles/ITEM_DAILY_P3.TXT > /data/informatica/ETCOE/EEDW01/SrcFiles/BMIT.txt
cat /data/informatica/ETCOE/EEDW01/SrcFiles/ITEM_DAILY_P5.TXT >> /data/informatica/ETCOE/EEDW01/SrcFiles/BMIT.txt
rm -f ITEM_DAILY_P3.TXT
rm -f ITEM_DAILY_P5.TXT
chmod 777 BMIT.txt

