# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DEPART_TECH_REC.sh 
# Creation Date: 10/28/2011 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_DEPART_TECH_REC : Start	

---- DROP TABLE VT_CDR_PLP_DEPART_TECH_REC;	

CREATE VOLATILE TABLE VT_CDR_PLP_DEPART_TECH_REC,NO LOG (
      DEPART_FORM_SEQ_ID INTEGER ,
      SUBMIT_DATE DATE FORMAT 'YYYY-MM-DD' ,
      CREATOR_ID INTEGER ,
      APPROVAL_FLAG INTEGER,
      APPROVAL_DATE DATE FORMAT 'YYYY-MM-DD',
      APPROVER_ID INTEGER,
      USER_COMMENTS VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ADMIN_CLOSE_FLAG INTEGER ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX  (DEPART_FORM_SEQ_ID ) ON COMMIT PRESERVE ROWS;



INSERT INTO VT_CDR_PLP_DEPART_TECH_REC
(
DEPART_FORM_SEQ_ID            
,SUBMIT_DATE                   
,CREATOR_ID                    
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,APPROVER_ID                   
,USER_COMMENTS                 
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,ADMIN_CLOSE_FLAG              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
)
SELECT
DEPART_FORM_SEQ_ID            
,SUBMIT_DATE                   
,CREATOR_ID                    
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,APPROVER_ID                   
,USER_COMMENTS                 
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,ADMIN_CLOSE_FLAG              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY   
FROM GEEDW_PLP_S.CDR_PLP_DEPART_TECH_REC_S
MINUS
SELECT	
DEPART_FORM_SEQ_ID            
,SUBMIT_DATE                   
,CREATOR_ID                    
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,APPROVER_ID                   
,USER_COMMENTS                 
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,ADMIN_CLOSE_FLAG              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY          
FROM GEEDW_PLP_BULK_T.CDR_PLP_DEPART_TECH_REC;

-- Table: VT_CDR_PLP_DEPART_TECH_REC  : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_DEPART_TECH_REC_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_DEPART_TECH_REC_S
(	
DEPART_FORM_SEQ_ID            
,SUBMIT_DATE                   
,CREATOR_ID                    
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,APPROVER_ID                   
,USER_COMMENTS                 
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,ADMIN_CLOSE_FLAG              
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY   
)	
SELECT 
DEPART_FORM_SEQ_ID            
,SUBMIT_DATE                   
,CREATOR_ID                    
,APPROVAL_FLAG                 
,APPROVAL_DATE                 
,APPROVER_ID                   
,USER_COMMENTS                 
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,ADMIN_CLOSE_FLAG              
,CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE               
,'CDR'   
FROM VT_CDR_PLP_DEPART_TECH_REC;		

-- Table: CDR_PLP_DEPART_TECH_REC : End




