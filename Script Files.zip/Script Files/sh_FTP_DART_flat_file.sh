#bin bash
cd /data/informatica/ETCOE/EEDW01/PLMDrwgHeaderData/
cat /data/informatica/ETCOE/EEDW01/PLMDrwgHeaderData/ug_issue1.out >> /data/informatica/ETCOE/EEDW01/PLMDrwgHeaderData/ug_issue.rpt-`date +%m%y`
#gunzip ug_issue.rpt-`date +%m%y`.gz
sftp cdr_twd@Sftp.corporate.ge.com << EOF
cd /cdr/PLM/PLMDrwgHeaderData/
#put ug_issue.rpt-`date +%m%y`
put ug_issue.rpt-`date +%m%y`
quit
chmod 777 ug_issue.rpt-`date +%m%y`
EOF
