#########################################################################################
##      Script:sh_BTEQ_COLLECT_STATS_OSC_BULK.sh                                        ##
##      This script is used to collect stats of  CDR_OSC_ODS_ENGINE BULK table.         ##
##      Created by:Harsha T                                                             ##
##      Last Modified:16/10/12                                                          ##
##      Creation Date:13/10/12                                                          ##
##                                                                                      ##
#########################################################################################



. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq <<EOF

.RUN File = ${SrcDir}/td_plp.mlbt

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database GEEDW_PLP_S;



COLLECT STATS ON GEEDW_EP_BULK_T.CDR_OSC_ODS_ENGINE COLUMN (EQUIPMENT_SERIAL_NUMBER);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_OSC_ODS_ENGINE COLUMN (CONTRACT_NUMBER);


.LOGOFF
.EXIT 0
EOF

bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"
