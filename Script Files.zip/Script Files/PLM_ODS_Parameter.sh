DT=`date +'%m/%d/%Y'`
sed "s_LASTDATE_${DT}_g" /data/informatica/ETCOE/EEDW01/Config/ods_parameter.txt > /data/informatica/ETCOE/EEDW01/Config/PLM_ODS_Parameter_file.txt;
