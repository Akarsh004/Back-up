/* This is used for deleting records in stage tables for DCI */
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq  << eof 
.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;
/*.RUN File = ${SrcDir}/td_plp.mlbt*/

delete from GEEDW_PLP_S.CDR_DCI_ACTION;
delete from GEEDW_PLP_S.CDR_DCI_HEADER;
delete from GEEDW_PLP_S.CDR_DCI_STATUS;

.logoff            
.QUIT
eof