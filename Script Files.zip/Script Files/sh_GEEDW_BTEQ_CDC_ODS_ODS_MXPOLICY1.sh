// ---------------------------------------------------------------------------- 
//			
// File: sh_GEEDW_BTEQ_CDR_PEG_TCCE_APPROVER.sh 
// Creation Date: 04/12/10 
// Last Modified: 04/12/10
// Purpose:CDC Implementation on the Staging and Bulk databases
// Created By: Smruti/Tarkesh
//
// ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/*.RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

	
CREATE VOLATILE TABLE VT_CDR_ODS_MXPOLICY ,NO LOG (
	          POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
	          POLICY_OID INTEGER)
	PRIMARY INDEX ( POLICY ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_MXPOLICY : Processing : Populate GT table with CDC data	



INSERT INTO VT_CDR_ODS_MXPOLICY
(	
POLICY,                    
POLICY_OID                    
)
SELECT
POLICY,                    
POLICY_OID            
FROM GEEDW_PLP_S.CDR_ODS_MXPOLICY_S
MINUS
SELECT
POLICY,                    
POLICY_OID                
FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_MXPOLICY;	


DELETE GEEDW_PLP_S.CDR_ODS_MXPOLICY_S;	


INSERT INTO GEEDW_PLP_S.CDR_ODS_MXPOLICY_S
(	
POLICY,
POLICY_OID,   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY
)	
SELECT 
POLICY,                    
POLICY_OID,   
CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_ODS_MXPOLICY;	

