# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DPRT_ATA_LIST.sh 
# Creation Date: 10/28/2011 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_DPRT_ATA_LIST : Start	

---- DROP TABLE VT_CDR_PLP_DPRT_ATA_LIST;	

CREATE VOLATILE TABLE VT_CDR_PLP_DPRT_ATA_LIST,NO LOG (
      ATA_LIST_SEQ_ID INTEGER ,
      PROG_NUM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      REV_NUM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      FRAME_SIZE_SEQ_ID INTEGER ,
      DESIGNATION_SEQ_ID INTEGER,
      HARDWARE_GRP_SEQ_ID INTEGER ,
      REQUEST_SOURCE VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      STATUS VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      GIB_EXT_MFT_SEQ_ID INTEGER,
      CREATION_DATE DATE FORMAT 'MM/DD/YYYY',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'MM/DD/YYYY',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( ATA_LIST_SEQ_ID ) ON COMMIT PRESERVE ROWS ;


INSERT INTO VT_CDR_PLP_DPRT_ATA_LIST
(
ATA_LIST_SEQ_ID               
,PROG_NUM                      
,REV_NUM                       
,FRAME_SIZE_SEQ_ID             
,DESIGNATION_SEQ_ID            
,HARDWARE_GRP_SEQ_ID           
,REQUEST_SOURCE                
,STATUS                        
,DESCRIPTION                   
,GIB_EXT_MFT_SEQ_ID            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                         
)
SELECT
ATA_LIST_SEQ_ID               
,PROG_NUM                      
,REV_NUM                       
,FRAME_SIZE_SEQ_ID             
,DESIGNATION_SEQ_ID            
,HARDWARE_GRP_SEQ_ID           
,REQUEST_SOURCE                
,STATUS                        
,DESCRIPTION                   
,GIB_EXT_MFT_SEQ_ID            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY          
FROM GEEDW_PLP_S.CDR_PLP_DPRT_ATA_LIST_S
MINUS
SELECT	
ATA_LIST_SEQ_ID               
,PROG_NUM                      
,REV_NUM                       
,FRAME_SIZE_SEQ_ID             
,DESIGNATION_SEQ_ID            
,HARDWARE_GRP_SEQ_ID           
,REQUEST_SOURCE                
,STATUS                        
,DESCRIPTION                   
,GIB_EXT_MFT_SEQ_ID            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY          
FROM GEEDW_PLP_BULK_T.CDR_PLP_DPRT_ATA_LIST;

-- Table: VT_CDR_PLP_DPRT_ATA_LIST  : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_DPRT_ATA_LIST_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_DPRT_ATA_LIST_S
(	
ATA_LIST_SEQ_ID               
,PROG_NUM                      
,REV_NUM                       
,FRAME_SIZE_SEQ_ID             
,DESIGNATION_SEQ_ID            
,HARDWARE_GRP_SEQ_ID           
,REQUEST_SOURCE                
,STATUS                        
,DESCRIPTION                   
,GIB_EXT_MFT_SEQ_ID            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY          
)	
SELECT 
ATA_LIST_SEQ_ID               
,PROG_NUM                      
,REV_NUM                       
,FRAME_SIZE_SEQ_ID             
,DESIGNATION_SEQ_ID            
,HARDWARE_GRP_SEQ_ID           
,REQUEST_SOURCE                
,STATUS                        
,DESCRIPTION                   
,GIB_EXT_MFT_SEQ_ID            
,CREATION_DATE                 
,CREATED_BY                    
,LAST_UPDATED_DATE             
,LAST_UPDATED_BY               
,CURRENT_DATE                 
,'CDR'                 
,CURRENT_DATE               
,'CDR'          
FROM VT_CDR_PLP_DPRT_ATA_LIST;		

-- Table: CDR_PLP_DPRT_ATA_LIST : End




