# ----------------------------------------------------------------------#
# File: sh_GEEDW_BTEQ_BMLL_DATA.sh					#
# Creation Date: 13th-DEC-2012						#
# Last Modified: 13th-DEC-2012						#
# Purpose: Population of ML-,MPL-,DL-,					#
#367A Product Lines for DRAWING ITEMS BASE Load                         #
#-----------------------------------------------------------------------#
# Created By: Samrat Basumallik	                                        #
# Updated By: Sumanta Bhuajabal                                         #
# Last Modified: 21-FEB-2014						#
# Added ACTIVE_INDR hold the retired record set with 'H3','H5','MH'	#
# ----------------------------------------------------------------------#


bteq << eof
.RUN File = /data/informatica/ETCOE/EEDW01/SrcFiles/td_plp.mlbt 
.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;
database GEEDW_PLP_BULK_T;



-- Deletes data from Base BMLL Report target table
DELETE FROM GEEDW_PLP_BULK_T.MT_MBOM_ALL_LEVELS;

-- Base ONE TIME Load for BMLL Report

INSERT INTO GEEDW_PLP_BULK_T.MT_MBOM_ALL_LEVELS 
WITH     RECURSIVE HIER   
(
TOP_LEVEL_PARENT,
CNTNT_ITM_ID, 
PRNT_ITM_ID, 
HPIN_PARENT_PREFIX, 
MLI_CHILD_PREFIX, 
ITM_STD_CNTNT_STRT_DT,  
ITM_STD_CNTNT_END_DT, 
ITM_STD_ADD_REV_NUM,
ACTIVE_INDR,
LEVEL
) 
AS
(
SELECT 
B.ITM_ID_NUM AS TOP_LEVEL_PARENT,
A.CNTNT_ITM_ID, 
A.PRNT_ITM_ID,
A.CNTNT_ITM_PRFX_CD AS HPIN, 
A.CNTNT_ITM_PRFX_CD AS MLI, 
A.ITM_STD_CNTNT_STRT_DT, 
A.ITM_STD_CNTNT_END_DT, 
ITM_STD_ADD_REV_NUM, 
CASE   WHEN (A.ITM_STD_CNTNT_END_DT IS NULL OR A.ITM_STD_CNTNT_END_DT > CURRENT_DATE) THEN 'Y'
WHEN (A.ITM_STD_CNTNT_END_DT IS NOT NULL  AND  A.ITM_STD_CNTNT_END_DT <=  CURRENT_DATE) THEN  'N'
END AS ACTIVE_INDR,                      
1(INTEGER)
FROM GEEDW_PLP_T.ITEM_STANDARD_CONTENT A
INNER JOIN
GEEDW_PLP_T.ITEM_IDENTIFICATION  B
ON A.PRNT_ITM_ID   = B.ITM_ID
AND  B.ITM_IDNTFR_TYPE_CD = 'DWG' 
AND B.ITM_SRCE_TYPE_CD IN ('C3','C5','M','H3','H5','MH')
AND  B.ITM_ID_NUM LIKE ANY ('ML-%','MPL-%','DL-%','367A%' )
AND  SUBSTR(B.ITM_ID_NUM,1,4)  NOT IN ('ML-1','ML-2')
UNION
ALL
SELECT                               
C.TOP_LEVEL_PARENT,
B.CNTNT_ITM_ID, 
B.PRNT_ITM_ID, 
C.MLI_CHILD_PREFIX, 
B.CNTNT_ITM_PRFX_CD  , 
B.ITM_STD_CNTNT_STRT_DT,  
B.ITM_STD_CNTNT_END_DT, 
B.ITM_STD_ADD_REV_NUM, 
CASE       
   WHEN (C.ACTIVE_INDR = 'Y' AND (B.ITM_STD_CNTNT_END_DT IS NULL         OR          B.ITM_STD_CNTNT_END_DT > CURRENT_DATE) )
     THEN 'Y'
  WHEN (C.ACTIVE_INDR = 'Y' AND (B.ITM_STD_CNTNT_END_DT IS NOT NULL  AND  B.ITM_STD_CNTNT_END_DT <=  CURRENT_DATE) )
 THEN 'N'
 WHEN (C.ACTIVE_INDR='N') THEN 'N'
 END AS ACTIVE_INDR,                                               
C.LEVEL+1 
FROM    GEEDW_PLP_T.ITEM_STANDARD_CONTENT B, 
HIER C
WHERE B.PRNT_ITM_ID = C.CNTNT_ITM_ID 
                AND       C.CNTNT_ITM_ID > 0  
                AND       C.LEVEL < 30

)
SELECT                               
                H.TOP_LEVEL_PARENT AS TOP_LEVEL_PARENT,
                IDFN1.ITM_ID_NUM AS PARENT_ITEM, 
                IDFN2.ITM_ID_NUM AS CHILD_ITEM, 
                IDFN1.ITM_SRCE_TYPE_CD AS PRNT_ITM_SRCE_TYPE_CD ,
                IDFN2.ITM_SRCE_TYPE_CD AS CHILD_ITM_SRCE_TYPE_CD ,
                E.ITM_DESC AS DESCRIPTION,
                H.MLI_CHILD_PREFIX AS MLI, 
                H.HPIN_PARENT_PREFIX AS PIN, 
                H.ITM_STD_CNTNT_STRT_DT AS ITEM_EFFECTIVITY_START_DT,                            
                H.ITM_STD_CNTNT_END_DT AS ITEM_EFFECTIVITY_RETIRE_DT,                             
                ITEM_ADD_ECN.ADDECN AS AUTHECN,               
                  H.LEVEL AS LVL,
                CAST(current_timestamp(0 )AS timestamp(0) FORMAT 'MM/DD/YYYYBHH:MI:SS') AS DW_LOAD_DATE,  'CDR' AS DW_CREATED_BY ,
                CAST(current_timestamp(0 )AS timestamp(0) FORMAT 'MM/DD/YYYYBHH:MI:SS')  AS DW_UPDATED_DATE, 'CDR' AS DW_UPDATED_BY, 
                    H.ACTIVE_INDR AS ACTIVE_INDR                                      
                FROM HIER H
                LEFT OUTER JOIN GEEDW_PLP_T.ITEM_IDENTIFICATION IDFN1 
                                ON IDFN1.ITM_ID = H.PRNT_ITM_ID 
                                AND IDFN1.ITM_IDNTFR_TYPE_CD = 'DWG' 
                                AND IDFN1.ITM_SRCE_TYPE_CD IN ('C3','C5','M','H3','H5','MH')
                LEFT OUTER JOIN GEEDW_PLP_T.ITEM_IDENTIFICATION IDFN2 
                                ON IDFN2.ITM_ID = H.CNTNT_ITM_ID 
                                AND IDFN2.ITM_IDNTFR_TYPE_CD = 'DWG' 
                                AND IDFN2.ITM_SRCE_TYPE_CD  IN ('C3','C5','M','H3','H5','MH')
                LEFT OUTER JOIN           (
                SELECT EVITM.ITM_ID, 
                ADDDCE.DSGN_CHNG_EVNT_NUM, 
                ADDDCE.DSGN_CHNG_EVNT_RVSN_NUM 
                FROM GEEDW_PLP_T.EVENT_ITEM EVITM  
                INNER JOIN GEEDW_PLP_T.DESIGN_CHANGE_EVENT ADDDCE 
                ON EVITM.EVNT_ID = ADDDCE.DSGN_CHNG_EVNT_ID
                WHERE EVITM.EVNT_ITM_TYPE_CD = 'DECE'
                ) AS ITEM_ADD_ECN (ITEM_ID, ADDECN, ADDREV)
                ON  (H.PRNT_ITM_ID = ITEM_ADD_ECN.ITEM_ID 
                         AND H.ITM_STD_ADD_REV_NUM = ITEM_ADD_ECN.ADDREV)

                LEFT OUTER JOIN GEEDW_PLP_T.ITEM E
                ON H.CNTNT_ITM_ID= E.ITM_ID
                                                                GROUP BY 
                                                                TOP_LEVEL_PARENT              
                                                                ,PARENT_ITEM                   
                                                                ,CHILD_ITEM                    
                                                                ,PRNT_ITM_SRCE_TYPE_CD         
                                                                ,CHILD_ITM_SRCE_TYPE_CD        
                                                                ,DESCRIPTION                   
                                                                ,MLI                           
                                                                ,PIN                           
                                                                ,ITEM_EFFECTIVITY_START_DT     
                                                                ,ITEM_EFFECTIVITY_RETIRE_DT    
                                                                ,AUTHECN
                                                                ,ACTIVE_INDR                       
                                                                ,LVL                           
                                                                ,DW_LOAD_DATE                  
                                                                ,DW_CREATED_BY                 
                                                                ,DW_UPDATED_DATE               
                                                                ,DW_UPDATED_BY                 
;



.IF ERRORCODE <> 0 THEN .EXIT ERRORCODE;
.LOGOFF;
.EXIT;
eof