# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DEPART_COMPONENTS.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

/*.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database ${Stg_database};

---- Table: CDR_PLP_DEPART_COMPONENTS : Start	

---- DROP TABLE VT_CDR_PLP_DEPART_COMPONENTS;	

CREATE VOLATILE TABLE VT_CDR_PLP_DEPART_COMPONENTS,NO LOG (
      COMPONENTS_SEQ_ID INTEGER,
      DEPART_FORM_SEQ_ID INTEGER,
      PART_TYPE_SEQ_ID INTEGER,
      HOURS INTEGER,
      STARTS INTEGER,
      TRIPS INTEGER,
      FIRED_HOURS INTEGER,
      FIRED_STARTS INTEGER,
      HOURS_R INTEGER,
      STARTS_R INTEGER,
      TRIPS_R INTEGER,
      FIRED_HOURS_R INTEGER,
      FIRED_STARTS_R INTEGER,
      PART_NO VARCHAR(14) CHARACTER SET LATIN NOT CASESPECIFIC,
      SERIAL_NO VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      HOURS_D INTEGER,
      STARTS_D INTEGER,
      FIRED_HOURS_D INTEGER,
      FIRED_STARTS_D INTEGER ,
      PART_CONDITION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      COMP_NON_DEPART_FLAG INTEGER,
      STATUS_FLAG INTEGER,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( COMPONENTS_SEQ_ID );


INSERT INTO VT_CDR_PLP_DEPART_COMPONENTS
(
COMPONENTS_SEQ_ID,             
DEPART_FORM_SEQ_ID,            
PART_TYPE_SEQ_ID,              
HOURS,                         
STARTS,                        
TRIPS,                         
FIRED_HOURS,                   
FIRED_STARTS,                  
HOURS_R,                       
STARTS_R,                      
TRIPS_R,                       
FIRED_HOURS_R,                 
FIRED_STARTS_R,                
PART_NO,                       
SERIAL_NO,                     
HOURS_D,                       
STARTS_D,                      
FIRED_HOURS_D,                 
FIRED_STARTS_D,                
PART_CONDITION,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
COMP_NON_DEPART_FLAG,          
STATUS_FLAG,                   
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                                                                                                                                     
)
SELECT	
COMPONENTS_SEQ_ID,             
DEPART_FORM_SEQ_ID,            
PART_TYPE_SEQ_ID,              
HOURS,                         
STARTS,                        
TRIPS,                         
FIRED_HOURS,                   
FIRED_STARTS,                  
HOURS_R,                       
STARTS_R,                      
TRIPS_R,                       
FIRED_HOURS_R,                 
FIRED_STARTS_R,                
PART_NO,                       
SERIAL_NO,                     
HOURS_D,                       
STARTS_D,                      
FIRED_HOURS_D,                 
FIRED_STARTS_D,                
PART_CONDITION,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
COMP_NON_DEPART_FLAG,          
STATUS_FLAG,                   
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY   
FROM	 GEEDW_PLP_S.CDR_PLP_DEPART_COMPONENTS_S
MINUS
SELECT	
COMPONENTS_SEQ_ID,             
DEPART_FORM_SEQ_ID,            
PART_TYPE_SEQ_ID,              
HOURS,                         
STARTS,                        
TRIPS,                         
FIRED_HOURS,                   
FIRED_STARTS,                  
HOURS_R,                       
STARTS_R,                      
TRIPS_R,                       
FIRED_HOURS_R,                 
FIRED_STARTS_R,                
PART_NO,                       
SERIAL_NO,                     
HOURS_D,                       
STARTS_D,                      
FIRED_HOURS_D,                 
FIRED_STARTS_D,                
PART_CONDITION,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
COMP_NON_DEPART_FLAG,          
STATUS_FLAG,                   
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY      
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_DEPART_COMPONENTS;

-- Table: VT_CDR_PLP_DEPART_COMM : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_DEPART_COMPONENTS_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_DEPART_COMPONENTS_S
(	
COMPONENTS_SEQ_ID,             
DEPART_FORM_SEQ_ID,            
PART_TYPE_SEQ_ID,              
HOURS,                         
STARTS,                        
TRIPS,                         
FIRED_HOURS,                   
FIRED_STARTS,                  
HOURS_R,                       
STARTS_R,                      
TRIPS_R,                       
FIRED_HOURS_R,                 
FIRED_STARTS_R,                
PART_NO,                       
SERIAL_NO,                     
HOURS_D,                       
STARTS_D,                      
FIRED_HOURS_D,                 
FIRED_STARTS_D,                
PART_CONDITION,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
COMP_NON_DEPART_FLAG,          
STATUS_FLAG,                   
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY     
)	
SELECT 
COMPONENTS_SEQ_ID,             
DEPART_FORM_SEQ_ID,            
PART_TYPE_SEQ_ID,              
HOURS,                         
STARTS,                        
TRIPS,                         
FIRED_HOURS,                   
FIRED_STARTS,                  
HOURS_R,                       
STARTS_R,                      
TRIPS_R,                       
FIRED_HOURS_R,                 
FIRED_STARTS_R,                
PART_NO,                       
SERIAL_NO,                     
HOURS_D,                       
STARTS_D,                      
FIRED_HOURS_D,                 
FIRED_STARTS_D,                
PART_CONDITION,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
COMP_NON_DEPART_FLAG,          
STATUS_FLAG,                   
CURRENT_DATE,                                                                                                                 
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_DEPART_COMPONENTS;	

-- Table: CDR_PLP_DEPART_COMM : End