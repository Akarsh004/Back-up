# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_SCRCRD_FILE.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_SCRECRD_FILE : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_SCRECRD_FILE;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_SCRECRD_FILE,NO LOG (
      SCORECARD_FILE_SEQ_ID INTEGER ,
      SCORECARD_TYPE VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      ATTACHMENT_NAME VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ATTACHMENT_SIZE VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      ATTACHMENT_DATE DATE FORMAT 'YY/MM/DD',
      USER_SSO_ID INTEGER ,
      ATTACHMENT_DESCRIPTION VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ATTACHMENT_FOLDER_NAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX(SCORECARD_FILE_SEQ_ID)ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_SCAUTO_SCRECRD_FILE
(
SCORECARD_FILE_SEQ_ID,         
SCORECARD_TYPE,                
ATTACHMENT_NAME,               
ATTACHMENT_SIZE ,              
ATTACHMENT_DATE,               
USER_SSO_ID ,                  
ATTACHMENT_DESCRIPTION,        
ATTACHMENT_FOLDER_NAME,                                                                                                                                                 
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                       
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
SCORECARD_FILE_SEQ_ID,         
SCORECARD_TYPE,                
ATTACHMENT_NAME,               
ATTACHMENT_SIZE ,              
ATTACHMENT_DATE,               
USER_SSO_ID ,                  
ATTACHMENT_DESCRIPTION,        
ATTACHMENT_FOLDER_NAME,                                            
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_SCRCRD_FILE_S
MINUS
SELECT	
SCORECARD_FILE_SEQ_ID,         
SCORECARD_TYPE,                
ATTACHMENT_NAME,               
ATTACHMENT_SIZE ,              
ATTACHMENT_DATE,               
USER_SSO_ID ,                  
ATTACHMENT_DESCRIPTION,        
ATTACHMENT_FOLDER_NAME,                                         
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_SCRCRD_FILE;

-- Table: VT_CDR_PLP_SCAUTO_SCRECRD_FILE : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_SCRCRD_FILE_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_SCRCRD_FILE_S
(	
SCORECARD_FILE_SEQ_ID,         
SCORECARD_TYPE,                
ATTACHMENT_NAME,               
ATTACHMENT_SIZE ,              
ATTACHMENT_DATE,               
USER_SSO_ID ,                  
ATTACHMENT_DESCRIPTION,        
ATTACHMENT_FOLDER_NAME,                                           
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
SCORECARD_FILE_SEQ_ID,         
SCORECARD_TYPE,                
ATTACHMENT_NAME,               
ATTACHMENT_SIZE ,              
ATTACHMENT_DATE,               
USER_SSO_ID ,                  
ATTACHMENT_DESCRIPTION,        
ATTACHMENT_FOLDER_NAME,                                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY, 
CURRENT_DATE,                 
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_SCRECRD_FILE;	

-- Table: CDR_PLP_SCAUTO_SCRECRD_FILE: End




