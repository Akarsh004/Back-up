#!/bin/ksh/
######################################################################
##################      LOCAL VARIABLES       ########################
######################################################################

SRCPATH=/data/informatica/ETCOE/EEDW01/Config/
SESSLOGPATH=/data/informatica/ETCOE/EEDW01/SessLogs/
Workflow_name=$1
Parameter_File_name=$1".txt"
Log_File=$SESSLOGPATH"Parameter_File_Update.log"
######################################################################
####################       Main Code         #########################
######################################################################

echo "INFO :" `date`  ":SCRIPT Parameter_File_Update PROCESSING STARTED"   >> $Log_File
if [ -d $SRCPATH ]; then
        cd $SRCPATH
        if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$SRCPATH}" successful "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Path change" {$SRCPATH}" failed "  >> $Log_File
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$SRCPATH} " Not Found "  >> $Log_File
        exit 1
fi

if test -f $Parameter_File_name
        then
                echo "INFO :" `date`  ":Parameter File " $Parameter_File_name " Found"   >> $Log_File
        else
                echo "ERROR :" `date`  ":Parameter File " $Parameter_File_name " Not Found"   >> $Log_File
                exit 1
fi

Current_Date=`date +'%m/%d/%Y %H:%M:%S'`
Current_Date="'"$Current_Date"'"
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Current Date  "$Current_Date" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Date function failed "  >> $Log_File
                    exit 1
         fi
Load_Date=`grep LAST_LOAD_DATE $Parameter_File_name |head -1`
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date  "$Load_Date" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load date not found "  >> $Log_File
                    exit 1
         fi
Date_Value=`echo $Load_Date |awk -F= '{print $2}'`
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date  value "$Date_Value" found "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load Date Value not found "  >> $Log_File
                    exit 1
         fi
sed "s@$Date_Value@$Current_Date@" $Parameter_File_name > tempfile
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Last Load Date replaced "   >> $Log_File
         else
                    echo "ERROR:" `date` ":Last Load Date replace failed"  >> $Log_File
                    exit 1
         fi
mv tempfile $Parameter_File_name
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":File renamed "   >> $Log_File
         else
                    echo "ERROR:" `date` ":File renaming failed "  >> $Log_File
                    exit 1
         fi
chmod 777 $Parameter_File_name
if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":File permission Changed "   >> $Log_File
         else
                    echo "ERROR:" `date` ":File permission can not be changed  "  >> $Log_File
                    exit 1
         fi

exit 0
