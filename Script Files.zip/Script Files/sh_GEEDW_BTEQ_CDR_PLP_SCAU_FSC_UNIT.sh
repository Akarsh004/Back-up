# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_FSC_UNIT.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Deepika
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_FSC_UNITS : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_FSC_UNITS;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_FSC_UNITS ,NO LOG (

      TURBINE_NUMBER VARCHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CS_ENGINE_FLAG INTEGER ,
      SC_REGISTERED_FLAG INTEGER ,
      ENHANCED_SC_FLAG INTEGER ,
      HAS_OSM_FLAG INTEGER ,
      CONFIG_SC_FLAG INTEGER ,
      SNOWFLAKE_FLAG INTEGER ,
      PROJ_REF_HRS INTEGER,
      PROJ_REF_STARTS INTEGER ,
      PROJ_REF_DATE DATE FORMAT 'YY/MM/DD' ,
      PROJ_REF_FAC_HRS INTEGER ,
      PROJ_REF_FAC_STARTS INTEGER ,
      PROJ_REF_FAC_DATE DATE FORMAT 'YY/MM/DD' ,
      OPS_STATUS INTEGER ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC   )
 PRIMARY INDEX  ( TURBINE_NUMBER )ON COMMIT PRESERVE ROWS;



INSERT INTO VT_CDR_PLP_SCAUTO_FSC_UNITS
(

TURBINE_NUMBER,                
CS_ENGINE_FLAG,                
SC_REGISTERED_FLAG,            
ENHANCED_SC_FLAG,              
HAS_OSM_FLAG,                  
CONFIG_SC_FLAG,                
SNOWFLAKE_FLAG ,               
PROJ_REF_HRS,                  
PROJ_REF_STARTS,               
PROJ_REF_DATE ,                
PROJ_REF_FAC_HRS,              
PROJ_REF_FAC_STARTS,           
PROJ_REF_FAC_DATE,             
OPS_STATUS ,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)

SELECT	

TURBINE_NUMBER,                
CS_ENGINE_FLAG,                
SC_REGISTERED_FLAG,            
ENHANCED_SC_FLAG,              
HAS_OSM_FLAG,                  
CONFIG_SC_FLAG,                
SNOWFLAKE_FLAG ,               
PROJ_REF_HRS,                  
PROJ_REF_STARTS,               
PROJ_REF_DATE ,                
PROJ_REF_FAC_HRS,              
PROJ_REF_FAC_STARTS,           
PROJ_REF_FAC_DATE,             
OPS_STATUS ,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY 

FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_FSC_UNIT_S

MINUS

SELECT	

TURBINE_NUMBER,                
CS_ENGINE_FLAG,                
SC_REGISTERED_FLAG,            
ENHANCED_SC_FLAG,              
HAS_OSM_FLAG,                  
CONFIG_SC_FLAG,                
SNOWFLAKE_FLAG ,               
PROJ_REF_HRS,                  
PROJ_REF_STARTS,               
PROJ_REF_DATE ,                
PROJ_REF_FAC_HRS,              
PROJ_REF_FAC_STARTS,           
PROJ_REF_FAC_DATE,             
OPS_STATUS ,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_FSC_UNIT;

-- Table: VT_CDR_PLP_SCAUTO_FSC_UNITS : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_FSC_UNIT_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_FSC_UNIT_S
(	
TURBINE_NUMBER,                
CS_ENGINE_FLAG,                
SC_REGISTERED_FLAG,            
ENHANCED_SC_FLAG,              
HAS_OSM_FLAG,                  
CONFIG_SC_FLAG,                
SNOWFLAKE_FLAG ,               
PROJ_REF_HRS,                  
PROJ_REF_STARTS,               
PROJ_REF_DATE ,                
PROJ_REF_FAC_HRS,              
PROJ_REF_FAC_STARTS,           
PROJ_REF_FAC_DATE,             
OPS_STATUS ,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 

TURBINE_NUMBER,                
CS_ENGINE_FLAG,                
SC_REGISTERED_FLAG,            
ENHANCED_SC_FLAG,              
HAS_OSM_FLAG,                  
CONFIG_SC_FLAG,                
SNOWFLAKE_FLAG ,               
PROJ_REF_HRS,                  
PROJ_REF_STARTS,               
PROJ_REF_DATE ,                
PROJ_REF_FAC_HRS,              
PROJ_REF_FAC_STARTS,           
PROJ_REF_FAC_DATE,             
OPS_STATUS ,                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY, 
CURRENT_DATE,        
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_FSC_UNITS ;	

-- Table: CDR_PLP_SCAUTO_FSC_UNITS : End




