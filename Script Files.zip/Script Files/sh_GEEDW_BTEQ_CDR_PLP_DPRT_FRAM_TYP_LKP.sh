# ---------------------------------------------------------------------------- 
# File: sh_GEEDW_BTEQ_CDR_PLP_DPRT_FRAM_TYP_LKP.sh
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
 /* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_PLP_ALLOWD_INT_LIMT_SN  : Start

 DROP TABLE VT_CDR_PLP_ALLOWD_INT_LIMT_SN ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */
 CREATE VOLATILE TABLE VT_CDR_PLP_DPRT_FRAM_TYP_LKP,NO LOG (
      FRAME_TYPE_SEQ_ID INTEGER  NOT NULL,
      TECHNOLOGY_DESC VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD' NOT NULL,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD'  NOT NULL,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      GT_MODEL_NUMBER_CODE VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      CLASSIFICATION VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX  ( FRAME_TYPE_SEQ_ID );


---Table: CDR_PLP_DPRT_FRAM_TYP_LKP : Processing : Populate GT table with CDC data 

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_DPRT_FRAM_TYP_LKP
(
FRAME_TYPE_SEQ_ID             ,
TECHNOLOGY_DESC               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
GT_MODEL_NUMBER_CODE          ,
CLASSIFICATION                ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
FRAME_TYPE_SEQ_ID             ,
TECHNOLOGY_DESC               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
GT_MODEL_NUMBER_CODE          ,
CLASSIFICATION                ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_PLP_DPRT_FRAM_TYP_LKP_S
MINUS
SELECT 
FRAME_TYPE_SEQ_ID             ,
TECHNOLOGY_DESC               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
GT_MODEL_NUMBER_CODE          ,
CLASSIFICATION                ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_BULK_T.CDR_PLP_DPRT_FRAM_TYP_LKP;


----Table: VT_CDR_GIB_CUSTOMER : Processing : Populate Stage table with CDC data only for mLDM processing  

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_DPRT_FRAM_TYP_LKP_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_DPRT_FRAM_TYP_LKP_S
(
FRAME_TYPE_SEQ_ID             ,
TECHNOLOGY_DESC               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
GT_MODEL_NUMBER_CODE          ,
CLASSIFICATION                ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
FRAME_TYPE_SEQ_ID             ,
TECHNOLOGY_DESC               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
GT_MODEL_NUMBER_CODE          ,
CLASSIFICATION                ,
CURRENT_DATE,                  
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_DPRT_FRAM_TYP_LKP;


---Table: CDR_PLP_DPRT_FRAM_TYP_LKP : End

