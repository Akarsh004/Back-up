ftp -inv <<EOF
open cdiextracts.corporate.ge.com
user cdi_energy_eng_dwh Pa55w0rd
cd weekly
lcd /data/informatica/ETCOE/EEDW01/SrcFiles/CDI
binary
mget CDI_FULL_All_CSV_120310-080002.csv.Z
quit
chmod 777
EOF
uncompress -f /data/informatica/ETCOE/EEDW01/SrcFiles/CDI/CDI_FULL_All_CSV_120310-080002.csv.Z
cd /data/informatica/ETCOE/EEDW01/SrcFiles/CDI
sed "s/\"/\'/g" CDI_FULL_All_CSV_120310-080002.csv > TCDI_FULL_All_CSV_120310-080002.csv

sed "s/\|\*\|/\"/g" TCDI_FULL_All_CSV_120310-080002.csv > PCDI_FULL_All_CSV_120310-080002.csv



