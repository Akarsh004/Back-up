# --------------------------------------------------------------------------------------------------------------#
# File: sh_GEEDW_BTEQ_RPDM_SYSTEM_NUMBER_GT.sh									#
# Creation Date: 10-JAN-2018											#
# Last Modified: 10-JAN-2018											#
# Purpose: Populate list of RPDM System numbers	by joining with Assert into BV					#
# Created By: Sumanta Bhujabal											#
# --------------------------------------------------------------------------------------------------------------#

. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq << eof 

.RUN File =/data/informatica/ETCOE/EEDW01/SrcFiles/td_plp.mlbt

database ${Bulk_database};

collect stats column ( SYSTEM_NM ) on GEEDW_PLP_BULK_T.MT_RPDM_T2SYSTEM_INSTANCE_GT;
collect stats column ( T2SPUNUMBER ) on GEEDW_PLP_BULK_T.MT_RPDM_T2SYSTEM_INSTANCE_GT;

.IF ERRORCODE <> 0 THEN .EXIT ERRORCODE;
.LOGOFF;
.EXIT;
eof
