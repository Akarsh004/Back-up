# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PLA_SITE_RO.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_PLA_SITE_RO : Start	

---- DROP TABLE VT_CDR_PLP_PLA_SITE_RO;	

CREATE VOLATILE TABLE VT_CDR_PLP_PLA_SITE_RO,NO LOG (
      PLA_SITE_RO_SEQ_ID INTEGER,
      PARENT_ID INTEGER,
      REPAIR_ORDER_NUM VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      SITE_NAME VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PLA_SITE_RO_SEQ_ID ) ON COMMIT PRESERVE ROWS;

INSERT INTO VT_CDR_PLP_PLA_SITE_RO
(
PLA_SITE_RO_SEQ_ID,            
PARENT_ID,                     
REPAIR_ORDER_NUM,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                                                            
)
SELECT	
PLA_SITE_RO_SEQ_ID,            
PARENT_ID,                     
REPAIR_ORDER_NUM,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
FROM	 GEEDW_PLP_S.CDR_PLP_PLA_SITE_RO_S
MINUS
SELECT	
PLA_SITE_RO_SEQ_ID,            
PARENT_ID,                     
REPAIR_ORDER_NUM,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY   
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PLA_SITE_RO;

-- Table: VT_CDR_PLP_PLA_SITE_RO : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PLA_SITE_RO_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PLA_SITE_RO_S
(	
PLA_SITE_RO_SEQ_ID,            
PARENT_ID,                     
REPAIR_ORDER_NUM,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,                     
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY   
)	
SELECT 
PLA_SITE_RO_SEQ_ID,            
PARENT_ID,                     
REPAIR_ORDER_NUM,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
SITE_NAME,     
CURRENT_DATE,                                                                                                         
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PLA_SITE_RO;	

-- Table: CDR_PLP_PLA_SITE_RO : End




