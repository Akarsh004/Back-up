#*************************************************************************************
#/* This is used for updating the LAST_UPDATE_DATE in Parameter.txt with the sysdate */
#*************************************************************************************
cd /data/informatica/ETCOE/EEDW01/ScriptFiles/
TXT=`cat Parameter.txt | grep "LAST_UPDATE_DATE=" | awk -F"=" '{print $2}' | head -1` ;
DT=`date +%d-%b-%Y` ;
sed "s/$TXT/$DT/g" /data/informatica/ETCOE/EEDW01/ScriptFiles/Parameter.txt > /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_STAGING_Parameter.txt ;

