DT=`date +'%m/%d/%Y'`
sed "s_LASTDATE_${DT}_g" /data/informatica/ETCOE/EEDW01/ScriptFiles/PLP_Parameter_LastDate.txt > /data/informatica/ETCOE/EEDW01/Config/wflw_EEDW_PLP_STAGE_Parameter.txt;




