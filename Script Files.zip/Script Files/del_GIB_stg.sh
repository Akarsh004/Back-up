/* This is used for deleting records in stage tables for GIB */
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq  << eof 
.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;
/*.RUN File = ${SrcDir}/td_plp.mlbt*/

delete from GEEDW_PLP_S.CDR_GIB_CUSTOMER_HIERARCHY;
delete from GEEDW_PLP_S.CDR_GIB_CUSTOMER;
delete from GEEDW_PLP_S.CDR_GIB_EMPLOYEE;
delete from GEEDW_PLP_S.CDR_GIB_EMPOFFICE;
delete from GEEDW_PLP_S.CDR_GIB_ORG_HIERARCHY;
delete from GEEDW_PLP_S.CDR_GIB_ORGANIZATION;
delete from GEEDW_PLP_S.CDR_GIB_SERVICE_RESP;
delete from GEEDW_PLP_S.CDR_GIB_RELATED_EQUIPMENT;

.logoff            
.QUIT
eof