# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_T_PRG.sh 
# Creation Date: 07/28/11 
# Last Modified: 07/28/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_PRG : Start	

---- DROP TABLE VT_CDR_ODS_T_PRG;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK *?

CREATE VOLATILE TABLE VT_CDR_ODS_T_PRG,NO LOG (
ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATION_DATE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
LAST_UPDATE_DATE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
SOURCE_MODIFIED_DATE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
SOURCE_ORIGINATED_DATE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER1 VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER2 VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_X VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
PRG_MGR VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
ORIG VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
CDRL_NOTIFICATIONS_LAST_RUN VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
ENABLE_DRL_NOTIFICATIONS VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
ORG_NM VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
EXPORT_CONTROL_WARNING_NOTICE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
PRG_ACRONYM VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
PRG_DESIGNATOR VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_F VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_E VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_D VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DESTRUCTION_NOTIFICATION VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_C VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DUE_DT_OFFSET VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_B VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DSTR_STATEMENT_A VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
SCRTY_LEVEL_CLSFN VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_LOAD_DATE DATE FORMAT 'YY/MM/DD'   ,
DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD'   ,
DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,

)

PRIMARY INDEX ( ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_T_PRG : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_PRG
(
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,DSTR_STATEMENT_X              
,PRG_MGR                       
,ORIG                          
,CDRL_NOTIFICATIONS_LAST_RUN   
,ENABLE_DRL_NOTIFICATIONS      
,ORG_NM                        
,EXPORT_CONTROL_WARNING_NOTICE 
,PRG_ACRONYM                   
,PRG_DESIGNATOR                
,DSTR_STATEMENT_F              
,DSTR_STATEMENT_E              
,DSTR_STATEMENT_D              
,DESTRUCTION_NOTIFICATION      
,DSTR_STATEMENT_C              
,DUE_DT_OFFSET                 
,DSTR_STATEMENT_B              
,DSTR_STATEMENT_A              
,SCRTY_LEVEL_CLSFN             
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
             
            
)

SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,DSTR_STATEMENT_X              
,PRG_MGR                       
,ORIG                          
,CDRL_NOTIFICATIONS_LAST_RUN   
,ENABLE_DRL_NOTIFICATIONS      
,ORG_NM                        
,EXPORT_CONTROL_WARNING_NOTICE 
,PRG_ACRONYM                   
,PRG_DESIGNATOR                
,DSTR_STATEMENT_F              
,DSTR_STATEMENT_E              
,DSTR_STATEMENT_D              
,DESTRUCTION_NOTIFICATION      
,DSTR_STATEMENT_C              
,DUE_DT_OFFSET                 
,DSTR_STATEMENT_B              
,DSTR_STATEMENT_A              
,SCRTY_LEVEL_CLSFN             
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 


FROM GEEDW_PLP_S.CDR_ODS_T_PRG_S
MINUS
SELECT
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,DSTR_STATEMENT_X              
,PRG_MGR                       
,ORIG                          
,CDRL_NOTIFICATIONS_LAST_RUN   
,ENABLE_DRL_NOTIFICATIONS      
,ORG_NM                        
,EXPORT_CONTROL_WARNING_NOTICE 
,PRG_ACRONYM                   
,PRG_DESIGNATOR                
,DSTR_STATEMENT_F              
,DSTR_STATEMENT_E              
,DSTR_STATEMENT_D              
,DESTRUCTION_NOTIFICATION      
,DSTR_STATEMENT_C              
,DUE_DT_OFFSET                 
,DSTR_STATEMENT_B              
,DSTR_STATEMENT_A              
,SCRTY_LEVEL_CLSFN             
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
       
               
             
              


FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_PRG;	




-- Table: VT_CDR_ODS_T_PRG : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_PRG_S;	

/* INSERTING DATA INTO STAGE */ 

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_PRG_S
(	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,DSTR_STATEMENT_X              
,PRG_MGR                       
,ORIG                          
,CDRL_NOTIFICATIONS_LAST_RUN   
,ENABLE_DRL_NOTIFICATIONS      
,ORG_NM                        
,EXPORT_CONTROL_WARNING_NOTICE 
,PRG_ACRONYM                   
,PRG_DESIGNATOR                
,DSTR_STATEMENT_F              
,DSTR_STATEMENT_E              
,DSTR_STATEMENT_D              
,DESTRUCTION_NOTIFICATION      
,DSTR_STATEMENT_C              
,DUE_DT_OFFSET                 
,DSTR_STATEMENT_B              
,DSTR_STATEMENT_A              
,SCRTY_LEVEL_CLSFN             
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 


               
)
SELECT	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,DSTR_STATEMENT_X              
,PRG_MGR                       
,ORIG                          
,CDRL_NOTIFICATIONS_LAST_RUN   
,ENABLE_DRL_NOTIFICATIONS      
,ORG_NM                        
,EXPORT_CONTROL_WARNING_NOTICE 
,PRG_ACRONYM                   
,PRG_DESIGNATOR                
,DSTR_STATEMENT_F              
,DSTR_STATEMENT_E              
,DSTR_STATEMENT_D              
,DESTRUCTION_NOTIFICATION      
,DSTR_STATEMENT_C              
,DUE_DT_OFFSET                 
,DSTR_STATEMENT_B              
,DSTR_STATEMENT_A              
,SCRTY_LEVEL_CLSFN             
,CURRENT_DATE                
,'CDR'                
,CURRENT_DATE                
,'CDR'                   

           
                  
  
             
            

FROM VT_CDR_ODS_T_PRG;	


-- Table: CDR_ODS_T_PRG : End
