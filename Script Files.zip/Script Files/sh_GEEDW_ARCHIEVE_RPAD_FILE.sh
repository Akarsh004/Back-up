#bin bash
cd /data/informatica/ETCOE/EEDW01/SrcFiles/
gzip rpad.txt
mv rpad1.txt.gz /data/informatica/ETCOE/EEDW01/OutFiles/rpad.txt.gz-`date +%d%m%y`
cd data/informatica/ETCOE/EEDW01/OutFiles
chmod 777 rpad.txt.gz-`date +%d%m%y`
sftp cdr_twd@Sftp.corporate.ge.com << EOF
cd /cdr/Rpad
put rpad.txt.gz-`date +%d%m%y`
quit
chmod 777 rpad.txt.gz-`date +%d%m%y`
EOF$