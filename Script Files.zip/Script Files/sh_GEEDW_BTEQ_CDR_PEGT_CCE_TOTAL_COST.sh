sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_CDR_PEGT_CCE_TOTAL_COST1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_CDR_PEGT_CCE_TOTAL_COST_LOG.txt 2>&1
