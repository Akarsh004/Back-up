# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_FLCASE_MODEL.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_FLCASE_MODEL : Start	

---- DROP TABLE VT_CDR_PLP_FLCASE_MODEL;	

CREATE VOLATILE TABLE VT_CDR_PLP_FLCASE_MODEL,NO LOG (
      CASE_ID INTEGER,
      MODEL_NUM VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
 PRIMARY INDEX(CASE_ID,MODEL_NUM)ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_FLCASE_MODEL
(
CASE_ID,                       
MODEL_NUM,                                                         
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                       
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
CASE_ID,                       
MODEL_NUM,                                      
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_FLCASE_MODEL_S
MINUS
SELECT	
CASE_ID,                       
MODEL_NUM,                                     
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_FLCASE_MODEL;

-- Table: VT_CDR_PLP_FLCASE_MODEL : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_FLCASE_MODEL_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_FLCASE_MODEL_S
(	
CASE_ID,                       
MODEL_NUM,                                     
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
CASE_ID,                       
MODEL_NUM,                                     
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,  
CURRENT_DATE,                
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_FLCASE_MODEL;	

-- Table: CDR_PLP_FLCASE_MODEL: End




