# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PRJCTIN_SCH_DTL.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_PRJCTIN_SCH_DTL : Start	

---- DROP TABLE VT_CDR_PLP_PRJCTIN_SCH_DTL;	

CREATE VOLATILE TABLE VT_CDR_PLP_PRJCTIN_SCH_DTL,NO LOG (
      PROJ_SCHEME_SEQ_ID INTEGER ,
      PROJ_SCHEME_NAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      PROJECTED_SCHEME_DESC VARCHAR(500) CHARACTER SET LATIN NOT CASESPECIFIC,
      NUMBER_OF_DAYS_MISSION INTEGER,
      STATUS INTEGER,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PROJ_SCHEME_SEQ_ID ) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_PRJCTIN_SCH_DTL
(
PROJ_SCHEME_SEQ_ID,            
PROJ_SCHEME_NAME,              
PROJECTED_SCHEME_DESC,         
NUMBER_OF_DAYS_MISSION,        
STATUS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                             
)
SELECT	
PROJ_SCHEME_SEQ_ID,            
PROJ_SCHEME_NAME,              
PROJECTED_SCHEME_DESC,         
NUMBER_OF_DAYS_MISSION,        
STATUS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
FROM	 GEEDW_PLP_S.CDR_PLP_PRJCTIN_SCH_DTL_S
MINUS
SELECT	
PROJ_SCHEME_SEQ_ID,            
PROJ_SCHEME_NAME,              
PROJECTED_SCHEME_DESC,         
NUMBER_OF_DAYS_MISSION,        
STATUS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PRJCTIN_SCH_DTL;

-- Table: VT_CDR_PLP_PRJCTIN_SCH_DTL : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PRJCTIN_SCH_DTL_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PRJCTIN_SCH_DTL_S
(	
PROJ_SCHEME_SEQ_ID,            
PROJ_SCHEME_NAME,              
PROJECTED_SCHEME_DESC,         
NUMBER_OF_DAYS_MISSION,        
STATUS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
)	
SELECT 
PROJ_SCHEME_SEQ_ID,            
PROJ_SCHEME_NAME,              
PROJECTED_SCHEME_DESC,         
NUMBER_OF_DAYS_MISSION,        
STATUS,                        
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                                                                              CURRENT_DATE,         
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PRJCTIN_SCH_DTL;	

-- Table: CDR_PLP_PRJCTIN_SCH_DTL : End




