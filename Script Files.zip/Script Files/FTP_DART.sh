#########################################################################################
##      Author: Prashant Chaubey, 23-SEP-09
##
##      This script
##      1) This Script clear
##          a) all *.out files from Out Files directory locate in plp home dir.
##          b) removes all cache files from cache file directory locate in plp home dir.
##
##
##
#########################################################################################

# GETTING VALUE OF ALL THE PARAMETER #
RootPath=/data/informatica/ETCOE/EEDW01
OutfilePath=$RootPath/OutFiles
CachePath=$RootPath/CacheFiles

# Going to out files directory #
cd $OutfilePath

# Removing all out files having Extention as .out leaving behind control files and loader log #
rm -rf *.out

# Going to Cache files directory #
cd $CachePath

# Removing all cache files present in the directory#
rm -rf *$ cat /data/informatica/ETCOE/EEDW01/ScriptFiles/FTP_DART.sh
DTT=`date +%d`
day1='1'
day2='7'
if test $DTT -ge $day1 -a $DTT -le $day2
then
HOST='imsv08.sch.ge.com'
USER='plpcdr01'
PASSWD='cJyd4pa4'
DT=`date +%m%y`

curr_year=`date '+%y'`
curr_month=`date '+%m'`
curr_day=`date '+%d'`
echo $curr_year
echo $curr_month
echo $curr_day
prev_month=`expr $curr_month - 1`
prev_year=$curr_year

if  test $prev_month -eq 0; then
    prev_month=12
    prev_year=`expr $curr_year - 1`
fi

if  test $prev_month -le 9; then
  prev_month=`echo "0$prev_month"`
fi


previous_mnth_val=$prev_month$prev_year

ftp -v -n <<EOF
open $HOST
user $USER $PASSWD
cd /geedim/syslog
echo $DT
lcd /data/informatica/ETCOE/EEDW01/SrcFiles/
get ug_issue.rpt-$DT
get ug_issue.rpt-$previous_mnth_val
quit
EOF
fi
if test $DTT -ge $day1 -a $DTT -le $day2
then
rm /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
mv /data/informatica/ETCOE/EEDW01/SrcFiles/ug_issue.rpt-$DT /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
cat /data/informatica/ETCOE/EEDW01/SrcFiles/ug_issue.rpt-$previous_mnth_val >> /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
rm /data/informatica/ETCOE/EEDW01/SrcFiles/ug_issue.rpt-$previous_mnth_val
fi
if test $DTT -gt $day2
then
HOST='imsv08.sch.ge.com'
USER='plpcdr01'
PASSWD='cJyd4pa4'
DT=`date +%m%y`
ftp -v -n <<EOF
open $HOST
user $USER $PASSWD
cd /geedim/syslog
echo $DT
lcd /data/informatica/ETCOE/EEDW01/SrcFiles/
get ug_issue.rpt-$DT
quit
EOF
fi
if test $DTT -gt $day2
then
rm /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
mv /data/informatica/ETCOE/EEDW01/SrcFiles/ug_issue.rpt-$DT /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
fi
