sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_AERO_LX_MERGE1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_AERO_LX_MERGE_LOG.txt 2>&1
