/* This is used for deleting records in stage tables*/



bteq  << eof.
/*/*.RUN File = ${SrcDir}/td_plp.mlbt*/ */
.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;

database GEEDW_PLP_S;
delete from GEEDW_PLP_S.CDR_COPICS_ITM_HST;
.logoff.
.QUIT
eof