# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_EPIP_STAGE_ROPT.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_EPIP_STAGE_ROPT : Start	

---- DROP TABLE VT_CDR_PLP_EPIP_STAGE_ROPT;	

CREATE VOLATILE TABLE VT_CDR_PLP_EPIP_STAGE_ROPT,NO LOG (
      STAGE_ROPARTS_SEQ_ID INTEGER ,
      JOB_SEQ_ID INTEGER,
      SVC_ID INTEGER ,
      PART_SERIAL_NUMBER VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      DRAWING_SERIAL_NUMBER VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DRAWING_GRP_SN VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      TECHNOLOGY VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      USER_COMMENTS VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_DISPOSITION VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PART_POSITION INTEGER ,
      PART_TAG INTEGER ,
      NON_DES_TEST INTEGER ,
      PART_DIMENSIONS INTEGER,
      EPIP_INSPECTION_STATUS INTEGER ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      STAGE_JOB_SEQ_ID INTEGER ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX(STAGE_ROPARTS_SEQ_ID) ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_EPIP_STAGE_ROPT
(
STAGE_ROPARTS_SEQ_ID,          
JOB_SEQ_ID,                    
SVC_ID,                        
PART_SERIAL_NUMBER,            
DRAWING_SERIAL_NUMBER,         
DRAWING_GRP_SN,                
TECHNOLOGY ,                   
USER_COMMENTS,                 
PART_DISPOSITION,              
PART_POSITION,                 
PART_TAG,                      
NON_DES_TEST,                  
PART_DIMENSIONS,               
EPIP_INSPECTION_STATUS,                       
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
STAGE_JOB_SEQ_ID ,                                         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
STAGE_ROPARTS_SEQ_ID,          
JOB_SEQ_ID,                    
SVC_ID,                        
PART_SERIAL_NUMBER,            
DRAWING_SERIAL_NUMBER,         
DRAWING_GRP_SN,                
TECHNOLOGY ,                   
USER_COMMENTS,                 
PART_DISPOSITION,              
PART_POSITION,                 
PART_TAG,                      
NON_DES_TEST,                  
PART_DIMENSIONS,               
EPIP_INSPECTION_STATUS,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
STAGE_JOB_SEQ_ID ,                  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_ROPT_S
MINUS
SELECT	
STAGE_ROPARTS_SEQ_ID,          
JOB_SEQ_ID,                    
SVC_ID,                        
PART_SERIAL_NUMBER,            
DRAWING_SERIAL_NUMBER,         
DRAWING_GRP_SN,                
TECHNOLOGY ,                   
USER_COMMENTS,                 
PART_DISPOSITION,              
PART_POSITION,                 
PART_TAG,                      
NON_DES_TEST,                  
PART_DIMENSIONS,               
EPIP_INSPECTION_STATUS,               
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
STAGE_JOB_SEQ_ID ,                 
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_EPIP_STAGE_ROPT;

-- Table: VT_CDR_PLP_EPIP_STAGE_ROPT : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_ROPT_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_ROPT_S
(	
STAGE_ROPARTS_SEQ_ID,          
JOB_SEQ_ID,                    
SVC_ID,                        
PART_SERIAL_NUMBER,            
DRAWING_SERIAL_NUMBER,         
DRAWING_GRP_SN,                
TECHNOLOGY ,                   
USER_COMMENTS,                 
PART_DISPOSITION,              
PART_POSITION,                 
PART_TAG,                      
NON_DES_TEST,                  
PART_DIMENSIONS,               
EPIP_INSPECTION_STATUS,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
STAGE_JOB_SEQ_ID ,                                     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
STAGE_ROPARTS_SEQ_ID,          
JOB_SEQ_ID,                    
SVC_ID,                        
PART_SERIAL_NUMBER,            
DRAWING_SERIAL_NUMBER,         
DRAWING_GRP_SN,                
TECHNOLOGY ,                   
USER_COMMENTS,                 
PART_DISPOSITION,              
PART_POSITION,                 
PART_TAG,                      
NON_DES_TEST,                  
PART_DIMENSIONS,               
EPIP_INSPECTION_STATUS,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
STAGE_JOB_SEQ_ID , 
CURRENT_DATE,
'PLP',                         
CURRENT_DATE,
'PLP'
FROM VT_CDR_PLP_EPIP_STAGE_ROPT;	

-- Table: CDR_PLP_EPIP_STAGE_ROPT: End




