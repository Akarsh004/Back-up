# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_ORGANIZATION.sh 
# Creation Date: 07/29/10 
# Last Modified: 07/29/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 
database ${Stg_database};

-- Table: CDR_GIB_ORGANIZATION : Start	

---- DROP TABLE VT_CDR_GIB_ORGANIZATION;	


CREATE VOLATILE TABLE VT_CDR_GIB_ORGANIZATION ,NO LOG (
	      ORGANIZATION_CODE VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ORGANIZATION_NAME VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ADDRESS_LINE1 VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ADDRESS_LINE2 VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ADDRESS_LINE3 VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ADDRESS_LINE4 VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
	      POSTAL_CODE VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC,
	      CITY VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	      STATE VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
	      COUNTRY VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
	      ORG_TYPE VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC,
	      LASTMODIFIED_BY VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC,
	      LASTMODIFIED_DT DATE FORMAT 'MM/DD/YYYY',
	      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
	      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
	      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
	      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( ORGANIZATION_CODE ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_GIB_ORGANIZATION : Processing : Populate GT table with CDC data	

INSERT INTO VT_CDR_GIB_ORGANIZATION 
(
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT           
               
)
SELECT 
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT           
FROM GEEDW_PLP_S.CDR_GIB_ORGANIZATION	
MINUS
SELECT 
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT
FROM GEEDW_PLP_BULK_T.CDR_GIB_ORGANIZATION;	


-- Table: VT_CDR_GIB_ORGANIZATION : Processing : Populate Stage table with CDC data only for mLDM processing	

DELETE GEEDW_PLP_S.CDR_GIB_ORGANIZATION;	


INSERT INTO GEEDW_PLP_S.CDR_GIB_ORGANIZATION 
(	
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
ORGANIZATION_CODE,             
ORGANIZATION_NAME,             
ADDRESS_LINE1,                 
ADDRESS_LINE2,                 
ADDRESS_LINE3,                 
ADDRESS_LINE4,                 
POSTAL_CODE,                   
CITY,                          
STATE,                         
COUNTRY,                       
ORG_TYPE,                      
LASTMODIFIED_BY,               
LASTMODIFIED_DT,               
CURRENT_DATE,
'GIB',
CURRENT_DATE,
'GIB'
FROM VT_CDR_GIB_ORGANIZATION;	


-- Table: CDR_GIB_ORGANIZATION : End




