# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_OUTAGE_TYPE_SYSTEM.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_OUTAGE_TYPE_SYSTEM : Start	

---- DROP TABLE VT_CDR_PLP_OUTAGE_TYPE_SYSTEM;	

CREATE VOLATILE TABLE VT_CDR_PLP_OUTAGE_TYPE_SYSTEM,NO LOG (
      OUTAGE_TYPE_ID INTEGER,
      PART_SYSTEM INTEGER,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( OUTAGE_TYPE_ID ,PART_SYSTEM ) ON COMMIT PRESERVE ROWS;



INSERT INTO VT_CDR_PLP_OUTAGE_TYPE_SYSTEM
(
OUTAGE_TYPE_ID,                
PART_SYSTEM,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                    
)
SELECT	
OUTAGE_TYPE_ID,                
PART_SYSTEM,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY  
FROM	 GEEDW_PLP_S.CDR_PLP_OUTAGE_TYPE_SYSTEM_S
MINUS
SELECT	
OUTAGE_TYPE_ID,                
PART_SYSTEM,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY   
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_OUTAGE_TYPE_SYSTEM;

-- Table: VT_CDR_PLP_OUTAGE_TYPE_SYSTEM : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_OUTAGE_TYPE_SYSTEM_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_OUTAGE_TYPE_SYSTEM_S 
(	
OUTAGE_TYPE_ID,                
PART_SYSTEM,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                     
)	
SELECT 
OUTAGE_TYPE_ID,                
PART_SYSTEM,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                                                                              CURRENT_DATE,                                   
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_OUTAGE_TYPE_SYSTEM;	

-- Table: CDR_PLP_OUTAGE_TYPE_SYSTEM : End




