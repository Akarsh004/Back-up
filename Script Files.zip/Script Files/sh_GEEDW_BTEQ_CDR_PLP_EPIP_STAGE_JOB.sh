# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_EPIP_STAGE_JOB.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_EPIP_STAGE_JOB : Start	

---- DROP TABLE VT_CDR_PLP_EPIP_STAGE_JOB;	

CREATE VOLATILE TABLE VT_CDR_PLP_EPIP_STAGE_JOB,NO LOG (
      STAGE_JOB_SEQ_ID INTEGER,
      JOB_SEQ_ID INTEGER,
      JOB_NUMBER VARCHAR(55) CHARACTER SET LATIN NOT CASESPECIFIC ,
      REPAIR_ORDER_DATE DATE FORMAT 'YYYY-MM-DD',
      PART_TYPE VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ENG_SITE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TURBINE_NUMBER VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      JOB_INSPECTOR VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      JOB_SHOP VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      JOB_TECHNOLOGY VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC,
      USER_COMMENTS VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
      CUST_SEQ_ID INTEGER,
      SITE_SEQ_ID INTEGER,
      PLDB_JOB INTEGER,
      SET_STATUS INTEGER ,
      JOB_TRANSFERED INTEGER,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
 PRIMARY INDEX(STAGE_JOB_SEQ_ID)ON COMMIT PRESERVE ROWS;


INSERT INTO VT_CDR_PLP_EPIP_STAGE_JOB
(
STAGE_JOB_SEQ_ID,              
JOB_SEQ_ID,                    
JOB_NUMBER,                    
REPAIR_ORDER_DATE,             
PART_TYPE,                     
ENG_SITE,                      
TURBINE_NUMBER,                
JOB_INSPECTOR,                 
JOB_SHOP,                      
JOB_TECHNOLOGY,                
USER_COMMENTS,                 
CUST_SEQ_ID,                   
SITE_SEQ_ID,                   
PLDB_JOB,                      
SET_STATUS,                    
JOB_TRANSFERED,                                                                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)
SELECT	
STAGE_JOB_SEQ_ID,              
JOB_SEQ_ID,                    
JOB_NUMBER,                    
REPAIR_ORDER_DATE,             
PART_TYPE,                     
ENG_SITE,                      
TURBINE_NUMBER,                
JOB_INSPECTOR,                 
JOB_SHOP,                      
JOB_TECHNOLOGY,                
USER_COMMENTS,                 
CUST_SEQ_ID,                   
SITE_SEQ_ID,                   
PLDB_JOB,                      
SET_STATUS,                    
JOB_TRANSFERED,                 
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                  
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                  
FROM	 GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_JOB_S
MINUS
SELECT	
STAGE_JOB_SEQ_ID,              
JOB_SEQ_ID,                    
JOB_NUMBER,                    
REPAIR_ORDER_DATE,             
PART_TYPE,                     
ENG_SITE,                      
TURBINE_NUMBER,                
JOB_INSPECTOR,                 
JOB_SHOP,                      
JOB_TECHNOLOGY,                
USER_COMMENTS,                 
CUST_SEQ_ID,                   
SITE_SEQ_ID,                   
PLDB_JOB,                      
SET_STATUS,                    
JOB_TRANSFERED,               
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                 
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_EPIP_STAGE_JOB;

-- Table: VT_CDR_PLP_EPIP_STAGE_JOB : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_JOB_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_EPIP_STAGE_JOB_S
(	
STAGE_JOB_SEQ_ID,              
JOB_SEQ_ID,                    
JOB_NUMBER,                    
REPAIR_ORDER_DATE,             
PART_TYPE,                     
ENG_SITE,                      
TURBINE_NUMBER,                
JOB_INSPECTOR,                 
JOB_SHOP,                      
JOB_TECHNOLOGY,                
USER_COMMENTS,                 
CUST_SEQ_ID,                   
SITE_SEQ_ID,                   
PLDB_JOB,                      
SET_STATUS,                    
JOB_TRANSFERED,                  
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                    
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 
STAGE_JOB_SEQ_ID,              
JOB_SEQ_ID,                    
JOB_NUMBER,                    
REPAIR_ORDER_DATE,             
PART_TYPE,                     
ENG_SITE,                      
TURBINE_NUMBER,                
JOB_INSPECTOR,                 
JOB_SHOP,                      
JOB_TECHNOLOGY,                
USER_COMMENTS,                 
CUST_SEQ_ID,                   
SITE_SEQ_ID,                   
PLDB_JOB,                      
SET_STATUS,                    
JOB_TRANSFERED,                 
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY, 
CURRENT_DATE,                
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_EPIP_STAGE_JOB;	

-- Table: CDR_PLP_EPIP_STAGE_JOB: End




