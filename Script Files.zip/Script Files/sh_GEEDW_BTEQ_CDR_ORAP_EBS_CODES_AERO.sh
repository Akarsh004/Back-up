# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ORAP_EBS_CODES_AERO.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Aliva
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ORAP_EBS_CODES_AERO : Start	




-- Table: CDR_ORAP_EBS_CODES_AERO : End




