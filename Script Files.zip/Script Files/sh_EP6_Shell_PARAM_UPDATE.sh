#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_EP6_GENERIC_SESS_WFLW_DTLS.sh
# Creation Date:31/10/2012
# Last Modified: 31/10/12
# Purpose:Collection of session details from stage session of turbine for GVL.
# Created By: Rajasekhar Pola
# 
# This Script:
# 1) This script will update the parameter files
#
#  Arg 1: file name
#  Arg 2: Target file name to collect the details
# ----------------------------------------------------------------------------	

########## Variables Declaration Starts #############
ServerPath=/data/informatica/ETCOE/EEDW01/
Scriptpath=$ServerPath/ScriptFiles/
parm_path=$ServerPath/Config/
cd $parm_path
sys_date=`date +'%d'`
PARAM=$parm_path/PARAM_EP6_STG_BASE.txt
PARAM_temp=$parm_path/PARAM_EP6_STG_BASE_temp.txt

########## Variables Declaration END #############

### UPDATE THE EP6_GVL_GT765_LAST_LOAD_DATE IN PARAMETER FILE WITH SYSDATE

# DATE VALUE STORING IN VARIABLE

Lase_extn_dt=`date --date="-1 day" +"%m-%d-%Y %r"`
echo "$Lase_extn_dt"

## EXISTING VALUE OF LASTLOAD DATE
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_GT765_LAST_LOAD_DATE"`
echo "$Last_extn_date_var"

#LAST LOAD DATE ONLY
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`

#REPLACE THE OLD DATE WITH NEW DATE
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE P6_GVL_GT765_ADDT_LAST_LOAD_DATE IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%m-%d-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "P6_GVL_GT765_ADDT_LAST_LOAD_DATE"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_UNT_RTR_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_UNT_RTR_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_TRBN_RTR_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_TRBN_RTR_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_TRBN_SHL_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_TRBN_SHL_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_NZL_ST_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_NZL_ST_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_SRD_ST_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_SRD_ST_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_NZL_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_NZL_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM

### UPDATE THE EP6_GVL_SRD_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_SRD_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_MES_TP_STG_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%m-%d-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_MES_TP_STG_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_MES_LINER_STG_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%m-%d-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_MES_LINER_STG_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM



### UPDATE THE EP6_GVL_PCF_FN_FCD_CMBSTN_STG_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_PCF_FN_FCD_CMBSTN_STG_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_PCF_CAP_FCD_CMBSTN_STG_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_PCF_CAP_FCD_CMBSTN_STG_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_GVL_BMW_CHRT_STG_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_GVL_BMW_CHRT_STG_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_HNGRY_HOT_GAS_PRTS_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_HNGRY_HOT_GAS_PRTS_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM


### UPDATE THE EP6_HNGRY_CMBTN_PRTS_LST_LD_DT IN PARAMETER FILE WITH SYSDATE

Lase_extn_dt=`date --date="-1 day" +"%d-%m-%Y %r"`
echo "$Lase_extn_dt"
Last_extn_date_var=`cat $PARAM|grep "EP6_HNGRY_CMBTN_PRTS_LST_LD_DT"`
echo "$Last_extn_date_var"
curn_lst_extn_val=`echo $Last_extn_date_var|awk -F"=" '{print $1}'`
echo "$curn_lst_extn_val"
date_lst_extn_tab1=`echo $Last_extn_date_var|awk -F"=" '{print $2}'`
sed "s/$Last_extn_date_var/$curn_lst_extn_val"="$Lase_extn_dt/g" $PARAM  > $PARAM_temp
cp $PARAM_temp $PARAM
