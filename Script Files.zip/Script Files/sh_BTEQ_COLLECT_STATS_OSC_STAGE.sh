#########################################################################################
##      Script:sh_BTEQ_COLLECT_STATS_OSC_STAGE.sh                                       ##
##      This script is used to collect stats of CDR_OSC_ODS_ENGINE STAGE table.         ##
##      Created by:Harsha T                                                             ##
##       Created Date:13/10/2102                                                        ##
##       Last_modified_date:16/10/2012                                                  ##
#########################################################################################



. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq <<EOF

.RUN File = ${SrcDir}/td_plp.mlbt

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database GEEDW_PLP_S;



COLLECT STATS ON CDR_OSC_ODS_ENGINE COLUMN (EQUIPMENT_SERIAL_NUMBER);
COLLECT STATS ON CDR_OSC_ODS_ENGINE COLUMN (CONTRACT_NUMBER);



.LOGOFF
.EXIT 0
EOF

bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"
