# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_ODS_T_CLIN.sh 
# Creation Date: 07/28/11 
# Last Modified: 07/28/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
.RUN File = ${SrcDir}/td_plp.mlbt

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_ODS_T_CLIN : Start	

---- DROP TABLE VT_CDR_ODS_T_CLIN;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_T_CLIN,NO LOG (
ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
OWNER VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
DESCRIPTION VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
POLICY VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
STATE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
PREVIOUS_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
NEXT_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
FIRST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
LATEST_REVISION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD',
SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD',
SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD',
ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
PER_UNIT_COST INTEGER,
PER_UNIT_COST_IN VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
VERIFIED_BY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CLIN_TASKING VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
REQUIREMENT_CATGRY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
DESIGNATED_USER VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CONTENT_TEXT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
SPONSORING_CUST VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
GE_INDR VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CLIN_TEXT_RQRMNT VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
SOW_PARAGRAPH VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CLIN_CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
ORIG VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CLIN VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CONTENT_DATA VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
PRIORITY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
USER_REQUIREMENT_IMPORTANCE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
NOTES VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
CONTENT_TYPE VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
ESTIMATED_COST INTEGER,
CLIN_INITIAL_DELIVERY_DATE DATE FORMAT 'YYYY-MM-DD',
DIFFICULTY VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
VERIFICATION_METHOD VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
SYNOPSIS VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
REQUIREMENT_CLSF VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC

)

PRIMARY INDEX ( ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_T_CLIN : Processing : Populate GT table with CDC data	

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_T_CLIN
(
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,PER_UNIT_COST                 
,PER_UNIT_COST_IN              
,VERIFIED_BY                   
,CLIN_TASKING                  
,REQUIREMENT_CATGRY            
,DESIGNATED_USER               
,CONTENT_TEXT                  
,SPONSORING_CUST               
,GE_INDR                       
,CLIN_TEXT_RQRMNT              
,SOW_PARAGRAPH                 
,CLIN_CREATION_DATE            
,ORIG                          
,CLIN                          
,CONTENT_DATA                  
,PRIORITY                      
,USER_REQUIREMENT_IMPORTANCE   
,NOTES                         
,CONTENT_TYPE                  
,ESTIMATED_COST                
,CLIN_INITIAL_DELIVERY_DATE    
,DIFFICULTY                    
,VERIFICATION_METHOD           
,SYNOPSIS                      
,REQUIREMENT_CLSF                 
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
             
            
           
                
)

SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,PER_UNIT_COST                 
,PER_UNIT_COST_IN              
,VERIFIED_BY                   
,CLIN_TASKING                  
,REQUIREMENT_CATGRY            
,DESIGNATED_USER               
,CONTENT_TEXT                  
,SPONSORING_CUST               
,GE_INDR                       
,CLIN_TEXT_RQRMNT              
,SOW_PARAGRAPH                 
,CLIN_CREATION_DATE            
,ORIG                          
,CLIN                          
,CONTENT_DATA                  
,PRIORITY                      
,USER_REQUIREMENT_IMPORTANCE   
,NOTES                         
,CONTENT_TYPE                  
,ESTIMATED_COST                
,CLIN_INITIAL_DELIVERY_DATE    
,DIFFICULTY                    
,VERIFICATION_METHOD           
,SYNOPSIS                      
,REQUIREMENT_CLSF                       
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
                
FROM GEEDW_PLP_S.CDR_ODS_T_CLIN_S
MINUS
SELECT 
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,PER_UNIT_COST                 
,PER_UNIT_COST_IN              
,VERIFIED_BY                   
,CLIN_TASKING                  
,REQUIREMENT_CATGRY            
,DESIGNATED_USER               
,CONTENT_TEXT                  
,SPONSORING_CUST               
,GE_INDR                       
,CLIN_TEXT_RQRMNT              
,SOW_PARAGRAPH                 
,CLIN_CREATION_DATE            
,ORIG                          
,CLIN                          
,CONTENT_DATA                  
,PRIORITY                      
,USER_REQUIREMENT_IMPORTANCE   
,NOTES                         
,CONTENT_TYPE                  
,ESTIMATED_COST                
,CLIN_INITIAL_DELIVERY_DATE    
,DIFFICULTY                    
,VERIFICATION_METHOD           
,SYNOPSIS                      
,REQUIREMENT_CLSF                     
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
             
              


FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_T_CLIN;	




-- Table: VT_CDR_ODS_T_CLIN : Processing : Populate Stage table with CDC data only for mLDM processing	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_T_CLIN_S;	

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_T_CLIN_S
(	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,PER_UNIT_COST                 
,PER_UNIT_COST_IN              
,VERIFIED_BY                   
,CLIN_TASKING                  
,REQUIREMENT_CATGRY            
,DESIGNATED_USER               
,CONTENT_TEXT                  
,SPONSORING_CUST               
,GE_INDR                       
,CLIN_TEXT_RQRMNT              
,SOW_PARAGRAPH                 
,CLIN_CREATION_DATE            
,ORIG                          
,CLIN                          
,CONTENT_DATA                  
,PRIORITY                      
,USER_REQUIREMENT_IMPORTANCE   
,NOTES                         
,CONTENT_TYPE                  
,ESTIMATED_COST                
,CLIN_INITIAL_DELIVERY_DATE    
,DIFFICULTY                    
,VERIFICATION_METHOD           
,SYNOPSIS                      
,REQUIREMENT_CLSF                      
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 
                
               


)
SELECT	
ID                            
,NAME                          
,REVISION                      
,VAULT                         
,OWNER                         
,DESCRIPTION                   
,POLICY                        
,STATE                         
,PREVIOUS_REVISION_ID          
,NEXT_REVISION_ID              
,FIRST_REVISION_ID             
,LATEST_REVISION_ID            
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,ALTOWNER1                     
,ALTOWNER2                     
,PER_UNIT_COST                 
,PER_UNIT_COST_IN              
,VERIFIED_BY                   
,CLIN_TASKING                  
,REQUIREMENT_CATGRY            
,DESIGNATED_USER               
,CONTENT_TEXT                  
,SPONSORING_CUST               
,GE_INDR                       
,CLIN_TEXT_RQRMNT              
,SOW_PARAGRAPH                 
,CLIN_CREATION_DATE            
,ORIG                          
,CLIN                          
,CONTENT_DATA                  
,PRIORITY                      
,USER_REQUIREMENT_IMPORTANCE   
,NOTES                         
,CONTENT_TYPE                  
,ESTIMATED_COST                
,CLIN_INITIAL_DELIVERY_DATE    
,DIFFICULTY                    
,VERIFICATION_METHOD           
,SYNOPSIS                      
,REQUIREMENT_CLSF                     
,CURRENT_DATE                 
,'CDR'                 
,CURRENT_DATE                 
,'CDR'                
                  
  
             
            

FROM VT_CDR_ODS_T_CLIN;	


-- Table: CDR_ODS_T_CLIN : End
