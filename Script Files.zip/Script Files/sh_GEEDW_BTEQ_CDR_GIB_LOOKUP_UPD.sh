# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_GIB_LOOKUP.sh 
# Creation Date: 07/29/10 
# Last Modified: 07/29/10
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
#
# ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_GIB_LOOKUP : Start	

---- DROP TABLE VT_CDR_GIB_LOOKUP;	


CREATE VOLATILE TABLE VT_CDR_GIB_LOOKUP ,NO LOG (
	        TABLEID VARCHAR(15) CHARACTER SET UNICODE NOT CASESPECIFIC,
		CODE VARCHAR(15) CHARACTER SET UNICODE NOT CASESPECIFIC,
		CODE_DESC VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
		DW_LOAD_DATE DATE FORMAT 'YY/MM/DD',
		DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
	        DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD',
	        DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX ( TABLEID, CODE ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_GIB_LOOKUP : Processing : Populate GT table with CDC data	

INSERT INTO VT_CDR_GIB_LOOKUP 
(
TABLEID,
CODE,
CODE_DESC
)
SELECT 
TABLEID,
CODE,
CODE_DESC
FROM GEEDW_PLP_S.CDR_GIB_LOOKUP	
MINUS
SELECT 
TABLEID,
CODE,
CODE_DESC
FROM GEEDW_PLP_BULK_T.CDR_GIB_LOOKUP;	


-- Table: VT_CDR_GIB_LOOKUP : Processing : Populate Stage table with CDC data only for mLDM processing	

DELETE GEEDW_PLP_S.CDR_GIB_LOOKUP;	


INSERT INTO GEEDW_PLP_S.CDR_GIB_LOOKUP 
(	
TABLEID,
CODE,
CODE_DESC,           
DW_LOAD_DATE,                  
DW_CREATED_BY,                
DW_UPDATED_DATE,               
DW_UPDATED_BY
)	
SELECT 
TABLEID,
CODE,
CODE_DESC,                     
CURRENT_DATE,
'GIB',
CURRENT_DATE,
'GIB'
FROM VT_CDR_GIB_LOOKUP;	


-- Table: CDR_GIB_LOOKUP : End


