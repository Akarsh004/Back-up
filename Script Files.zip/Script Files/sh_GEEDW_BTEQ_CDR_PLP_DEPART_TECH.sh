# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DEPART_TECH.sh 
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_PLP_DEPART_TECH  : Start	

-- DROP TABLE VT_CDR_PLP_DEPART_TECH --;	

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_PLP_DEPART_TECH,NO LOG (
   
      DEPART_FORM_SEQ_ID INTEGER  ,
      PAC_NUMBER VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PAC_COMPLETED INTEGER  ,
      FORCED_OUTAGE_FLAG INTEGER   ,
      EARLY_OUTAGE_FLAG INTEGER   ,
      START_CAPABILITY_FLAG INTEGER   ,
      REDUCED_OUTPUT_FLAG INTEGER   ,
      REDUCED_HEAT_RATE_FLAG INTEGER   ,
      INCRSD_EMISSIONS_FLAG INTEGER  ,
      FALL_OUTRATE_FLAG INTEGER  ,
      REPAIR_COST_FLAG INTEGER  ,
      REDUCED_PART_LIFE_FLAG INTEGER  ,
      RELBLTY_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PERFMNCE_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OWNERSHIP_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CONSUMABLES_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PRE_EXEC_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC  ,
      DURING_EXEC_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POST_EXEC_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PRE_DATA_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DURING_DATA_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      POST_DATA_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      SUBMIT_DATE DATE FORMAT 'YYYY-MM-DD' ,
      CREATOR_ID INTEGER ,
      APPROVAL_FLAG INTEGER ,
      APPROVAL_DATE DATE FORMAT 'YYYY-MM-DD' ,
      APPROVER_ID INTEGER,
      TECH_REJECTION_NOTES VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TRA_PRESENTATION VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PAC_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      FIRST_FACTORED_HOURS INTEGER ,
      FIRST_FACTORED_STARTS INTEGER ,
      ADMIN_CLOSE_FLAG INTEGER ,
      PAC_TEXT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )


 PRIMARY INDEX  (DEPART_FORM_SEQ_ID) ON COMMIT PRESERVE ROWS;

/* Table: CDR_PLP_DEPART_TECH : Processing : Populate GT table with CDC data */	

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_DEPART_TECH
(
DEPART_FORM_SEQ_ID            ,
PAC_NUMBER                    ,
PAC_COMPLETED                 ,
FORCED_OUTAGE_FLAG            ,
EARLY_OUTAGE_FLAG             ,
START_CAPABILITY_FLAG         ,
REDUCED_OUTPUT_FLAG           ,
REDUCED_HEAT_RATE_FLAG        ,
INCRSD_EMISSIONS_FLAG         ,
FALL_OUTRATE_FLAG             ,
REPAIR_COST_FLAG              ,
REDUCED_PART_LIFE_FLAG        ,
RELBLTY_COMMENT               ,
PERFMNCE_COMMENT              ,
OWNERSHIP_COMMENT             ,
CONSUMABLES_COMMENT           ,
PRE_EXEC_COMMENT              ,
DURING_EXEC_COMMENT           ,
POST_EXEC_COMMENT             ,
PRE_DATA_COMMENT              ,
DURING_DATA_COMMENT           ,
POST_DATA_COMMENT             ,
SUBMIT_DATE                   ,
CREATOR_ID                    ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
APPROVER_ID                   ,
TECH_REJECTION_NOTES          ,
TRA_PRESENTATION              ,
PAC_COMMENT                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
FIRST_FACTORED_HOURS          ,
FIRST_FACTORED_STARTS         ,
ADMIN_CLOSE_FLAG              ,
PAC_TEXT                      ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
                
)
SELECT 
DEPART_FORM_SEQ_ID            ,
PAC_NUMBER                    ,
PAC_COMPLETED                 ,
FORCED_OUTAGE_FLAG            ,
EARLY_OUTAGE_FLAG             ,
START_CAPABILITY_FLAG         ,
REDUCED_OUTPUT_FLAG           ,
REDUCED_HEAT_RATE_FLAG        ,
INCRSD_EMISSIONS_FLAG         ,
FALL_OUTRATE_FLAG             ,
REPAIR_COST_FLAG              ,
REDUCED_PART_LIFE_FLAG        ,
RELBLTY_COMMENT               ,
PERFMNCE_COMMENT              ,
OWNERSHIP_COMMENT             ,
CONSUMABLES_COMMENT           ,
PRE_EXEC_COMMENT              ,
DURING_EXEC_COMMENT           ,
POST_EXEC_COMMENT             ,
PRE_DATA_COMMENT              ,
DURING_DATA_COMMENT           ,
POST_DATA_COMMENT             ,
SUBMIT_DATE                   ,
CREATOR_ID                    ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
APPROVER_ID                   ,
TECH_REJECTION_NOTES          ,
TRA_PRESENTATION              ,
PAC_COMMENT                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
FIRST_FACTORED_HOURS          ,
FIRST_FACTORED_STARTS         ,
ADMIN_CLOSE_FLAG              ,
PAC_TEXT                      ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                                 
FROM GEEDW_PLP_S.CDR_PLP_DEPART_TECH_S
MINUS
SELECT
DEPART_FORM_SEQ_ID            ,
PAC_NUMBER                    ,
PAC_COMPLETED                 ,
FORCED_OUTAGE_FLAG            ,
EARLY_OUTAGE_FLAG             ,
START_CAPABILITY_FLAG         ,
REDUCED_OUTPUT_FLAG           ,
REDUCED_HEAT_RATE_FLAG        ,
INCRSD_EMISSIONS_FLAG         ,
FALL_OUTRATE_FLAG             ,
REPAIR_COST_FLAG              ,
REDUCED_PART_LIFE_FLAG        ,
RELBLTY_COMMENT               ,
PERFMNCE_COMMENT              ,
OWNERSHIP_COMMENT             ,
CONSUMABLES_COMMENT           ,
PRE_EXEC_COMMENT              ,
DURING_EXEC_COMMENT           ,
POST_EXEC_COMMENT             ,
PRE_DATA_COMMENT              ,
DURING_DATA_COMMENT           ,
POST_DATA_COMMENT             ,
SUBMIT_DATE                   ,
CREATOR_ID                    ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
APPROVER_ID                   ,
TECH_REJECTION_NOTES          ,
TRA_PRESENTATION              ,
PAC_COMMENT                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
FIRST_FACTORED_HOURS          ,
FIRST_FACTORED_STARTS         ,
ADMIN_CLOSE_FLAG              ,
PAC_TEXT                      ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                                
FROM GEEDW_PLP_BULK_T.CDR_PLP_DEPART_TECH;	


/* Table: VT_CDR_PLP_DEPART_TECH : Processing : Populate Stage table with CDC data only for mLDM processing  */	

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_DEPART_TECH_S;	

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_DEPART_TECH_S
(	
DEPART_FORM_SEQ_ID            ,
PAC_NUMBER                    ,
PAC_COMPLETED                 ,
FORCED_OUTAGE_FLAG            ,
EARLY_OUTAGE_FLAG             ,
START_CAPABILITY_FLAG         ,
REDUCED_OUTPUT_FLAG           ,
REDUCED_HEAT_RATE_FLAG        ,
INCRSD_EMISSIONS_FLAG         ,
FALL_OUTRATE_FLAG             ,
REPAIR_COST_FLAG              ,
REDUCED_PART_LIFE_FLAG        ,
RELBLTY_COMMENT               ,
PERFMNCE_COMMENT              ,
OWNERSHIP_COMMENT             ,
CONSUMABLES_COMMENT           ,
PRE_EXEC_COMMENT              ,
DURING_EXEC_COMMENT           ,
POST_EXEC_COMMENT             ,
PRE_DATA_COMMENT              ,
DURING_DATA_COMMENT           ,
POST_DATA_COMMENT             ,
SUBMIT_DATE                   ,
CREATOR_ID                    ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
APPROVER_ID                   ,
TECH_REJECTION_NOTES          ,
TRA_PRESENTATION              ,
PAC_COMMENT                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
FIRST_FACTORED_HOURS          ,
FIRST_FACTORED_STARTS         ,
ADMIN_CLOSE_FLAG              ,
PAC_TEXT                      ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                                 
)	
SELECT 
DEPART_FORM_SEQ_ID            ,
PAC_NUMBER                    ,
PAC_COMPLETED                 ,
FORCED_OUTAGE_FLAG            ,
EARLY_OUTAGE_FLAG             ,
START_CAPABILITY_FLAG         ,
REDUCED_OUTPUT_FLAG           ,
REDUCED_HEAT_RATE_FLAG        ,
INCRSD_EMISSIONS_FLAG         ,
FALL_OUTRATE_FLAG             ,
REPAIR_COST_FLAG              ,
REDUCED_PART_LIFE_FLAG        ,
RELBLTY_COMMENT               ,
PERFMNCE_COMMENT              ,
OWNERSHIP_COMMENT             ,
CONSUMABLES_COMMENT           ,
PRE_EXEC_COMMENT              ,
DURING_EXEC_COMMENT           ,
POST_EXEC_COMMENT             ,
PRE_DATA_COMMENT              ,
DURING_DATA_COMMENT           ,
POST_DATA_COMMENT             ,
SUBMIT_DATE                   ,
CREATOR_ID                    ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
APPROVER_ID                   ,
TECH_REJECTION_NOTES          ,
TRA_PRESENTATION              ,
PAC_COMMENT                   ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
LAST_UPDATED_BY               ,
FIRST_FACTORED_HOURS          ,
FIRST_FACTORED_STARTS         ,
ADMIN_CLOSE_FLAG              ,
PAC_TEXT                      ,
CURRENT_DATE,
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_DEPART_TECH;	


---Table: CDR_PLP_DEPART_TECH : End

