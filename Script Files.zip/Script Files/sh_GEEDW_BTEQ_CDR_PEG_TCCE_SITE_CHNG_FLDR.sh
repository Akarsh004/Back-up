// ---------------------------------------------------------------------------- 
//			
// File: sh_GEEDW_BTEQ_CDR_PEG_TCCE_SITE_CHNG_FLDR.sh 
// Creation Date: 04/16/10 
// Last Modified: 04/16/10
// Purpose:CDC Implementation on the Staging and Bulk databases
// Created By: Smruti/Tarkesh
//
// ----------------------------------------------------------------------------
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;

-- Table: CDR_PEG_TCCE_SITE_CHNG_FLDR : Start	

---- DROP TABLE VT_CDR_PEG_TCCE_SITE_CHNG_FLDR;	


CREATE VOLATILE TABLE VT_CDR_PEG_TCCE_SITE_CHNG_FLDR ,NO LOG		
     (		
       IPS_NUMBER VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      IPS_DESIGN_NO VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      DOC_NAME VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX  ( IPS_NUMBER ) ON COMMIT PRESERVE ROWS;



-- Table: CDR_PEG_TCCE_CLONE : Processing : Populate GT table with CDC data	

INSERT INTO VT_CDR_PEG_TCCE_SITE_CHNG_FLDR
(	
	IPS_NUMBER,                  
	IPS_DESIGN_NO,                 
	DOC_NAME     
)
SELECT 
        IPS_NUMBER,                  
	IPS_DESIGN_NO,                 
	DOC_NAME 
        FROM GEEDW_PLP_S.CDR_PEG_TCCE_SITE_CHNG_FLDR	
       
	MINUS
SELECT 
        IPS_NUMBER,                  
	IPS_DESIGN_NO,                 
	DOC_NAME
        FROM GEEDW_PLP_BULK_T.CDR_PEG_TCCE_SITE_CHNG_FLDR;	

-- Table: CDR_PEG_TCCE_CLONE : Processing : Append Bulk table with CDC data using Delete/Insert mechanism	

DELETE FROM GEEDW_PLP_BULK_T.CDR_PEG_TCCE_SITE_CHNG_FLDR 
WHERE 
( 
       IPS_NUMBER,                  
       IPS_DESIGN_NO,                 
       DOC_NAME
) 
IN 	
(
SELECT  
       IPS_NUMBER,                  
       IPS_DESIGN_NO,                 
       DOC_NAME
FROM VT_CDR_PEG_TCCE_SITE_CHNG_FLDR 
);	

INSERT INTO GEEDW_PLP_BULK_T.CDR_PEG_TCCE_SITE_CHNG_FLDR
(	
	IPS_NUMBER,                  
        IPS_DESIGN_NO,                 
        DOC_NAME,
	DW_LOAD_DATE,
	DW_CREATED_BY,
	DW_UPDATED_DATE,
	DW_UPDATED_BY
)	
SELECT 
	IPS_NUMBER,                  
        IPS_DESIGN_NO,                 
        DOC_NAME,
	CURRENT_DATE,
	'CDR',
	CURRENT_DATE,
	'CDR'
        FROM VT_CDR_PEG_TCCE_SITE_CHNG_FLDR;	

-- Table: VT_CDR_PEG_TCCE_SITE_CHNG_FLDR : Processing : Populate Stage table with CDC data only for mLDM processing	
DELETE FROM GEEDW_PLP_S.CDR_PEG_TCCE_SITE_CHNG_FLDR ;



INSERT INTO GEEDW_PLP_S.CDR_PEG_TCCE_SITE_CHNG_FLDR 
(	
	IPS_NUMBER,                  
        IPS_DESIGN_NO,                 
        DOC_NAME,
	DW_LOAD_DATE,
	DW_CREATED_BY,
	DW_UPDATED_DATE,
	DW_UPDATED_BY
)	
SELECT 
        IPS_NUMBER,                  
        IPS_DESIGN_NO,                 
        DOC_NAME,
	CURRENT_DATE,
	'CDR',
	CURRENT_DATE,
	'CDR'
	FROM VT_CDR_PEG_TCCE_SITE_CHNG_FLDR;	

-- Table: CDR_PEG_TCCE_SITE_CHNG_FLDR : End