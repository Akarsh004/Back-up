##############################################################################################
#######################created by Mahindra Satyam ############################################
##############################created date : 27th Oct 2010 ###################################
##############################Reviewed by :Smruti Patnaik ####################################
##############################Purpose : Getting BMIT Source Files from FTP server ############
############################################################################################## 

#bin bash

# GIVING THE USERNAME AND PASSWORD OF THE SERVER  FROM WHERE THE FILE IS TO BE FETCHED #
cd /data/informatica/ETCOE/EEDW01/SrcFiles/
# FETCHING FILES FROM THE CORPORATE SERVER #
sftp cdr_twd@Sftp.corporate.ge.com << EOF
# ENTERING THE PATH WHERE THE FILE IS STORED #
cd /cdr
# FETCHING THE FILES FROM THE CORPORATE SERVER #
get ITEM_DAILY_P3.TXT
get ITEM_DAILY_P5.TXT
quit
# GIVING ACCESS RIGHTS #
chmod 777 ITEM_DAILY_P3.TXT
chmod 777 ITEM_DAILY_P5.TXT
EOF
