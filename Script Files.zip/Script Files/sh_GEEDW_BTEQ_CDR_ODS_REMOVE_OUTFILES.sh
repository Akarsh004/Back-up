sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_CDR_ODS_REMOVE_OUTFILES1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_CDR_ODS_REMOVE_OUTFILES_LOG.txt 2>&1
