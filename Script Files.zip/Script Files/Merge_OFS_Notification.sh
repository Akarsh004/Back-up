
DL=tanwir.shaikh@ge.com,akarsh.singh@ge.com,Chandana.Ray@ge.com
set heading off;
set feedback off;
DL=`echo "$DL"| tr -d '\040\'`
echo "$DL"
VAR_1=`cat /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_OFS_MERGE1_LOG.txt | grep -i "FAILURE"`
XYZ=$?
if [ $XYZ = 0 ]
then
echo "Error"
(echo -e "Hi, \n This is an auto generated email for Merge execution failure. \n\nPlease take necessary steps to rectify the error.
\n\n Regards, \n OFS - ETL Team") | mailx -s "OFS Merge Execution Failed!!" $DL 
else
echo "No Error"
(echo -e "Hi, \n This is an auto generated email for ETL Workflow Completion Notification. \n\n wflw_GEEDW_OFS_BULK completed successfully \n\n If you observe data quality issue on EEDW views, please raise INC#  using http://helpdesk.ge.com  route to team CI = EEDW
\n\n Regards, \n Informatica server \n\n ======================================================\n OFS - ETL Team \n\n Email process issues to ETCOE EEDW Support  etcoe.eedw.support@ge.com") | mailx -s "OFS data sync completed" $DL
fi