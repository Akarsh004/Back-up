/* This is used for connecting to server and fetching files using FTP */
#bin bash
HOST='imsv08.sch.ge.com'
USER='plpcdr01'
PASSWD='cJyd4pa4'
DT=`date +%m%y`
ftp -v -n <<EOF
open $HOST
user $USER $PASSWD
cd /geedim/syslog
echo $DT
lcd /data/informatica/ETCOE/EEDW01/SrcFiles/
get ug_issue.rpt-$DT
quit
mv /data/informatica/ETCOE/EEDW01/SrcFiles/ug_issue.rpt-0209 /data/informatica/ETCOE/EEDW01/SrcFiles/docmaster.txt
EOF 

