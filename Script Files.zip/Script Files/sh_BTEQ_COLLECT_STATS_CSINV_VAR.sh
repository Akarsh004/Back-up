#########################################################################################
##                                                                                     ##
##   Script:sh_BTEQ_COLLECT_STATS_CSINV_VAR.sh                                         ##
##   Creation Date:13/10/12                                                            ##
##   Last Modified:16/10/12                                                            ##
##   Purpose:This script is used to collect stats of CDR_CS_PLD_VAR table.             ##
##   Created By: Harsha                                                                ##
##                                                                                     ##
#########################################################################################

. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq <<EOF

.RUN File = ${SrcDir}/td_plp.mlbt

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database GEEDW_PLP_S;

COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (CS_TRB_NUM);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (ED_TRB_NUM);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (CS_PRT_SR);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (ED_PRT_SR);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (CS_DRW_SR);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (ED_DRW_SR);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CS_PLD_VAR COLUMN (FISCAL_WEEK_NUM);

.LOGOFF
.EXIT 0
EOF
bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"