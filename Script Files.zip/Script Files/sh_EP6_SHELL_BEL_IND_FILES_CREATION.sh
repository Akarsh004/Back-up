#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_EP6_SHELL_BEL_IND_FILES_CREATION.sh
# Creation Date:31/10/2012
# Last Modified: 31/10/12
# Purpose:Collection of session details from stage session of turbine for GVL.
# Created By: Rajasekhar Pola
# 
# This Script:
# 1) This script will collect the session run details and stoore in one file
# 2) This script takes 2paremeters as aruguments 
#
#  Arg 1: Log file name
#  Arg 2: Target file name to collect the details
# ----------------------------------------------------------------------------	

######################   VARIABLE PATHS DECLARATIONS  ###############
	server_path=/data/informatica/ETCOE/EEDW01
	bel_srcpath=$server_path/SrcFiles/SD/BELFORT
	inf_srcpath=$server_path/SrcFiles/INFA/BELFORT

# TURBINE BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	trbn_path=$bel_srcpath/TRBN
	trbn_srcpath=$inf_srcpath/TRBN

# UNIT ROTOR BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	unttrbn_path=$bel_srcpath/UNTRTR
	unttrbn_srcpath=$inf_srcpath/UNTRTR

# TURBINE ROTOR BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	trbnrtr_path=$bel_srcpath/TRBNRTR
	trbnrtr_srcpath=$inf_srcpath/TRBNRTR

# BKT BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	bkt_path=$bel_srcpath/BKT
	bkt_srcpath=$inf_srcpath/BKT

# SET NOZZLE BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	set_nzle_path=$bel_srcpath/SET_NZZLE
	set_nzle_srcpath=$inf_srcpath/SET_NZZLE

# SET SHROUD BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	set_shrd_path=$bel_srcpath/SET_SHRD
	set_shrd_srcpath=$inf_srcpath/SET_SHRD

# NOZZLE BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	nzle_path=$bel_srcpath/NOZZLE
	nzle_srcpath=$inf_srcpath/NOZZLE

# SHROUD BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	shrd_path=$bel_srcpath/SHROUD
	shrd_srcpath=$inf_srcpath/SHROUD

# TP BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	tp_path=$bel_srcpath/TP
	tp_srcpath=$inf_srcpath/TP

# LINER BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	liner_path=$bel_srcpath/LINER
	liner_srcpath=$inf_srcpath/LINER

# FUEL NOZZLE BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	fn_path=$bel_srcpath/FN
	fn_srcpath=$inf_srcpath/FN

# CAPS BELEOFRT SRC FILES PATH AND INFORMATICA PATHS
	caps_path=$bel_srcpath/CAPS
	caps_srcpath=$inf_srcpath/CAPS


##################### VARIABLE PATHS DECLARATIONS END ##############

######################   VARIABLE FILES DECLARATIONS  ###############
trbn_inf_src_file=$trbn_srcpath/Turbine_bel_data.dat

untrtr_inf_src_file=$unttrbn_srcpath/unt_rtr_file_list

trbnrtr_inf_src_file=$trbnrtr_srcpath/LKP_TRBN_RTR.txt
bktchrt_inf_src_file=$trbnrtr_srcpath/SRC_BCKT_CHART.txt
tr_ur_inf_src_file=$trbnrtr_srcpath/LKP_TR_UR.txt

bkt_chrt_inf_src_file=$bkt_srcpath/BCKT_CHRT_BEL_STG.txt
bkt_inf_src_file=$bkt_srcpath/BCKT_CMPNT_BEL_STG.txt

set_nzle_trbn_inf_src_file=$set_nzle_srcpath/SET_NZL_TRBN_LIST.txt
set_shrd_trbn_inf_src_file=$set_shrd_srcpath/SET_SRD_TRBN_LIST.txt

nzle_shrd_cmpnt_inf_src=$nzle_srcpath/CMPNT_LIST.txt
nzle_set_inf_src_file=$nzle_srcpath/NZL_SET_LIST.txt

shrd_set_inf_src_file=$shrd_srcpath/SRD_SET_LIST.txt

tp_inf_src_file=$tp_srcpath/TP_Bel_stg.dat

liner_inf_src_file=$liner_srcpath/LINER_Bel_stg.dat
liner_caps_asmb_inf_src_file=$liner_srcpath/LC_Bel_stg.dat

fn_inf_src_file=$fn_srcpath/FN_Filelist.lst

caps_inf_src_file=$caps_srcpath/CAP_Filelist.lst


##################### VARIABLE FILES DECLARATIONS END ##############



TRBN
{
cd $trbn_path

mv *.* $trbn_srcpath/

cd $trbn_srcpath

ls *.dar > $trbn_inf_src_file

}

UNTRTR
{
cd $unttrbn_path

mv *.* $unttrbn_srcpath/

cd $unttrbn_srcpath/

ls *.dar > $untrtr_inf_src_file

}

TRBNRTR
{
cd $trbnrtr_path

mv *.* $trbnrtr_srcpath/

cd $trbnrtr_srcpath

ls *.dat > $trbnrtr_inf_src_file
ls RAC*.arb > $bktchrt_inf_src_file
ls RPGT*.arb > $tr_ur_inf_src_file
ls RFC*.arb >> $tr_ur_inf_src_file


}

BKT
{

cd $bkt_path

mv *.* $bkt_srcpath/

cd $bkt_srcpath/

ls BAC*.arb > $bkt_inf_src_file
ls BAC*.dat > $bkt_chrt_inf_src_file
}

SET_NZZLE
{

cd $set_nzle_path/

mv *.* $set_nzle_srcpath/

cd $set_nzle_srcpath/

ls *.dar > $set_nzle_trbn_inf_src_file

}

SET_SHRD
{
cd $set_shrd_path/

mv *.* $set_shrd_srcpath/

cd $set_shrd_srcpath/

ls *.dar > $set_shrd_trbn_inf_src_file
}

NOZZLE
{
cd $nzle_path

mv *.* $nzle_srcpath/

cd $shrd_path

mv *.arb $nzle_srcpath/

cd  $nzle_srcpath/

ls *.arb > $nzle_shrd_cmpnt_inf_src

ls *.dat > $nzle_set_inf_src_file

}

SHROUD
{

cd $shrd_path

mv *.* $shrd_srcpath/

cd  $shrd_srcpath/

touch test.dat

ls *.dat > $shrd_set_inf_src_file

}


TP
{

cd $tp_path
mv *.* $tp_srcpath/

cd $tp_srcpath/
ls *.dar > $tp_inf_src_file
}


LINER
{

cd $liner_path
mv *.* $liner_srcpath/
cd $liner_srcpath/

ls *.dar|egrep -v "6B|7E|7EA|7B|9B|9C|9EA|9E|5D|5PA|5Other|OtherOther" > $liner_inf_src_file

ls *.dar|egrep "6B|7E|7EA|7B|9B|9C|9EA|9E|5D|5PA|5Other|OtherOther" > $liner_caps_asmb_inf_src_file

}


FN
{

cd $fn_path
mv *.* $fn_srcpath/
cd $fn_srcpath/

ls *.dar > $fn_inf_src_file
}



CAPS
{

cd $caps_path
mv *.* $caps_srcpath/
cd $caps_srcpath/

ls *.dar > $caps_inf_src_file
}


TRBN
UNTRTR
TRBNRTR
BKT
SET_NZZLE
SET_SHRD
NOZZLE
SHROUD
TP
LINER
FN
CAPS