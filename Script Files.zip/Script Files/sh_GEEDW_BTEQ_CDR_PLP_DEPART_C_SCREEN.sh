# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_DEPART_C_SCREEN.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu
#------------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---- Table: CDR_PLP_DEPART_C_SCREEN : Start	

---- DROP TABLE VT_CDR_PLP_DEPART_C_SCREEN;	

CREATE VOLATILE TABLE VT_CDR_PLP_DEPART_C_SCREEN,NO LOG (
      DEPART_FORM_SEQ_ID INTEGER,
      COMP_CONTRACT_FLAG INTEGER,
      FLEET_WIDE_FLAG INTEGER,
      FLEET_WIDE_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      SIMILAR_UNITS VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      CONTRACT_OPS VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      APPROVAL_FLAG INTEGER,
      APPROVAL_COMMENT VARCHAR(4000) CHARACTER SET LATIN NOT CASESPECIFIC,
      APPROVAL_DATE DATE FORMAT 'YYYY-MM-DD',
      APPROVER_ID INTEGER,
      CREATOR_ID INTEGER,
      SUBMIT_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      ADMIN_CLOSE_FLAG INTEGER,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( DEPART_FORM_SEQ_ID );



INSERT INTO VT_CDR_PLP_DEPART_C_SCREEN
(
DEPART_FORM_SEQ_ID,            
COMP_CONTRACT_FLAG,            
FLEET_WIDE_FLAG,               
FLEET_WIDE_COMMENT,            
SIMILAR_UNITS,                 
CONTRACT_OPS,                  
APPROVAL_FLAG,                 
APPROVAL_COMMENT,              
APPROVAL_DATE,                 
APPROVER_ID,                   
CREATOR_ID,                    
SUBMIT_DATE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
ADMIN_CLOSE_FLAG,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                                                                                    
)
SELECT	
DEPART_FORM_SEQ_ID,            
COMP_CONTRACT_FLAG,            
FLEET_WIDE_FLAG,               
FLEET_WIDE_COMMENT,            
SIMILAR_UNITS,                 
CONTRACT_OPS,                  
APPROVAL_FLAG,                 
APPROVAL_COMMENT,              
APPROVAL_DATE,                 
APPROVER_ID,                   
CREATOR_ID,                    
SUBMIT_DATE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
ADMIN_CLOSE_FLAG,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY 
FROM	 GEEDW_PLP_S.CDR_PLP_DEPART_C_SCREEN_S
MINUS
SELECT	
DEPART_FORM_SEQ_ID,            
COMP_CONTRACT_FLAG,            
FLEET_WIDE_FLAG,               
FLEET_WIDE_COMMENT,            
SIMILAR_UNITS,                 
CONTRACT_OPS,                  
APPROVAL_FLAG,                 
APPROVAL_COMMENT,              
APPROVAL_DATE,                 
APPROVER_ID,                   
CREATOR_ID,                    
SUBMIT_DATE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
ADMIN_CLOSE_FLAG,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_DEPART_C_SCREEN;

-- Table: VT_CDR_PLP_DEPART_C_SCREEN : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_DEPART_C_SCREEN_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_DEPART_C_SCREEN_S
(	
DEPART_FORM_SEQ_ID,            
COMP_CONTRACT_FLAG,            
FLEET_WIDE_FLAG,               
FLEET_WIDE_COMMENT,            
SIMILAR_UNITS,                 
CONTRACT_OPS,                  
APPROVAL_FLAG,                 
APPROVAL_COMMENT,              
APPROVAL_DATE,                 
APPROVER_ID,                   
CREATOR_ID,                    
SUBMIT_DATE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
ADMIN_CLOSE_FLAG,              
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY       
)	
SELECT 
DEPART_FORM_SEQ_ID,            
COMP_CONTRACT_FLAG,            
FLEET_WIDE_FLAG,               
FLEET_WIDE_COMMENT,            
SIMILAR_UNITS,                 
CONTRACT_OPS,                  
APPROVAL_FLAG,                 
APPROVAL_COMMENT,              
APPROVAL_DATE,                 
APPROVER_ID,                   
CREATOR_ID,                    
SUBMIT_DATE,                   
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
ADMIN_CLOSE_FLAG,              
CURRENT_DATE,                              
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_DEPART_C_SCREEN;	

-- Table: CDR_PLP_DEPART_C_SCREEN : End