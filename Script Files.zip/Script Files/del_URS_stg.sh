bteq <<EOF

 /* .RUN File = /data/informatica/ETCOE/EEDW01/SrcFiles/td_plp.mlbt ; */

  .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

DELETE FROM GEEDW_PLP_S.CDR_URS_TDETL;    
DELETE FROM GEEDW_PLP_S.CDR_URS_TDTXT;
DELETE FROM GEEDW_PLP_S.CDR_URS_THTXT;
DELETE FROM GEEDW_PLP_S.CDR_URS_TTURB;

.LOGOFF;
.EXIT;
EOF
