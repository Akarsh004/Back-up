##########################################################################################
##############################created by Mahindra Satyam #################################
##############################created date : 27th Oct 2010 ##############################
##############################Reviewed by :Smruti Patnaik ################################
##############################Purpose : Archieving Flat Files #############################
##########################################################################################

#bin bash
cd /data/informatica/ETCOE/EEDW01/SrcFiles/
gzip BMIT.txt
mv BMIT.txt.gz /data/informatica/ETCOE/EEDW01/OutFiles/BMIT.txt.gz-`date +%d%m%y`
cd /data/informatica/ETCOE/EEDW01/OutFiles/
chmod 777 BMIT.txt.gz-`date +%d%m%y`
sftp cdr_twd@Sftp.corporate.ge.com << EOF
cd /cdr/BMIT
put BMIT.txt.gz-`date +%d%m%y`
quit
chmod 777 BMIT.txt.gz-`date +%d%m%y`
EOF

