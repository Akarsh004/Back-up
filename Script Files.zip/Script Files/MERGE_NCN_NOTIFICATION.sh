
DL=tanwir.shaikh@ge.com,akarsh.singh@ge.com,Chandana.Ray@ge.com
set heading off;
set feedback off;
DL=`echo "$DL"| tr -d '\040\'`
echo "$DL"
VAR_1=`cat /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_NCN_MERGE1_LOG.txt | grep -i "FAILURE"`
XYZ=$?
if [ $XYZ = 0 ]
then
echo "Error"
(echo -e "Hi, \n This is an auto generated email for NCN Merge execution failure. \n\nPlease take necessary steps to rectify the error.
\n\n Regards, \n PLM - ETL Team") | mailx -s "NCN Merge Execution Failed!!" $DL 
else
echo "No Error"
(echo -e "Hi, \n This is an auto generated email for Merge execution success. 
\n\n Regards, \n PLM - ETL Team") | mailx -s "Merge Execution Succeeded for NCN!!" $DL 
fi