# ---------------------------------------------------------------------------- 
#
# File: sh_GEEDW_BTEQ_CDR_ODS_R_GE_COST_FEATURE.sh 
# Creation Date: 06/20/11
# Last Modified: 06/20/11
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Dipankar 
#
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */ 

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt;  

database ${Stg_database};

-- Table: CDR_ODS_R_GE_COST_FEATURE : Start

---- DROP TABLE VT_CDR_ODS_R_GE_COST_FEATURE;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */

CREATE VOLATILE TABLE VT_CDR_ODS_R_GE_COST_FEATURE,NO LOG (
      RELATION_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_TYPE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_ID VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_TYPE VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_NAME VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_REVISION VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_VAULT VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROZEN_IND VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATE_DATE DATE FORMAT 'YYYY-MM-DD',
      SOURCE_MODIFIED_DATE DATE FORMAT 'YYYY-MM-DD',
      SOURCE_ORIGINATED_DATE DATE FORMAT 'YYYY-MM-DD',
      OWNER_COL VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ALTOWNER1 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      ALTOWNER2 VARCHAR(128) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( RELATION_ID ) ON COMMIT PRESERVE ROWS;


-- Table: CDR_ODS_R_GE_COST_FEATURE: Processing : Populate GT table with CDC data

/* INSERTING INTO THE VOLATILE TABLE */

INSERT INTO VT_CDR_ODS_R_GE_COST_FEATURE
(
 RELATION_ID                   
,FROM_ID                       
,FROM_TYPE                     
,FROM_NAME                     
,FROM_REVISION                 
,FROM_VAULT                    
,TO_ID                         
,TO_TYPE                       
,TO_NAME                       
,TO_REVISION                   
,TO_VAULT                      
,FROZEN_IND                    
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,OWNER_COL                     
,ALTOWNER1                     
,ALTOWNER2
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 

)

SELECT 
 RELATION_ID                   
,FROM_ID                       
,FROM_TYPE                     
,FROM_NAME                     
,FROM_REVISION                 
,FROM_VAULT                    
,TO_ID                         
,TO_TYPE                       
,TO_NAME                       
,TO_REVISION                   
,TO_VAULT                      
,FROZEN_IND                    
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,OWNER_COL                     
,ALTOWNER1                     
,ALTOWNER2
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 

FROM GEEDW_PLP_S.CDR_ODS_R_GE_COST_FEATURE_S
MINUS
SELECT 
 RELATION_ID                   
,FROM_ID                       
,FROM_TYPE                     
,FROM_NAME                     
,FROM_REVISION                 
,FROM_VAULT                    
,TO_ID                         
,TO_TYPE                       
,TO_NAME                       
,TO_REVISION                   
,TO_VAULT                      
,FROZEN_IND                    
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,OWNER_COL                     
,ALTOWNER1                     
,ALTOWNER2
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY                 

FROM GEEDW_PLM_ODS_BULK_T.CDR_ODS_R_GE_COST_FEATURE;




-- Table: VT_CDR_ODS_R_GE_COST_FEATURE : Processing : Populate Stage table with CDC data only for mLDM processing

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_ODS_R_GE_COST_FEATURE_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_ODS_R_GE_COST_FEATURE_S
(
 RELATION_ID                   
,FROM_ID                       
,FROM_TYPE                     
,FROM_NAME                     
,FROM_REVISION                 
,FROM_VAULT                    
,TO_ID                         
,TO_TYPE                       
,TO_NAME                       
,TO_REVISION                   
,TO_VAULT                      
,FROZEN_IND                    
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,OWNER_COL                     
,ALTOWNER1                     
,ALTOWNER2
,DW_LOAD_DATE                  
,DW_CREATED_BY                 
,DW_UPDATED_DATE               
,DW_UPDATED_BY
)
SELECT 
 RELATION_ID                   
,FROM_ID                       
,FROM_TYPE                     
,FROM_NAME                     
,FROM_REVISION                 
,FROM_VAULT                    
,TO_ID                         
,TO_TYPE                       
,TO_NAME                       
,TO_REVISION                   
,TO_VAULT                      
,FROZEN_IND                    
,CREATED_BY                    
,CREATION_DATE                 
,LAST_UPDATED_BY               
,LAST_UPDATE_DATE              
,SOURCE_MODIFIED_DATE          
,SOURCE_ORIGINATED_DATE        
,OWNER_COL                     
,ALTOWNER1                     
,ALTOWNER2
,CURRENT_DATE                  
,'CDR'                 
,CURRENT_DATE                  
,'CDR' 

FROM VT_CDR_ODS_R_GE_COST_FEATURE;


