# ---------------------------------------------------------------------------- 
# File: sh_GEEDW_BTEQ_CDR_PLP_DPRT_PRE_EXC_TRACK.sh
# Creation Date: 07/18/11 
# Last Modified: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Ragini
# ----------------------------------------------------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED #
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
 /* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

---Table: CDR_PLP_DPRT_PRE_EXC_TRACK  : Start

 DROP TABLE VT_CDR_PLP_DPRT_PRE_EXC_TRACK ;

/* CREATION OF A VOLATILE TABLE WHICH WILL HAVE DATA FROM STAGE MINUS BULK */
 CREATE VOLATILE TABLE VT_CDR_PLP_DPRT_PRE_EXC_TRACK,NO LOG (
      DEPART_FORM_SEQ_ID INTEGER  NOT NULL,
      SITE_BATTLE_GROUND INTEGER  NOT NULL,
      REASON_FOR_NO INTEGER ,
      OTHER_REASON VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PROPOSED_OUTAGE_FLAG INTEGER ,
      EBI_FLAG INTEGER ,
      EBI_ATTACH VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PAC_CASE_NUMBER VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PRE_DEPART_RECM INTEGER ,
      OLD_PROPOSED_DATE DATE FORMAT 'YYYY-MM-DD',
      APPROVER_ID INTEGER ,
      APPROVAL_FLAG INTEGER,
      APPROVAL_DATE DATE FORMAT 'YYYY-MM-DD',
      TOTAL_FIRED_HOURS INTEGER ,
      TOTAL_FIRED_STARTS INTEGER ,
      TOTAL_TRIPS INTEGER,
      INTERVAL_FIRED_HOURS INTEGER ,
      INTERVAL_FIRED_STARTS INTEGER ,
      INTERVAL_TRIPS INTEGER ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC  NOT NULL,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD'  NOT NULL,
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' NOT NULL,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX  ( DEPART_FORM_SEQ_ID );

---Table: CDR_PLP_DPRT_PRE_EXC_TRACK : Processing : Populate GT table with CDC data 

/*  INSERTING INTO THE VOLATILE TABLE */ 

INSERT INTO VT_CDR_PLP_DPRT_PRE_EXC_TRACK
(
DEPART_FORM_SEQ_ID            ,
SITE_BATTLE_GROUND            ,
REASON_FOR_NO                 ,
OTHER_REASON                  ,
PROPOSED_OUTAGE_FLAG          ,
EBI_FLAG                      ,
EBI_ATTACH                    ,
PAC_CASE_NUMBER               ,
PRE_DEPART_RECM               ,
OLD_PROPOSED_DATE             ,
APPROVER_ID                   ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
TOTAL_FIRED_HOURS             ,
TOTAL_FIRED_STARTS            ,
TOTAL_TRIPS                   ,
INTERVAL_FIRED_HOURS          ,
INTERVAL_FIRED_STARTS         ,
INTERVAL_TRIPS                ,
LAST_UPDATED_BY               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
DEPART_FORM_SEQ_ID            ,
SITE_BATTLE_GROUND            ,
REASON_FOR_NO                 ,
OTHER_REASON                  ,
PROPOSED_OUTAGE_FLAG          ,
EBI_FLAG                      ,
EBI_ATTACH                    ,
PAC_CASE_NUMBER               ,
PRE_DEPART_RECM               ,
OLD_PROPOSED_DATE             ,
APPROVER_ID                   ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
TOTAL_FIRED_HOURS             ,
TOTAL_FIRED_STARTS            ,
TOTAL_TRIPS                   ,
INTERVAL_FIRED_HOURS          ,
INTERVAL_FIRED_STARTS         ,
INTERVAL_TRIPS                ,
LAST_UPDATED_BY               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_S.CDR_PLP_DPRT_PRE_EXC_TRCK_S
MINUS
SELECT 
DEPART_FORM_SEQ_ID            ,
SITE_BATTLE_GROUND            ,
REASON_FOR_NO                 ,
OTHER_REASON                  ,
PROPOSED_OUTAGE_FLAG          ,
EBI_FLAG                      ,
EBI_ATTACH                    ,
PAC_CASE_NUMBER               ,
PRE_DEPART_RECM               ,
OLD_PROPOSED_DATE             ,
APPROVER_ID                   ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
TOTAL_FIRED_HOURS             ,
TOTAL_FIRED_STARTS            ,
TOTAL_TRIPS                   ,
INTERVAL_FIRED_HOURS          ,
INTERVAL_FIRED_STARTS         ,
INTERVAL_TRIPS                ,
LAST_UPDATED_BY               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
FROM GEEDW_PLP_BULK_T.CDR_PLP_DPRT_PRE_EXC_TRACK;


----Table: VT_CDR_PLP_DPRT_PRE_EXC_TRCK : Processing : Populate Stage table with CDC data only for mLDM processing  

/* DELETING DATA FROM STAGE */

DELETE GEEDW_PLP_S.CDR_PLP_DPRT_PRE_EXC_TRCK_S;

/* INSERTING DATA INTO STAGE */

INSERT INTO GEEDW_PLP_S.CDR_PLP_DPRT_PRE_EXC_TRCK_S
(
DEPART_FORM_SEQ_ID            ,
SITE_BATTLE_GROUND            ,
REASON_FOR_NO                 ,
OTHER_REASON                  ,
PROPOSED_OUTAGE_FLAG          ,
EBI_FLAG                      ,
EBI_ATTACH                    ,
PAC_CASE_NUMBER               ,
PRE_DEPART_RECM               ,
OLD_PROPOSED_DATE             ,
APPROVER_ID                   ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
TOTAL_FIRED_HOURS             ,
TOTAL_FIRED_STARTS            ,
TOTAL_TRIPS                   ,
INTERVAL_FIRED_HOURS          ,
INTERVAL_FIRED_STARTS         ,
INTERVAL_TRIPS                ,
LAST_UPDATED_BY               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
DW_LOAD_DATE                  ,
DW_CREATED_BY                 ,
DW_UPDATED_DATE               ,
DW_UPDATED_BY                 
)
SELECT 
DEPART_FORM_SEQ_ID            ,
SITE_BATTLE_GROUND            ,
REASON_FOR_NO                 ,
OTHER_REASON                  ,
PROPOSED_OUTAGE_FLAG          ,
EBI_FLAG                      ,
EBI_ATTACH                    ,
PAC_CASE_NUMBER               ,
PRE_DEPART_RECM               ,
OLD_PROPOSED_DATE             ,
APPROVER_ID                   ,
APPROVAL_FLAG                 ,
APPROVAL_DATE                 ,
TOTAL_FIRED_HOURS             ,
TOTAL_FIRED_STARTS            ,
TOTAL_TRIPS                   ,
INTERVAL_FIRED_HOURS          ,
INTERVAL_FIRED_STARTS         ,
INTERVAL_TRIPS                ,
LAST_UPDATED_BY               ,
CREATION_DATE                 ,
CREATED_BY                    ,
LAST_UPDATED_DATE             ,
CURRENT_DATE,                  
'CDR',                 
CURRENT_DATE,               
'CDR'                 
FROM VT_CDR_PLP_DPRT_PRE_EXC_TRACK;


---Table: CDR_PLP_DPRT_PRE_EXC_TRACK : End

