# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_BTEQ_CDR_PLP_SCAU_HIST_REPRT.sh 
# Creation Date: 07/18/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Deepika
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_SCAUTO_HIST_REPORT : Start	

---- DROP TABLE VT_CDR_PLP_SCAUTO_HIST_REPORT;	

CREATE VOLATILE TABLE VT_CDR_PLP_SCAUTO_HIST_REPORT ,NO LOG (

      UNIT_TYPE VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC ,
      TOTAL_UNITS INTEGER,
      FIRED_HOURS INTEGER ,
      FIRED_STARTS INTEGER ,
      PROJ_FIRED_HOURS INTEGER ,
      PROJ_FIRED_STARTS INTEGER ,
      CREATION_DATE DATE FORMAT 'YY/MM/DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LAST_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_LOAD_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      DW_UPDATED_DATE DATE FORMAT 'YY/MM/DD' ,
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC )
PRIMARY INDEX   ( UNIT_TYPE )ON COMMIT PRESERVE ROWS;




INSERT INTO VT_CDR_PLP_SCAUTO_HIST_REPORT
(

UNIT_TYPE,                     
TOTAL_UNITS,                   
FIRED_HOURS,                   
FIRED_STARTS,                  
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                   
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)

SELECT	

UNIT_TYPE,                     
TOTAL_UNITS,                   
FIRED_HOURS,                   
FIRED_STARTS,                  
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,             
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,     
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY 

FROM	 GEEDW_PLP_S.CDR_PLP_SCAU_HIST_REPRT_S

MINUS

SELECT	

UNIT_TYPE,                     
TOTAL_UNITS,                   
FIRED_HOURS,                   
FIRED_STARTS,                  
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,               
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,             
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_SCAU_HIST_REPRT;

-- Table: VT_CDR_PLP_SCAUTO_HIST_REPORT : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_SCAU_HIST_REPRT_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_SCAU_HIST_REPRT_S
(	
UNIT_TYPE,                     
TOTAL_UNITS,                   
FIRED_HOURS,                   
FIRED_STARTS,                  
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,                
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,         
DW_LOAD_DATE,
DW_CREATED_BY,
DW_UPDATED_DATE,
DW_UPDATED_BY                 
)	
SELECT 

UNIT_TYPE,                     
TOTAL_UNITS,                   
FIRED_HOURS,                   
FIRED_STARTS,                  
PROJ_FIRED_HOURS,              
PROJ_FIRED_STARTS,                  
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,  
CURRENT_DATE,       
'CDR',                         
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_SCAUTO_HIST_REPORT ;	

-- Table: CDR_PLP_SCAUTO_HIST_REPORT : End




