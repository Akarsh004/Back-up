# ---------------------------------------------------------------------------- 			
# File: sh_GEEDW_BTEQ_CDR_PLP_PLD_SCM_EA_MN_UPD.sh 
# Creation Date: 07/19/11 
# Purpose:CDC Implementation on the Staging and Bulk databases
# Created By: Krishanu Pratim Borah.
#------------------------------
# ENTERING INTO THE PATH WHERE THE FILE IS TO BE STORED 
. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq << eof
/* .RUN File = ${SrcDir}/td_plp.mlbt */

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database ${Stg_database};

-- Table: CDR_PLP_PLD_SCM_EA_MN_UPD : Start	

---- DROP TABLE VT_CDR_PLP_PLD_SCM_EA_MN_UPD;	

CREATE VOLATILE TABLE VT_CDR_PLP_PLD_SCM_EA_MN_UPD,NO LOG (
      PLDB_SCMTMAN_ST_SEQ_ID INTEGER,
      FROM_SITE VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_SITE VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      FROM_CPM VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      TO_CPM VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      EVENT_ID VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      EVENT_DATE DATE FORMAT 'YYYY-MM-DD',
      ACTION_TAKEN VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      COMMENTS VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      STATUS_NAME VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_TYPE_SEQ_ID INTEGER,
      PART_TYPE_DESC VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_SERIAL_NUM VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      PART_DRAWING_NUM VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      UNIT_NUMBER VARCHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      FLEX_FIELD1 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      FLEX_FIELD2 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      PROCESSED_STATUS VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      CREATION_DATE DATE FORMAT 'YYYY-MM-DD',
      CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      LAST_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      LAST_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_LOAD_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_CREATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      DW_UPDATED_DATE DATE FORMAT 'YYYY-MM-DD',
      DW_UPDATED_BY VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PLDB_SCMTMAN_ST_SEQ_ID ) ON COMMIT PRESERVE ROWS;



INSERT INTO VT_CDR_PLP_PLD_SCM_EA_MN_UPD
(
PLDB_SCMTMAN_ST_SEQ_ID,        
FROM_SITE,                     
TO_SITE,                       
FROM_CPM,                      
TO_CPM,                        
EVENT_ID,                      
EVENT_DATE,                    
ACTION_TAKEN,                  
COMMENTS,                      
STATUS_NAME,                   
PART_TYPE_SEQ_ID,              
PART_TYPE_DESC,                
PART_SERIAL_NUM,               
PART_DRAWING_NUM,              
UNIT_NUMBER,                   
FLEX_FIELD1,                   
FLEX_FIELD2,                   
PROCESSED_STATUS,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY                                                                                                                 )
SELECT	
PLDB_SCMTMAN_ST_SEQ_ID,        
FROM_SITE,                     
TO_SITE,                       
FROM_CPM,                      
TO_CPM,                        
EVENT_ID,                      
EVENT_DATE,                    
ACTION_TAKEN,                  
COMMENTS,                      
STATUS_NAME,                   
PART_TYPE_SEQ_ID,              
PART_TYPE_DESC,                
PART_SERIAL_NUM,               
PART_DRAWING_NUM,              
UNIT_NUMBER,                   
FLEX_FIELD1,                   
FLEX_FIELD2,                   
PROCESSED_STATUS,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
FROM	 GEEDW_PLP_S.CDR_PLP_PLD_SCM_EA_MN_UPD_S
MINUS
SELECT	
PLDB_SCMTMAN_ST_SEQ_ID,        
FROM_SITE,                     
TO_SITE,                       
FROM_CPM,                      
TO_CPM,                        
EVENT_ID,                      
EVENT_DATE,                    
ACTION_TAKEN,                  
COMMENTS,                      
STATUS_NAME,                   
PART_TYPE_SEQ_ID,              
PART_TYPE_DESC,                
PART_SERIAL_NUM,               
PART_DRAWING_NUM,              
UNIT_NUMBER,                   
FLEX_FIELD1,                   
FLEX_FIELD2,                   
PROCESSED_STATUS,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
FROM	 GEEDW_PLP_BULK_T.CDR_PLP_PLD_SCM_EA_MN_UPD;

-- Table: VT_CDR_PLP_PLD_SCM_EA_MN_UPD : Processing : Populate Stage table with CDC data only for mLDM processing	


DELETE GEEDW_PLP_S.CDR_PLP_PLD_SCM_EA_MN_UPD_S;	


INSERT INTO GEEDW_PLP_S.CDR_PLP_PLD_SCM_EA_MN_UPD_S
(	
PLDB_SCMTMAN_ST_SEQ_ID,        
FROM_SITE,                     
TO_SITE,                       
FROM_CPM,                      
TO_CPM,                        
EVENT_ID,                      
EVENT_DATE,                    
ACTION_TAKEN,                  
COMMENTS,                      
STATUS_NAME,                   
PART_TYPE_SEQ_ID,              
PART_TYPE_DESC,                
PART_SERIAL_NUM,               
PART_DRAWING_NUM,              
UNIT_NUMBER,                   
FLEX_FIELD1,                   
FLEX_FIELD2,                   
PROCESSED_STATUS,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,               
DW_LOAD_DATE,                  
DW_CREATED_BY,                 
DW_UPDATED_DATE,               
DW_UPDATED_BY    
)	
SELECT 
PLDB_SCMTMAN_ST_SEQ_ID,        
FROM_SITE,                     
TO_SITE,                       
FROM_CPM,                      
TO_CPM,                        
EVENT_ID,                      
EVENT_DATE,                    
ACTION_TAKEN,                  
COMMENTS,                      
STATUS_NAME,                   
PART_TYPE_SEQ_ID,              
PART_TYPE_DESC,                
PART_SERIAL_NUM,               
PART_DRAWING_NUM,              
UNIT_NUMBER,                   
FLEX_FIELD1,                   
FLEX_FIELD2,                   
PROCESSED_STATUS,              
CREATION_DATE,                 
CREATED_BY,                    
LAST_UPDATED_DATE,             
LAST_UPDATED_BY,                                                                                                             CURRENT_DATE,
'CDR',
CURRENT_DATE,
'CDR'
FROM VT_CDR_PLP_PLD_SCM_EA_MN_UPD;	

-- Table: CDR_PLP_PLD_SCM_EA_MN_UPD : End




