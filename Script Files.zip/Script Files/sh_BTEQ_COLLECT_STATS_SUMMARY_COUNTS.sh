#########################################################################################
##                                                                                     ##
##   File: sh_BTEQ_COLLECT_STATS_SUMMARY_COUNTS.sh                                     ##
##   Creation Date:13/10/12                                                            ##
##   Last Modified:16/10/12                                                            ##
##   Purpose:This script is used to collect stats of CDR_CSINV_SNAPSHOT                ##
##   /CDR_CSIV_MATCH_COUNT table                                                       ##
##   Created By: Harsha                                                                ##
##                                                                                     ##
#########################################################################################


. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh
bteq <<EOF

.RUN File = ${SrcDir}/td_plp.mlbt

/* .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; */

database GEEDW_PLP_S;

COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CSINV_SNAPSHOT COLUMN (FISCAL_WEEK_NUM);
COLLECT STATS ON GEEDW_EP_BULK_T.CDR_CSIV_MATCH_COUNT COLUMN (FISCAL_WEEK_NUM);

.LOGOFF
.EXIT 0
EOF

bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"
