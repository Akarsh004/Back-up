#########################################################################################
##      Author: Vikran, 30-DEC-09
##
##
##      1) This script is runs the collect stats on mLDM tables.
##
#########################################################################################

sh /data/informatica/ETCOE/EEDW01/ScriptFiles/LoggingScripts/sh_GEEDW_BTEQ_RUN_LOAD_STAT.sh >> /data/informatica/ETCOE/EEDW01/ScriptFiles/LoggingScripts/a.txt;
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_RPAD_DATA1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_RPAD_DATA_LOG.txt 2>&1
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_PLM_KPI_CYCLE_TIME.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_PLM_KPI_CYCLE_TIME_LOG.txt 2>&1
##sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BMLL_DELTA_DATA1_05212015.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_BMLL_DELTA_DATA1_05212015_LOG.txt 2>&1##
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_SBOM_WCRT_ICM.sh
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_COPICS_MSAN_STAGE.sh
##sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_WFMDW_DEL.sh##
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_INTERFACE_STAGE.sh
##sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_FETCH_STAGE.sh##
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_ESPL_STG2BULK_INSERT.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_ESPL_STG2BULK_INSERT_LOG.txt 2>&1
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_PLM_KPI_CYCLE_TIME_NON-E.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_PLM_KPI_CYCLE_TIME_NON-E_LOG.txt 2>&1
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_BOM_HEALTH.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_MT_BOM_HEALTH_LOG.txt 2>&1


. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh


bteq <<EOF

 /* .RUN File = ${SrcDir}/td_plp.mlbt */ 

.RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database GEEDW_PLP_BULK_T;

.run FILE=/data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_COLLECT_STATS_BULK.sql;


.LOGOFF
.EXIT 0
EOF

bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"
exit $bteqexitcode$