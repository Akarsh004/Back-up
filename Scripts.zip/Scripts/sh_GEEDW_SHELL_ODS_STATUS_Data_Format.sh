cp /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_GET_ODS_DETAILS_LOG.txt /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_GET_ODS_DETAILS_LOG1.txt
sed -i ':a;N;$!ba;s/\n/,/g' /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_GET_ODS_DETAILS_LOG.txt
sed -i 's/\(\([^,]*,\)\{9\}[^,]*\),/\1\n/g' /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_GET_ODS_DETAILS_LOG.txt
cp /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_GET_ODS_DETAILS_LOG.txt /data/informatica/ETCOE/EEDW01/Scripts/wflw_GEEDW_ODS_STAGE_report_new.csv
chmod 0777 /data/informatica/ETCOE/EEDW01/Scripts/wflw_GEEDW_ODS_STAGE_report_new.csv
