grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM_cdr_ods_r_affctd_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM_cdr_ods_r_affctd_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AFFCTD_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS_cdr_ods_r_and_rsk_aft_itm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS_cdr_ods_r_and_rsk_aft_itm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_RISK_AFCTD_ITEMS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS_cdr_ods_r_an_d_sub_depts_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS_cdr_ods_r_an_d_sub_depts_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_D_SUB_DEPARTMENTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE_cdr_ods_r_adtpm_adtpm_val_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE_cdr_ods_r_adtpm_adtpm_val_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_AN_DTPM_VALUE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM_cdr_ods_r_an_dtpm_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM_cdr_ods_r_an_dtpm_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_cdr_ods_r_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_AN_DTPM_cdr_ods_r_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_AN_DTPM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP_cdr_ods_r_appld_part_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP_cdr_ods_r_appld_part_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_APPLIED_PART_MARKUP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASND_PART_cdr_ods_R_ASND_PART_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASND_PART_cdr_ods_R_ASND_PART_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASND_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM_cdr_ods_r_asn_affctd_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM_cdr_ods_r_asn_affctd_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_AFFCTD_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_EC_cdr_ods_r_assn_ec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_EC_cdr_ods_r_assn_ec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_EC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_ISSUE_cdr_ods_r_assn_issue_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_ISSUE_cdr_ods_r_assn_issue_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_ISSUE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_TASKS_cdr_ods_r_assn_tasks_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSN_TASKS_cdr_ods_r_assn_tasks_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSN_TASKS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ_cdr_ods_r_bus_unit_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ_cdr_ods_r_bus_unit_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_BUS_UNIT_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT_cdr_ods_r_change_rspbt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT_cdr_ods_r_change_rspbt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CHANGE_RSPBT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CITIZEN_cdr_ods_r_citizen_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CITIZEN_cdr_ods_r_citizen_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CITIZEN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM_cdr_ods_r_classified_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM_cdr_ods_r_classified_item_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLASSIFIED_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART_cdr_ods_r_clin_asstd_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART_cdr_ods_r_clin_asstd_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_ASSOCIATED_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_BUILDS_cdr_ods_R_CLIN_BUILDS_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_BUILDS_cdr_ods_R_CLIN_BUILDS_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_BUILDS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLINCI_cdr_ods_R_CLINCI_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLINCI_cdr_ods_R_CLINCI_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINCI.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLINWBSE_cdr_ods_r_clinwbse_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLINWBSE_cdr_ods_r_clinwbse_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLINWBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLSF_cdr_ods_r_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLSF_cdr_ods_r_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLSF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT_cdr_ods_r_company_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT_cdr_ods_r_company_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COMPANY_CONTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN_cdr_ods_r_contract_clin_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN_cdr_ods_r_contract_clin_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CLIN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT_cdr_ods_r_contract_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT_cdr_ods_r_contract_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_CONTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ_cdr_ods_r_contract_gov_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ_cdr_ods_r_contract_gov_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_GOVERNG_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ_cdr_ods_r_contract_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ_cdr_ods_r_contract_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CSTM_GBOM_cdr_ods_r_cstm_gbom_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CSTM_GBOM_cdr_ods_r_cstm_gbom_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CSTM_GBOM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DATA_VAULTS_cdr_ods_r_data_vaults_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DATA_VAULTS_cdr_ods_r_data_vaults_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DATA_VAULTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DEPENDENCY_cdr_ods_r_dependency_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DEPENDENCY_cdr_ods_r_dependency_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DEPENDENCY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY_cdr_ods_r_desn_respnsblty_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY_cdr_ods_r_desn_respnsblty_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DESN_RESPONSBLTY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EBOM_cdr_ods_r_ebom_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EBOM_cdr_ods_r_ebom_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EBOM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP_cdr_ods_r_eco_chng_rqst_inp_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP_cdr_ods_r_eco_chng_rqst_inp_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECO_CHNG_RQST_INP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY_cdr_ods_r_ecr_org_company_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY_cdr_ods_r_ecr_org_company_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ECR_ORIG_COMPANY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE_cdr_ods_r_exc_clsf_lcnse_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE_cdr_ods_r_exc_clsf_lcnse_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_CLSF_LICENSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE_cdr_ods_r_exc_licd_people1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE_cdr_ods_r_exc_licd_people1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EXC_LICD_PEOPLE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN_cdr_ods_r_featr_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN_cdr_ods_r_featr_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_FEATURE_PRDT_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_APRVR_cdr_ods_r_ge_aprvr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_APRVR_cdr_ods_r_ge_aprvr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_APRVR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP_cdr_ods_r_ge_bu_cfgn_lkp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP_cdr_ods_r_ge_bu_cfgn_lkp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_BU_CFGN_LOOKUP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS_cdr_ods_r_ge_cas_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS_cdr_ods_r_ge_cas_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_MFGS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C_cdr_ods_r_ge_cas_setup_c1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C_cdr_ods_r_ge_cas_setup_c1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CAS_SETUP_C.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS_cdr_ods_r_ge_cfgn_l_dft_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS_cdr_ods_r_ge_cfgn_l_dft_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_DFLT_DOCS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS_cdr_ods_r_ge_cfgn_l_rfq_tmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS_cdr_ods_r_ge_cfgn_l_rfq_tmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CFGN_L_RFQ_TMPLTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY_cdr_ods_r_ge_clsfy_rglt_ctg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY_cdr_ods_r_ge_clsfy_rglt_ctg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CLSFY_RGLTRY_CTGRY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT_cdr_ods_r_ge_contract_prdt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT_cdr_ods_r_ge_contract_prdt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CONTRACT_PRDT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS_cdr_ods_r_ge_copics_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS_cdr_ods_r_ge_copics_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_MFGS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C_cdr_ods_r_ge_copics_setup_c1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C_cdr_ods_r_ge_copics_setup_c1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COPICS_SETUP_C.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT_cdr_ods_r_ge_cst_cstr_rqt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT_cdr_ods_r_ge_cst_cstr_rqt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_CSTMR_RQRMNT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE_cdr_ods_r_ge_cost_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE_cdr_ods_r_ge_cost_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_PART_cdr_ods_r_ge_cost_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COST_PART_cdr_ods_r_ge_cost_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COST_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM_cdr_ods_r_ge_critical_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM_cdr_ods_r_ge_critical_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CRITICAL_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST_cdr_ods_r_ge_cstm_spec_cost_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST_cdr_ods_r_ge_cstm_spec_cost_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTM_SPECIAL_COST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG_cdr_ods_r_ge_cstmr_dwg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG_cdr_ods_r_ge_cstmr_dwg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_CSTMR_DWG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS_cdr_ods_r_ge_dflt_dc_r_tmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS_cdr_ods_r_ge_dflt_dc_r_tmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DFLT_DOC_R_TMPLTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DOC_cdr_ods_r_ge_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DOC_cdr_ods_r_ge_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC_cdr_ods_r_ge_epetc5_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC_cdr_ods_r_ge_epetc5_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP_cdr_ods_r_ge_epetc5_set_up1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP_cdr_ods_r_ge_epetc5_set_up1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_EPETC5_SET_UP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS_cdr_ods_r_ge_fldr_buyer_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS_cdr_ods_r_ge_fldr_buyer_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_BUYER_DOCS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC_cdr_ods_r_ge_folder_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC_cdr_ods_r_ge_folder_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_FOLDER_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS_cdr_ods_r_ge_lne_i_sdx_fldr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS_cdr_ods_r_ge_lne_i_sdx_fldr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_I_SDX_FOLDERS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER_cdr_ods_r_ge_lne_itm_p_ordr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER_cdr_ods_r_ge_lne_itm_p_ordr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LINE_ITEM_P_ORDER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY_cdr_ods_r_ge_loc_eqvt_cmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY_cdr_ods_r_ge_loc_eqvt_cmp1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_LOC_EQVT_COMPANY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O_cdr_ods_r_ge_mbm_mfgg_p_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O_cdr_ods_r_ge_mbm_mfgg_p_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_MFGG_P_O.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT_cdr_ods_r_ge_mbm_o_p_elmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT_cdr_ods_r_ge_mbm_o_p_elmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_P_ELEMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN_cdr_ods_r_ge_mbm_o_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN_cdr_ods_r_ge_mbm_o_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_O_SPECN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P_cdr_ods_r_ge_mbm_prt_mfg_p1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P_cdr_ods_r_ge_mbm_prt_mfg_p1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PART_MFGG_P.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P_cdr_ods_r_ge_mbm_plnt_mfg_p1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P_cdr_ods_r_ge_mbm_plnt_mfg_p1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_PLANT_MFGG_P.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT_cdr_ods_r_ge_mbm_r_p_elmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT_cdr_ods_r_ge_mbm_r_p_elmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/m_GEEDW_S_ODS_R_GE_MBM_R_P_ELEMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O_cdr_ods_r_ge_mbm_refrnce_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O_cdr_ods_r_ge_mbm_refrnce_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_MBM_REFERENCE_O.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_OBJ_HST_cdr_ods_r_ge_obj_hst_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_OBJ_HST_cdr_ods_r_ge_obj_hst_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OBJ_HST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE_cdr_ods_r_ge_oprtn_u_site1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE_cdr_ods_r_ge_oprtn_u_site1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_OPERATING_U_SITE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR_cdr_ods_r_ge_p_o_awrdd_splr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR_cdr_ods_r_ge_p_o_awrdd_splr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_O_AWARDED_SPLR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG_cdr_ods_r_ge_p_scn_rqst_dwg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG_cdr_ods_r_ge_p_scn_rqst_dwg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SCAN_RQST_DWG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT_cdr_ods_r_ge_p_sdx_f_bs_unt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT_cdr_ods_r_ge_p_sdx_f_bs_unt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_F_BUS_UNIT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O_cdr_ods_r_ge_p_sdx_fldr_p_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O_cdr_ods_r_ge_p_sdx_fldr_p_o1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_P_SDX_FOLDER_P_O.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN_cdr_ods_r_ge_prnt_prdt_cfgn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN_cdr_ods_r_ge_prnt_prdt_cfgn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_PRDT_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN_cdr_ods_r_ge_prnt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN_cdr_ods_r_ge_prnt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRNT_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U_cdr_ods_r_ge_prnt_sdx_f_o_u1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U_cdr_ods_r_ge_prnt_sdx_f_o_u1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PARENT_SDX_F_O_U.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L_cdr_ods_r_ge_prt_fml_cfgn_l1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L_cdr_ods_r_ge_prt_fml_cfgn_l1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_FAMILY_CFGN_L.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST_cdr_ods_r_ge_part_qlfn_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST_cdr_ods_r_ge_part_qlfn_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PART_QLFN_RQST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT_cdr_ods_r_ge_prd_cfgn_tmpt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT_cdr_ods_r_ge_prd_cfgn_tmpt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRDT_CFGN_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER_cdr_ods_r_ge_qual_p_order1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER_cdr_ods_r_ge_qual_p_order1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_P_ORDER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL_cdr_ods_r_ge_qual_to_qual1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL_cdr_ods_r_ge_qual_to_qual1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QUAL_TO_QUAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN_cdr_ods_r_ge_rqst_qlfnl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN_cdr_ods_r_ge_rqst_qlfnl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_RQST_QLFN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE_cdr_ods_r_ge_src_to_viewabl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE_cdr_ods_r_ge_src_to_viewabl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SOURCE_TO_VIEWABLE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC_cdr_ods_r_ge_splr_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC_cdr_ods_r_ge_splr_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED_cdr_ods_r_ge_splr_submit1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED_cdr_ods_r_ge_splr_submit1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SPLR_SUBMITTED.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION_cdr_ods_r_ge_sub_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION_cdr_ods_r_ge_sub_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SUB_SPECIFACTION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER_cdr_ods_r_ge_tchncl_r_owner1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER_cdr_ods_r_ge_tchncl_r_owner1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_R_OWNER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO_cdr_ods_r_ge_tchncl_rvw_rdo1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO_cdr_ods_r_ge_tchncl_rvw_rdo1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TCHNCL_REVIEW_RDO.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE_cdr_ods_r_ge_tmplt_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE_cdr_ods_r_ge_tmplt_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_TMPLT_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM_cdr_ods_r_governed_item_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM_cdr_ods_r_governed_item_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GOVERNED_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL_cdr_ods_r_has_bus_skill_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL_cdr_ods_r_has_bus_skill_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BUS_SKILL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_EFFORTS_cdr_ods_R_HAS_EFFORTS_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_EFFORTS_cdr_ods_R_HAS_EFFORTS_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_EFFORTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ_cdr_ods_r_init_tmplt_prj_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ_cdr_ods_r_init_tmplt_prj_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INITIATED_TMPLT_PROJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INT_RTE_TMT_cdr_ods_r_int_rte_tmt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INT_RTE_TMT_cdr_ods_r_int_rte_tmt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INT_RTE_TMT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF_cdr_ods_r_issue_catgy_clf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF_cdr_ods_r_issue_catgy_clf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE_CATEGORY_CLSF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ISSUE_cdr_ods_r_issue_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ISSUE_cdr_ods_r_issue_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ISSUE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION_cdr_ods_r_left_expression_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION_cdr_ods_r_left_expression_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LEFT_EXPRESSION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ_cdr_ods_r_line_item_obj1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ_cdr_ods_r_line_item_obj1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM_OBJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LINE_ITEM_cdr_ods_r_line_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LINE_ITEM_cdr_ods_r_line_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LINE_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MEMBER_cdr_ods_r_member_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MEMBER_cdr_ods_r_member_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MESSAGE_cdr_ods_r_message_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MESSAGE_cdr_ods_r_message_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MESSAGE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV_cdr_ods_r_new_spc_spc_rev_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV_cdr_ods_r_new_spc_spc_rev_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_NEW_SPEC_SPEC_REV.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_OBJ_ROUTE_cdr_ods_r_obj_route_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_OBJ_ROUTE_cdr_ods_r_obj_route_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_OBJ_ROUTE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PART_SPECN_cdr_ods_r_part_specn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PART_SPECN_cdr_ods_r_part_specn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PART_SPECN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PLAN_FOCUS_cdr_ods_r_plan_focus1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PLAN_FOCUS_cdr_ods_r_plan_focus1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_FOCUS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PLAN_LOC_cdr_ods_r_plan_loc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PLAN_LOC_cdr_ods_r_plan_loc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PLAN_LOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD_cdr_ods_r_prdt_cfgn_build_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD_cdr_ods_r_prdt_cfgn_build_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN_BUILD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_CFGN_cdr_ods_r_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_CFGN_cdr_ods_r_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRG_CONTRACT_cdr_ods_r_prg_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRG_CONTRACT_cdr_ods_r_prg_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_CONTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRG_PRJ_cdr_ods_r_prg_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRG_PRJ_cdr_ods_r_prg_prj_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRG_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY_cdr_ods_r_prj_aces_key_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY_cdr_ods_r_prj_aces_key_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_KEY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST_cdr_ods_r_prj_aces_list_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST_cdr_ods_r_prj_aces_list_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ACCESS_LIST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS_cdr_ods_r_prj_members_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS_cdr_ods_r_prj_members_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_QUESTION_cdr_ods_r_prj_question1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_QUESTION_cdr_ods_r_prj_question1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_QUESTION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_TASK_cdr_ods_r_prj_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_TASK_cdr_ods_r_prj_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_TASK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP_cdr_ods_r_proposed_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP_cdr_ods_r_proposed_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PROPOSED_MARKUP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR_cdr_ods_r_raisd_agnst_ecr_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR_cdr_ods_r_raisd_agnst_ecr_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RAISED_AGAINST_ECR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_REFERENCE_DOC_cdr_ods_r_reference_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_REFERENCE_DOC_cdr_ods_r_reference_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REFERENCE_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_REPLY_cdr_ods_r_reply1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_REPLY_cdr_ods_r_reply1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_REPLY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RESOLVED_TO_cdr_ods_r_resolved_to_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RESOLVED_TO_cdr_ods_r_resolved_to_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RESOLVED_TO.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RFQ_SPLR_cdr_ods_r_rfq_splr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RFQ_SPLR_cdr_ods_r_rfq_splr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RFQ_SPLR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION_cdr_ods_r_right_expression_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION_cdr_ods_r_right_expression_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RIGHT_EXPRESSION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM_cdr_ods_r_risk_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM_cdr_ods_r_risk_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RISK_AN_DTPM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ROUTE_NODE_cdr_ods_r_route_node_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ROUTE_NODE_cdr_ods_r_route_node_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ROUTE_NODE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ROUTE_TASK_cdr_ods_r_route_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ROUTE_TASK_cdr_ods_r_route_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_ODS_R_ROUTE_TASK_S.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY_cdr_ods_r_rqrmnt_satfed_by1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY_cdr_ods_r_rqrmnt_satfed_by1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQRMNT_SATISFIED_BY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV_cdr_ods_r_rqst_spec_rev_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV_cdr_ods_r_rqst_spec_rev_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RQST_SPEC_REV.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR_cdr_ods_r_rsp_design_engr_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR_cdr_ods_r_rsp_design_engr_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RSP_DESIGN_ENGR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SECURITY_RULE_cdr_ods_r_security_rule_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SECURITY_RULE_cdr_ods_r_security_rule_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SECURITY_RULE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS_cdr_ods_r_selected_options_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS_cdr_ods_r_selected_options_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SELECTED_OPTIONS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE_cdr_ods_r_specn_structure_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE_cdr_ods_r_specn_structure_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SPECN_STRUCTURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUB_VAULTS_cdr_ods_r_sub_vaults1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUB_VAULTS_cdr_ods_r_sub_vaults1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUB_VAULTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUBCLASS_cdr_ods_r_subclass1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUBCLASS_cdr_ods_r_subclass1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBCLASS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUBTASK_cdr_ods_r_subtask_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_SUBTASK_cdr_ods_r_subtask_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_SUBTASK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE_cdr_ods_r_task_delivrble_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE_cdr_ods_r_task_delivrble_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TASK_DELIVERABLE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_R_THREAD_cdr_ods_r_thread1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_R_THREAD_cdr_ods_r_thread1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_THREAD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART_cdr_ods_r_top_level_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART_cdr_ods_r_top_level_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_TOP_LEVEL_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2_cdr_ods_r_vaulted_docs_rev2_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2_cdr_ods_r_vaulted_docs_rev2_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VAULTED_DOCS_REV2.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST_cdr_ods_t_an_d_res_rqst_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST_cdr_ods_t_an_d_res_rqst_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_RESOURCE_RQST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT_cdr_ods_t_an_d_upl_ms_pr_tm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT_cdr_ods_t_an_d_upl_ms_pr_tm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_D_UPL_MS_PRJ_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE_cdr_ods_t_an_dtpm_value_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE_cdr_ods_t_an_dtpm_value_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM_VALUE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_DTPM_cdr_ods_t_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_AN_DTPM_cdr_ods_t_an_dtpm_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_AN_DTPM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOM_MARKUP_cdr_ods_t_bom_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOM_MARKUP_cdr_ods_t_bom_markup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOM_MARKUP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL_cdr_ods_t_business_skill_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL_cdr_ods_t_business_skill_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_SKILL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT_cdr_ods_t_business_unit1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT_cdr_ods_t_business_unit1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BUSINESS_UNIT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CDRL_cdr_ods_t_cdrl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CDRL_cdr_ods_t_cdrl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CDRL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CHAPTER_cdr_ods_t_chapter_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CHAPTER_cdr_ods_t_chapter_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CHAPTER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CLIN_cdr_ods_t_clin1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CLIN_cdr_ods_t_clin1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLIN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CLSF_cdr_ods_t_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CLSF_cdr_ods_t_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CLSF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COMPANY_cdr_ods_t_company1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COMPANY_cdr_ods_t_company1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMPANY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN_cdr_ods_t_contract_docn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN_cdr_ods_t_contract_docn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_DOCN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_cdr_ods_t_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_cdr_ods_t_contract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COUNTRY_cdr_ods_t_country_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COUNTRY_cdr_ods_t_country_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COUNTRY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT_cdr_ods_t_cstmr_require1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT_cdr_ods_t_cstmr_require1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_REQUIREMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN_cdr_ods_t_cst_rqt_spc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN_cdr_ods_t_cst_rqt_spc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CSTMR_RQRMNT_SPECN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DELIVERABLE_cdr_ods_t_deliverable_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DELIVERABLE_cdr_ods_t_deliverable_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DELIVERABLE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DEPT_cdr_ods_t_department1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DEPT_cdr_ods_t_department1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DEPT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DOC_cdr_ods_t_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DOC_cdr_ods_t_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DWG_PRINT_cdr_ods_t_dwg_print1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DWG_PRINT_cdr_ods_t_dwg_print1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DWG_PRINT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ECO_cdr_ods_t_eco1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ECO_cdr_ods_t_eco1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECO.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ECR_cdr_ods_t_ecr_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ECR_cdr_ods_t_ecr_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ECR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EFFORT_cdr_ods_t_effort_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EFFORT_cdr_ods_t_effort_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EFFORT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS_cdr_ods_t_expt_ctrl_class_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS_cdr_ods_t_expt_ctrl_class_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPT_CTL_CLSS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC_cdr_ods_t_export_ctrl_doc_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC_cdr_ods_t_export_ctrl_doc_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPORT_CTRL_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB_cdr_ods_t_exprt_ctrl_lib_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB_cdr_ods_t_exprt_ctrl_lib_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_EXPRT_CTRL_LIB.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_FNCL_ITEM_cdr_ods_t_fncl_item_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_FNCL_ITEM_cdr_ods_t_fncl_item_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_FNCL_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GATE_cdr_ods_t_gate.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GATE_cdr_ods_t_gate.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GATE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP_cdr_ods_t_ge_dpma_ldr_tmp_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP_cdr_ods_t_ge_dpma_ldr_tmp_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DPMA_LDR_TMP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST_cdr_ods_t_ge_bulk_upld_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST_cdr_ods_t_ge_bulk_upld_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_RQST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_cdr_ods_t_ge_bulk_upload1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD_cdr_ods_t_ge_bulk_upload1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_BULK_UPLOAD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP_cdr_ods_t_ge_cfgn_lookup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP_cdr_ods_t_ge_cfgn_lookup1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN_LOOKUP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CFGN_cdr_ods_t_ge_cfgn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CFGN_cdr_ods_t_ge_cfgn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC_cdr_ods_t_ge_chr_acby_v_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC_cdr_ods_t_ge_chr_acby_v_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CHRCTC_ACTBY_V_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_CM_AND_U_cdr_ods_t_ge_cm_and_u.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_CM_AND_U_cdr_ods_t_ge_cm_and_u.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CM_AND_U.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R_cdr_ods_t_ge_commercial_r1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R_cdr_ods_t_ge_commercial_r1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMERCIAL_R.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC_cdr_ods_t_ge_commitment_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC_cdr_ods_t_ge_commitment_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMITMENT_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC_cdr_ods_t_ge_comdty_asm_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC_cdr_ods_t_ge_comdty_asm_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMODITY_ASSM_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_DOC_cdr_ods_t_ge_cost_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_DOC_cdr_ods_t_ge_cost_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ_cdr_ods_t_ge_cost_out_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ_cdr_ods_t_ge_cost_out_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST_OUT_NPI_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_cdr_ods_t_ge_cost_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COST_cdr_ods_t_ge_cost_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT_cdr_ods_t_ge_cst_bom_rprt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT_cdr_ods_t_ge_cst_bom_rprt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_BOM_REPORT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT_cdr_ods_t_ge_cstm_c_report1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT_cdr_ods_t_ge_cstm_c_report1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTM_C_REPORT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION_cdr_ods_t_ge_cstmr_publcatn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION_cdr_ods_t_ge_cstmr_publcatn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CSTMR_PUBLICATION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT_cdr_ods_t_ge_cud_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT_cdr_ods_t_ge_cud_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_CUD_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR_cdr_ods_t_ge_doc_fldr_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR_cdr_ods_t_ge_doc_fldr_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_FLDR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION_cdr_ods_t_ge_engrg_instrctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION_cdr_ods_t_ge_engrg_instrctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG_INSTRUCTION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_ENGRG_cdr_ods_t_ge_engrg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_ENGRG_cdr_ods_t_ge_engrg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_ENGRG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED_cdr_ods_t_ge_ext_managed_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED_cdr_ods_t_ge_ext_managed_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_MANAGED.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ_cdr_ods_t_ge_ext_fnd_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ_cdr_ods_t_ge_ext_fnd_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_EXT_FND_NPI_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS_cdr_ods_t_ge_flow_parts.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS_cdr_ods_t_ge_flow_parts.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FLOW_PARTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC_cdr_ods_t_ge_fmea_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC_cdr_ods_t_ge_fmea_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FMEA_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC_cdr_ods_t_ge_fpq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC_cdr_ods_t_ge_fpq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_FPQ_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ_cdr_ods_t_ge_grwth_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ_cdr_ods_t_ge_grwth_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_GRWTH_NPI_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_I_RN_D_cdr_ods_t_ge_i_rn_d.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_I_RN_D_cdr_ods_t_ge_i_rn_d.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_RN_D.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_INTERFACE_cdr_ods_t_ge_interface1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_INTERFACE_cdr_ods_t_ge_interface1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_INTERFACE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD_cdr_ods_t_ge_legacy_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD_cdr_ods_t_ge_legacy_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LEGACY_RECORD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED_cdr_ods_t_ge_lesson_learned1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED_cdr_ods_t_ge_lesson_learned1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LESSON_LEARNED.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR_cdr_ods_t_ge_ln_itm_sdx_fld1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR_cdr_ods_t_ge_ln_itm_sdx_fld1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_LINE_ITEM_SDX_FLDR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MARKETING_D_cdr_ods_t_ge_marketing_d1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MARKETING_D_cdr_ods_t_ge_marketing_d1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MARKETING_D.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_DOC_cdr_ods_t_ge_mbm_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_DOC_cdr_ods_t_ge_mbm_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS_cdr_ods_t_ge_mbm_mfg_prcess1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS_cdr_ods_t_ge_mbm_mfg_prcess1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_MFGG_PROCESS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION_cdr_ods_t_ge_mbm_operation1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION_cdr_ods_t_ge_mbm_operation1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_OPERATION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT_cdr_ods_t_ge_mbm_p_element1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT_cdr_ods_t_ge_mbm_p_element1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_P_ELEMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY_cdr_ods_t_ge_mbm_ug_asbly1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY_cdr_ods_t_ge_mbm_ug_asbly1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_ASBLY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL_cdr_ods_t_ge_mbm_ug_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL_cdr_ods_t_ge_mbm_ug_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_MODEL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY_cdr_ods_t_ge_mbm_ug_v_asbly1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY_cdr_ods_t_ge_mbm_ug_v_asbly1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_ASBLY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL_cdr_ods_t_ge_mbm_ug_v_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL_cdr_ods_t_ge_mbm_ug_v_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MBM_UG_V_MODEL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART_cdr_ods_t_ge_mfg_svc_kt_prt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART_cdr_ods_t_ge_mfg_svc_kt_prt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MFG_SVCS_KIT_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MPP_DOC_cdr_ods_t_ge_mpp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_MPP_DOC_cdr_ods_t_ge_mpp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_MPP_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NDT_DOC_cdr_ods_t_ge_ndt_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NDT_DOC_cdr_ods_t_ge_ndt_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NDT_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT_cdr_ods_t_ge_new_unit.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT_cdr_ods_t_ge_new_unit.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NEW_UNIT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_cdr_ods_t_ge_npi.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_cdr_ods_t_ge_npi.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ_cdr_ods_t_ge_npi_sub_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ_cdr_ods_t_ge_npi_sub_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_SUB_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NTI_cdr_ods_t_ge_nti.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NTI_cdr_ods_t_ge_nti.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NTI.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL_cdr_ods_t_ge_operational1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL_cdr_ods_t_ge_operational1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OPERATIONAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS_cdr_ods_t_ge_other_docs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS_cdr_ods_t_ge_other_docs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_OTHER_DOCS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT_cdr_ods_t_ge_pbom_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT_cdr_ods_t_ge_pbom_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PBOM_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT_cdr_ods_t_ge_pddr_report1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT_cdr_ods_t_ge_pddr_report1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PDDR_REPORT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE_cdr_ods_t_ge_performance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE_cdr_ods_t_ge_performance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PERFORMANCE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PHYSICAL_cdr_ods_t_ge_physical1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PHYSICAL_cdr_ods_t_ge_physical1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PHYSICAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC_cdr_ods_t_ge_plq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC_cdr_ods_t_ge_plq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PLQ_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_POQ_DOC_cdr_ods_t_ge_poq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_POQ_DOC_cdr_ods_t_ge_poq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_POQ_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PPO_DOC_cdr_ods_t_ge_ppo_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PPO_DOC_cdr_ods_t_ge_ppo_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC_cdr_ods_t_ge_ppo_v_c_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC_cdr_ods_t_ge_ppo_v_c_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PPO_V_C_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PQP_DOC_cdr_ods_t_ge_pqp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PQP_DOC_cdr_ods_t_ge_pqp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PQP_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST_cdr_ods_t_ge_prnt_scn_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST_cdr_ods_t_ge_prnt_scn_rqst1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRINT_SCAN_RQST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PROCEDURE_cdr_ods_t_ge_procedure1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PROCEDURE_cdr_ods_t_ge_procedure1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PROCEDURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER_cdr_ods_t_ge_purchase_order1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER_cdr_ods_t_ge_purchase_order1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PURCHASE_ORDER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS_cdr_ods_t_ge_qlfn_require1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS_cdr_ods_t_ge_qlfn_require1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLFN_REQUIREMENTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD_cdr_ods_t_ge_qlt_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD_cdr_ods_t_ge_qlt_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_IMRVM_NPI_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD_cdr_ods_t_ge_qlt_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD_cdr_ods_t_ge_qlt_record1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_QLT_RECORD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_REQUISITION_cdr_ods_t_ge_requisition.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_REQUISITION_cdr_ods_t_ge_requisition.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ_cdr_ods_t_ge_requisitn_sub_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ_cdr_ods_t_ge_requisitn_sub_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_REQUISITN_SUB_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN_cdr_ods_t_ge_rqst_for_qlfn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN_cdr_ods_t_ge_rqst_for_qlfn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RQST_FOR_QLFN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_RTS_cdr_ods_t_ge_rts.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_RTS_cdr_ods_t_ge_rts.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_RTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC_cdr_ods_t_ge_simple_plq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC_cdr_ods_t_ge_simple_plq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SIMPLE_PLQ_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC_cdr_ods_t_ge_splr_cmplc_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC_cdr_ods_t_ge_splr_cmplc_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_CMPLC_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC_cdr_ods_t_ge_splr_d_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC_cdr_ods_t_ge_splr_d_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_D_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN_cdr_ods_t_ge_splr_qlfn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN_cdr_ods_t_ge_splr_qlfn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPLR_QLFN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC_cdr_ods_t_ge_spq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC_cdr_ods_t_ge_spq_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPQ_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ_cdr_ods_t_ge_sustng_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ_cdr_ods_t_ge_sustng_npi_prj.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SUSTNG_NPI_PRJ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SW_cdr_ods_t_ge_sw1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SW_cdr_ods_t_ge_sw1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SW.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC_cdr_ods_t_ge_tech_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC_cdr_ods_t_ge_tech_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TECHNICAL_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT_cdr_ods_t_ge_trs_requrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT_cdr_ods_t_ge_trs_requrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_TRS_REQUIREMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC_cdr_ods_t_ge_vendor_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC_cdr_ods_t_ge_vendor_doc_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT_cdr_ods_t_ge_vndr_p_l_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT_cdr_ods_t_ge_vndr_p_l_tmplt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_P_L_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART_cdr_ods_t_ge_vendor_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART_cdr_ods_t_ge_vendor_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC_cdr_ods_t_ge_vendor_rsp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC_cdr_ods_t_ge_vendor_rsp_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_VENDOR_RSP_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC_cdr_ods_t_ge_weld_case_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC_cdr_ods_t_ge_weld_case_doc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_WELD_CASE_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GENERAL_CLASS_cdr_ods_t_general_class_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GENERAL_CLASS_cdr_ods_t_general_class_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_CLASS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY_cdr_ods_t_general_library_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY_cdr_ods_t_general_library_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GENERAL_LIBRARY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_BUILD_cdr_ods_t_hw_build_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_BUILD_cdr_ods_t_hw_build_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_BUILD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_CI_cdr_ods_t_hw_ci_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_CI_cdr_ods_t_hw_ci_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_CI.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_FEATURE_cdr_ods_t_hw_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_FEATURE_cdr_ods_t_hw_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_PRDT_cdr_ods_t_hw_prdt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_HW_PRDT_cdr_ods_t_hw_prdt_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_HW_PRDT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_INBOX_TASK_cdr_ods_t_inbox_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_INBOX_TASK_cdr_ods_t_inbox_task_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INBOX_TASK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS_cdr_ods_t_ip_ctrl_class_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS_cdr_ods_t_ip_ctrl_class_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_CTRL_CLASS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC_cdr_ods_t_ip_expt_clsf_dc_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC_cdr_ods_t_ip_expt_clsf_dc_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_IP_EXPORT_CLSF_DOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY_cdr_ods_t_issue_category_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY_cdr_ods_t_issue_category_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CATEGORY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_CLSF_cdr_ods_t_issue_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_CLSF_cdr_ods_t_issue_clsf_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE_CLSF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_cdr_ods_t_issue_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ISSUE_cdr_ods_t_issue_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ISSUE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LINE_ITEM_cdr_ods_t_line_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LINE_ITEM_cdr_ods_t_line_item1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LINE_ITEM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LOC_cdr_ods_t_loc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LOC_cdr_ods_t_loc1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MESSAGE_cdr_ods_t_message_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MESSAGE_cdr_ods_t_message_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MESSAGE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MILESTONE_RISK_cdr_ods_t_milestone_risk1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MILESTONE_RISK_cdr_ods_t_milestone_risk1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE_RISK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MILESTONE_cdr_ods_t_milestone1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MILESTONE_cdr_ods_t_milestone1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MILESTONE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_NON_CONTRCT_DRL_cdr_ods_t_non_contrct_drl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_NON_CONTRCT_DRL_cdr_ods_t_non_contrct_drl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_CONTRACT_DRL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT_cdr_ods_t_non_d_agreement1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT_cdr_ods_t_non_d_agreement1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_NON_D_AGREEMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ORG_cdr_ods_t_org1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ORG_cdr_ods_t_org1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ORG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_FAMILY_cdr_ods_t_part_family_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_FAMILY_cdr_ods_t_part_family_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_FAMILY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_LIBRARY_cdr_ods_t_part_library1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_LIBRARY_cdr_ods_t_part_library1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_LIBRARY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN_cdr_ods_t_part_qlt_plan1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN_cdr_ods_t_part_qlt_plan1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_QLT_PLAN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_SPEC_cdr_ods_t_part_spec_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_SPEC_cdr_ods_t_part_spec_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART_SPEC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_cdr_ods_t_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PART_cdr_ods_t_part_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PERSON_cdr_ods_t_person1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PERSON_cdr_ods_t_person1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PERSON.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PHASE_cdr_ods_t_phase.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PHASE_cdr_ods_t_phase.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PHASE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PLAN_cdr_ods_t_plan1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PLAN_cdr_ods_t_plan1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PLAN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_CFGN_cdr_ods_t_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_CFGN_cdr_ods_t_prdt_cfgn_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_CFGN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_LINE_cdr_ods_t_prdt_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_LINE_cdr_ods_t_prdt_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_LINE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC_cdr_ods_t_prdt_rqmnt_spec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC_cdr_ods_t_prdt_rqmnt_spec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_RQMNT_SPEC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRG_cdr_ods_t_prg_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRG_cdr_ods_t_prg_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT_cdr_ods_t_prj_department1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT_cdr_ods_t_prj_department1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_DEPARTMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_MEMBER_cdr_ods_t_prj_member_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_MEMBER_cdr_ods_t_prj_member_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_MEMBER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_PRO_cdr_ods_t_prj_pro_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_PRO_cdr_ods_t_prj_pro_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_PRO.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_RISK_cdr_ods_t_prj_risk_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_RISK_cdr_ods_t_prj_risk_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_RISK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_TMPLT_cdr_ods_t_prj_tmplt_s11.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRJ_TMPLT_cdr_ods_t_prj_tmplt_s11.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRJ_TMPLT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PROJ_SPACE_cdr_ods_t_proj_space1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PROJ_SPACE_cdr_ods_t_proj_space1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PROJ_SPACE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_RFQ_cdr_ods_t_rfq1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_RFQ_cdr_ods_t_rfq1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RFQ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ROUTE_cdr_ods_t_route_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_ROUTE_cdr_ods_t_route_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_ROUTE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_RQ_SPEC_cdr_ods_t_rq_spec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_RQ_SPEC_cdr_ods_t_rq_spec_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQ_SPEC.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/cdr_ods_t_rqrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/cdr_ods_t_rqrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_RQRMNT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SDRL_cdr_ods_t_sdrl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SDRL_cdr_ods_t_sdrl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SDRL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS_cdr_ods_t_secrty_ctl_cls_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS_cdr_ods_t_secrty_ctl_cls_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECRTY_CTRL_CLASS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SECURITY_RULE_cdr_ods_t_security_rule_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SECURITY_RULE_cdr_ods_t_security_rule_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SECURITY_RULE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBCONTRACT_cdr_ods_t_subcontract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBCONTRACT_cdr_ods_t_subcontract_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBCONTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBMITTAL_cdr_ods_t_submittal_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBMITTAL_cdr_ods_t_submittal_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBMITTAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_CI_cdr_ods_t_sw_ci_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_CI_cdr_ods_t_sw_ci_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_CI.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_FEATURE_cdr_ods_t_sw_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_FEATURE_cdr_ods_t_sw_feature_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_TASK_cdr_ods_t_task1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_TASK_cdr_ods_t_task1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_TASK_MGMT_cdr_ods_t_task_mgmt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_TASK_MGMT_cdr_ods_t_task_mgmt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_TASK_MGMT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_THREAD_cdr_ods_t_thread_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_THREAD_cdr_ods_t_thread_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_THREAD.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_ASBLY_cdr_ods_t_ug_asbly_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_ASBLY_cdr_ods_t_ug_asbly_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_ASBLY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_DWG_cdr_ods_t_ug_dwg_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_DWG_cdr_ods_t_ug_dwg_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_DWG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_MODEL_cdr_ods_t_ug_model_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_MODEL_cdr_ods_t_ug_model_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_MODEL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WBSE_cdr_ods_t_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WBSE_cdr_ods_t_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK_cdr_ods_t_workflow_task_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK_cdr_ods_t_workflow_task_s.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKFLOW_TASK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT_cdr_ods_t_workspace_vault_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT_cdr_ods_t_workspace_vault_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE_VAULT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS_cdr_ods_vca_all_projetcs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS_cdr_ods_vca_all_projetcs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_VCA_ALL_PROJETCS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_PRG_cdr_ods_t_ge_npi_prg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_NPI_PRG_cdr_ods_t_ge_npi_prg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_NPI_PRG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CFGN_FEATURES_cdr_ods_r_cfgn_features1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CFGN_FEATURES_cdr_ods_r_cfgn_features1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_FEATURES.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS_cdr_ods_r_cfgn_options1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS_cdr_ods_r_cfgn_options1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CFGN_OPTIONS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GBOM_cdr_ods_r_gbom1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GBOM_cdr_ods_r_gbom1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GBOM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE_cdr_ods_r_ge_cmmn_idnfr_wbs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE_cdr_ods_r_ge_cmmn_idnfr_wbs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_COMMON_IDNFR_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE_cdr_ods_r_ge_c_idnfr_l_ftre1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE_cdr_ods_r_ge_c_idnfr_l_ftre1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_C_IDNFR_L_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES_cdr_ods_r_logical_features1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES_cdr_ods_r_logical_features1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_LOGICAL_FEATURES.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VARIES_BY_cdr_ods_r_varies_by1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VARIES_BY_cdr_ods_r_varies_by1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VARIES_BY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CFGN_FEATURE_cdr_ods_t_cfgn_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CFGN_FEATURE_cdr_ods_t_cfgn_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CFGN_OPTION_cdr_ods_t_cfgn_option1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CFGN_OPTION_cdr_ods_t_cfgn_option1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CFGN_OPTION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR_cdr_ods_t_ge_common_idnfr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR_cdr_ods_t_ge_common_idnfr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_COMMON_IDNFR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL_cdr_ods_t_ge_c_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL_cdr_ods_t_ge_c_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_C_MATERIAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL_cdr_ods_t_ge_i_std_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL_cdr_ods_t_ge_i_std_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_I_STD_MATERIAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE_cdr_ods_t_ge_prj_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE_cdr_ods_t_ge_prj_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL_cdr_ods_t_ge_specfd_mtrial1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL_cdr_ods_t_ge_specfd_mtrial1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SPECIFIED_MATERIAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE_cdr_ods_t_logical_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE_cdr_ods_t_logical_feature1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_LOGICAL_FEATURE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MATERIAL_cdr_ods_t_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MATERIAL_cdr_ods_t_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MATERIAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBSTANCE_cdr_ods_t_substance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SUBSTANCE_cdr_ods_t_substance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SUBSTANCE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_CLIN_cdr_ods_r_clin_clin1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CLIN_CLIN_cdr_ods_r_clin_clin1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CLIN_CLIN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL_cdr_ods_r_cmpnt_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL_cdr_ods_r_cmpnt_material1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_MATERIAL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN_cdr_ods_r_cntrct_prt_sctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN_cdr_ods_r_cntrct_prt_sctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_PART_SCTN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART_cdr_ods_r_cntrct_tmplt_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART_cdr_ods_r_cntrct_tmplt_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CONTRACT_TMPLT_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN_cdr_ods_r_material_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN_cdr_ods_r_material_specn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MATERIAL_SPECN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION_cdr_ods_r_wbse_organization1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION_cdr_ods_r_wbse_organization1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_WBSE_ORGANIZATION.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_PART_cdr_ods_t_contract_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_PART_cdr_ods_t_contract_part1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_PART.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN_cdr_ods_t_contract_sctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN_cdr_ods_t_contract_sctn1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CONTRACT_SCTN.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SALE_ORDR_LINE_cdr_ods_r_ge_sale_ordr_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SALE_ORDR_LINE_cdr_ods_r_ge_sale_ordr_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORDER_LINE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT_cdr_ods_r_ge_sale_ord_l_prt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT_cdr_ods_r_ge_sale_ord_l_prt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_SALE_ORD_L_PRT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER_cdr_ods_t_ge_sales_order_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER_cdr_ods_t_ge_sales_order_s1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALES_ORDER.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE_cdr_ods_t_ge_sale_ordr_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE_cdr_ods_t_ge_sale_ordr_line1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SALE_ORDR_LINE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT_cdr_ods_r_cad_sub_cmpnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT_cdr_ods_r_cad_sub_cmpnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CAD_SUB_CMPNT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM_cdr_ods_r_copy_wbse_from1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM_cdr_ods_r_copy_wbse_from1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_COPY_WBSE_FROM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT_cdr_ods_r_derived_requrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT_cdr_ods_r_derived_requrmnt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_REQUIREMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR_cdr_ods_r_ge_prj_sales_ordr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR_cdr_ods_r_ge_prj_sales_ordr1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_PRJ_SALES_ORDR.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MFGS_cdr_ods_r_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MFGS_cdr_ods_r_mfgs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MFGS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP_cdr_ods_r_prj_membership1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP_cdr_ods_r_prj_membership1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_MEMBERSHIP.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RELATED_WBSE_cdr_ods_r_related_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_RELATED_WBSE_cdr_ods_r_related_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_RELATED_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VERSION_OF_cdr_ods_r_version_of1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_VERSION_OF_cdr_ods_r_version_of1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_VERSION_OF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL_cdr_ods_t_ug_vrsnd_mdl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL_cdr_ods_t_ug_vrsnd_mdl1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_UG_VERSIONED_MODEL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKSPACE_cdr_ods_t_workspace1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_WORKSPACE_cdr_ods_t_workspace1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_WORKSPACE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE_cdr_ods_t_ge_prj_part_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE_cdr_ods_t_ge_prj_part_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PART_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COMMON_WBSE_cdr_ods_t_common_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_COMMON_WBSE_cdr_ods_t_common_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_COMMON_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL_cdr_ods_r_ge_doc_to_doc_rel1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL_cdr_ods_r_ge_doc_to_doc_rel1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_DOC_TO_DOC_REL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ALTERNATE_cdr_ods_r_alternate1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ALTERNATE_cdr_ods_r_alternate1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ALTERNATE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS_cdr_ods_r_prdt_line_models1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS_cdr_ods_r_prdt_line_models1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDT_LINE_MODELS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDTS_cdr_ods_r_prdts1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRDTS_cdr_ods_r_prdts1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRDTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDTS_cdr_ods_t_prdts1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDTS_cdr_ods_t_prdts1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDTS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MODEL_cdr_ods_t_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_MODEL_cdr_ods_t_model1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_MODEL.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE_cdr_ods_r_associated_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE_cdr_ods_r_associated_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_ASSOCIATED_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE_cdr_ods_t_ge_doc_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE_cdr_ods_t_ge_doc_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_DOC_CWBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE_cdr_ods_t_ge_part_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE_cdr_ods_t_ge_part_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PART_CWBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE_cdr_ods_t_ge_prdt_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE_cdr_ods_t_ge_prdt_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRDT_CWBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE_cdr_ods_t_ge_prj_doc_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE_cdr_ods_t_ge_prj_doc_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_DOC_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE_cdr_ods_t_ge_prj_prdt_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE_cdr_ods_t_ge_prj_prdt_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_PRDT_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE_cdr_ods_t_ge_prj_service_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE_cdr_ods_t_ge_prj_service_wbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_PRJ_SERVICE_WBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE_cdr_ods_t_ge_service_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE_cdr_ods_t_ge_service_cwbse1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_GE_SERVICE_CWBSE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE_cdr_ods_r_cmpnt_substance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE_cdr_ods_r_cmpnt_substance1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_CMPNT_SUBSTANCE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT_cdr_ods_r_derived_abstract1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT_cdr_ods_r_derived_abstract1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DERIVED_ABSTRACT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DSTBN_LIST_cdr_ods_r_dstbn_list1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_DSTBN_LIST_cdr_ods_r_dstbn_list1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_DSTBN_LIST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EMPLOYEE_cdr_ods_r_employee1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_EMPLOYEE_cdr_ods_r_employee1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_EMPLOYEE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ_cdr_ods_r_ge_qlfn_rfq1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ_cdr_ods_r_ge_qlfn_rfq1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_GE_QLFN_RFQ.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BOOKS_cdr_ods_r_has_books1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BOOKS_cdr_ods_r_has_books1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES_cdr_ods_r_has_bookshelves1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES_cdr_ods_r_has_bookshelves1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_BOOKSHELVES.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_DOCS_cdr_ods_r_has_docs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_HAS_DOCS_cdr_ods_r_has_docs1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_HAS_DOCS.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT_cdr_ods_r_inv_attachment1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT_cdr_ods_r_inv_attachment1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_INV_ATTACHMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MEMBER_LIST_cdr_ods_r_member_list1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_MEMBER_LIST_cdr_ods_r_member_list1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_MEMBER_LIST.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_.out.ldrlogE_cdr_ods_r_prj_.out.ldrloge1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_R_PRJ_.out.ldrlogE_cdr_ods_r_prj_.out.ldrloge1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_R_PRJ_ROUTE.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOOK_cdr_ods_t_book1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOOK_cdr_ods_t_book1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOK.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOOKSHELF_cdr_ods_t_bookshelf1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_BOOKSHELF_cdr_ods_t_bookshelf1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_BOOKSHELF.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CMT_cdr_ods_t_cmt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_CMT_cdr_ods_t_cmt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_CMT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DOC_LIBRARY_cdr_ods_t_doc_library1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_DOC_LIBRARY_cdr_ods_t_doc_library1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_DOC_LIBRARY.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG_cdr_ods_t_inventor_integ_g_cfg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG_cdr_ods_t_inventor_integ_g_cfg1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_INVENTOR_INTEG_G_CFG.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT_cdr_ods_t_m_clsfn_assignment1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT_cdr_ods_t_m_clsfn_assignment1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_M_CLSFN_ASSIGNMENT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM_cdr_ods_t_prdt_platform1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM_cdr_ods_t_prdt_platform1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_PLATFORM.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_VARIANT_cdr_ods_t_prdt_variant1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_PRDT_VARIANT_cdr_ods_t_prdt_variant1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_PRDT_VARIANT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SERVICE_PRDT_cdr_ods_t_service_prdt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SERVICE_PRDT_cdr_ods_t_service_prdt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SERVICE_PRDT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

grep 'Workflow:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log  | cut -d "[" -f2 | cut -d "]" -f1
grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log | grep 's_' | cut -d "[" -f2 | cut -d "]" -f1
grep 'Mapping name:' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log  | cut -d ":" -f2 | cut -d " " -f2| sed 's/.$//'
dt_start_session=`grep 'Initializing session' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log  | grep 's_' | cut -d "[" -f3 | cut -d "]" -f1`
dt_start_session1=$(date -d "$dt_start_session" +'%m/%d/%Y %r')
echo $dt_start_session1
dt_end_session=`grep 'completed at' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log  | cut -d "[" -f3 | cut -d "]" -f1`
dt_end_session1=$(date -d "$dt_end_session" +'%m/%d/%Y %r')
echo $dt_end_session1
grep 'Total Records Read' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_PRDT_cdr_ods_t_sw_prdt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep 'Total Inserts Applied' /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_T_SW_PRDT_cdr_ods_t_sw_prdt1.out.ldrlog | cut -d "=" -f2 | cut -d " " -f3
grep -m 1 'Rejected Rows'  /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log  |  cut -d "[" -f5 | cut -d "]" -f1
run_status=`grep 'Session run completed successfully' /data/informatica/ETCOE/EEDW01/SessLogs/s_m_GEEDW_S_ODS_T_SW_PRDT.log | cut -d " " -f6`
if [ "$run_status" == "successfully." ]
 then 
  echo "Succeeded"
  echo "No Error"
 else
  echo "Failed"
  echo "Error"
fi
############

sh /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_ODS_STATUS_Data_Format.sh > /data/informatica/ETCOE/EEDW01/Scripts/sh_GEEDW_SHELL_ODS_STATUS_Data_Format_LOG.txt 2>&1
