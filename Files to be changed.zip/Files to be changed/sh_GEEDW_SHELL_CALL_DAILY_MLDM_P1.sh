##################################################################################################################################
##                                                                                                                              ##
##       Script Name:sh_GEEDW_SHELL_CALL_DAILY_MLDM.sh		                                                                  ##
##       Author: Sanjib Patra                                                                                                   ##
##       Creation Date:09-AUG-2012                                                                                              ##
##       Modified Date:                                                                                                         ##
##                                                                                                                              ##
##       Description:                                                                                                           ##
##        This Script triggers the wflw_GEEDW_DAILY_MLDM workflow in EEDW03.                                                    ##
##                                                                                                                              ##
##################################################################################################################################

pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_MLDM

##Script To update the Parameter File ODS_DAILY_STAGE##

# DECLARING A VARIABLE WHICH TAKES THE DESIRED BUFFER TIME #
hour_value='11' 
# GETTING CURRENT SYSTEM DATE MINUS BUFFER TIME #
DT=`date --date="$hour_value hours ago" +'%m/%d/%Y %r'`
# GETTING THE NEW STRING WITH CURRENT DATE WITH BUFFER VALUE #
new_dt="\$\$LAST_RUN_DATE="$DT
# REPLACING THE LINES WHICH CONTAIN THE STRING "LAST_RUN_DATE=" WITH NEW DATE #
sed -i "/LAST_RUN_DATE=/ c $new_dt" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DAILY_STAGE_PARAMETER.txt
exit 0;



