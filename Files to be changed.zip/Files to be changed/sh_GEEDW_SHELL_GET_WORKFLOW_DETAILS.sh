#############################################EEDW01##wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES1=$(date -d "$dt_start_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES1
dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES1=$(date -d "$dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES
 else
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE_LX_MX_TABLES | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW01##wflw_GEEDW_S_ODS_DELETES##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_S_ODS_DELETES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_S_ODS_DELETES1=$(date -d "$dt_start_wflw_GEEDW_S_ODS_DELETES" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_S_ODS_DELETES1
dt_end_wflw_GEEDW_S_ODS_DELETES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_S_ODS_DELETES1=$(date -d "$dt_end_wflw_GEEDW_S_ODS_DELETES" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_S_ODS_DELETES" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_S_ODS_DELETES
 else
  echo $dt_end_wflw_GEEDW_S_ODS_DELETES1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_S_ODS_DELETES | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW01##wflw_GEEDW_DAILY_STAGE##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_STAGE1=$(date -d "$dt_start_wflw_GEEDW_DAILY_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_STAGE1
dt_end_wflw_GEEDW_DAILY_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_STAGE1=$(date -d "$dt_end_wflw_GEEDW_DAILY_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_STAGE
 else
  echo $dt_end_wflw_GEEDW_DAILY_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW01 wflw_GEEDW_DAILY_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW02##wflw_GEEDW_ORAP_STAGE##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_ORAP_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_ORAP_STAGE1=$(date -d "$dt_start_wflw_GEEDW_ORAP_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_ORAP_STAGE1
dt_end_wflw_GEEDW_ORAP_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_ORAP_STAGE1=$(date -d "$dt_end_wflw_GEEDW_ORAP_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_ORAP_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_ORAP_STAGE
 else
  echo $dt_end_wflw_GEEDW_ORAP_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_ORAP_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW02##wflw_EEDW_PLP_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_EEDW_PLP_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_EEDW_PLP_STAGE1=$(date -d "$dt_start_wflw_EEDW_PLP_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_EEDW_PLP_STAGE1
dt_end_wflw_EEDW_PLP_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_EEDW_PLP_STAGE1=$(date -d "$dt_end_wflw_EEDW_PLP_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_EEDW_PLP_STAGE" == "" ]
 then 
  echo $dt_end_wflw_EEDW_PLP_STAGE
 else
  echo $dt_end_wflw_EEDW_PLP_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_EEDW_PLP_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW02##wflw_GEEDW_INTEGRATION_RUN_DTL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_INTEGRATION_RUN_DTL1=$(date -d "$dt_start_wflw_GEEDW_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_INTEGRATION_RUN_DTL1
dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL1=$(date -d "$dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL
 else
  echo $dt_end_wflw_GEEDW_INTEGRATION_RUN_DTL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW03##wflw_GEEDW_CMD_TASK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_CMD_TASK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_CMD_TASK1=$(date -d "$dt_start_wflw_GEEDW_CMD_TASK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_CMD_TASK1
dt_end_wflw_GEEDW_CMD_TASK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_CMD_TASK1=$(date -d "$dt_end_wflw_GEEDW_CMD_TASK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_CMD_TASK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_CMD_TASK
 else
  echo $dt_end_wflw_GEEDW_CMD_TASK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CMD_TASK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW03##wflw_GEEDW_DAILY_STAGE_ONCE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_STAGE_ONCE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_STAGE_ONCE1=$(date -d "$dt_start_wflw_GEEDW_DAILY_STAGE_ONCE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_STAGE_ONCE1
dt_end_wflw_GEEDW_DAILY_STAGE_ONCE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_STAGE_ONCE1=$(date -d "$dt_end_wflw_GEEDW_DAILY_STAGE_ONCE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_STAGE_ONCE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_ONCE
 else
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_ONCE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_STAGE_ONCE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW03##wflw_GEEDW_STAGING##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_STAGING=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_STAGING1=$(date -d "$dt_start_wflw_GEEDW_STAGING" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_STAGING1
dt_end_wflw_GEEDW_STAGING=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_STAGING1=$(date -d "$dt_end_wflw_GEEDW_STAGING" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_STAGING" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_STAGING
 else
  echo $dt_end_wflw_GEEDW_STAGING1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_STAGING | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_ORAP_BULK##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_ORAP_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_ORAP_BULK1=$(date -d "$dt_start_wflw_GEEDW_ORAP_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_ORAP_BULK1
dt_end_wflw_GEEDW_ORAP_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_ORAP_BULK1=$(date -d "$dt_end_wflw_GEEDW_ORAP_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_ORAP_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_ORAP_BULK
 else
  echo $dt_end_wflw_GEEDW_ORAP_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_PLP_BULK_TO_FILE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_PLP_BULK_TO_FILE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_PLP_BULK_TO_FILE1=$(date -d "$dt_start_wflw_GEEDW_PLP_BULK_TO_FILE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_PLP_BULK_TO_FILE1
dt_end_wflw_GEEDW_PLP_BULK_TO_FILE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_PLP_BULK_TO_FILE1=$(date -d "$dt_end_wflw_GEEDW_PLP_BULK_TO_FILE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_PLP_BULK_TO_FILE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_PLP_BULK_TO_FILE
 else
  echo $dt_end_wflw_GEEDW_PLP_BULK_TO_FILE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PLP_BULK_TO_FILE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_EEDW_PLP_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_EEDW_PLP_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_EEDW_PLP_BULK1=$(date -d "$dt_start_wflw_EEDW_PLP_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_EEDW_PLP_BULK1
dt_end_wflw_EEDW_PLP_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_EEDW_PLP_BULK1=$(date -d "$dt_end_wflw_EEDW_PLP_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_EEDW_PLP_BULK" == "" ]
 then 
  echo $dt_end_wflw_EEDW_PLP_BULK
 else
  echo $dt_end_wflw_EEDW_PLP_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_EEDW_PLP_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_PEGASUS##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_PEGASUS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_PEGASUS1=$(date -d "$dt_start_wflw_GEEDW_PEGASUS" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_PEGASUS1
dt_end_wflw_GEEDW_PEGASUS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_PEGASUS1=$(date -d "$dt_end_wflw_GEEDW_PEGASUS" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_PEGASUS" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_PEGASUS
 else
  echo $dt_end_wflw_GEEDW_PEGASUS1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_PEGASUS | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_2EXT_APPS_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_2EXT_APPS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_2EXT_APPS_DAILY1=$(date -d "$dt_start_wflw_GEEDW_2EXT_APPS_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_2EXT_APPS_DAILY1
dt_end_wflw_GEEDW_2EXT_APPS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_2EXT_APPS_DAILY1=$(date -d "$dt_end_wflw_GEEDW_2EXT_APPS_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_2EXT_APPS_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_2EXT_APPS_DAILY
 else
  echo $dt_end_wflw_GEEDW_2EXT_APPS_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_2EXT_APPS_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS1=$(date -d "$dt_start_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS1
dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS1=$(date -d "$dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS
 else
  echo $dt_end_wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_BMIT_COPICS_DAILY_INSERTS | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_B_ODS_DOCMASTER_B_PLM##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM1=$(date -d "$dt_start_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM1
dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM1=$(date -d "$dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM
 else
  echo $dt_end_wflw_GEEDW_B_ODS_DOCMASTER_B_PLM1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_B_ODS_DOCMASTER_B_PLM | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW04##wflw_GEEDW_REACH_LEGACY_STG##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_REACH_LEGACY_STG=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_REACH_LEGACY_STG1=$(date -d "$dt_start_wflw_GEEDW_REACH_LEGACY_STG" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_REACH_LEGACY_STG1
dt_end_wflw_GEEDW_REACH_LEGACY_STG=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_REACH_LEGACY_STG1=$(date -d "$dt_end_wflw_GEEDW_REACH_LEGACY_STG" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_REACH_LEGACY_STG" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_REACH_LEGACY_STG
 else
  echo $dt_end_wflw_GEEDW_REACH_LEGACY_STG1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_REACH_LEGACY_STG | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_EARS_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_EARS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_EARS_BULK1=$(date -d "$dt_start_wflw_GEEDW_EARS_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_EARS_BULK1
dt_end_wflw_GEEDW_EARS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_EARS_BULK1=$(date -d "$dt_end_wflw_GEEDW_EARS_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_EARS_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_EARS_BULK
 else
  echo $dt_end_wflw_GEEDW_EARS_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_EARS_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_MT_PLM_KPI_TASK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_MT_PLM_KPI_TASK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_MT_PLM_KPI_TASK1=$(date -d "$dt_start_wflw_GEEDW_MT_PLM_KPI_TASK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_MT_PLM_KPI_TASK1
dt_end_wflw_GEEDW_MT_PLM_KPI_TASK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_MT_PLM_KPI_TASK1=$(date -d "$dt_end_wflw_GEEDW_MT_PLM_KPI_TASK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_MT_PLM_KPI_TASK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_MT_PLM_KPI_TASK
 else
  echo $dt_end_wflw_GEEDW_MT_PLM_KPI_TASK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_MT_PLM_KPI_TASK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_ODS_BULK_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_ODS_BULK_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_ODS_BULK_DAILY1=$(date -d "$dt_start_wflw_GEEDW_ODS_BULK_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_ODS_BULK_DAILY1
dt_end_wflw_GEEDW_ODS_BULK_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_ODS_BULK_DAILY1=$(date -d "$dt_end_wflw_GEEDW_ODS_BULK_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_ODS_BULK_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_ODS_BULK_DAILY
 else
  echo $dt_end_wflw_GEEDW_ODS_BULK_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_ODS_BULK_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_B_PLP##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_PLP=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_PLP1=$(date -d "$dt_start_wflw_GEEDW_B_PLP" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_PLP1
dt_end_wflw_GEEDW_B_PLP=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_PLP1=$(date -d "$dt_end_wflw_GEEDW_B_PLP" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_PLP" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_PLP
 else
  echo $dt_end_wflw_GEEDW_B_PLP1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_B_ODS_DELETES##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_ODS_DELETES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_ODS_DELETES1=$(date -d "$dt_start_wflw_GEEDW_B_ODS_DELETES" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_ODS_DELETES1
dt_end_wflw_GEEDW_B_ODS_DELETES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_ODS_DELETES1=$(date -d "$dt_end_wflw_GEEDW_B_ODS_DELETES" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_ODS_DELETES" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_ODS_DELETES
 else
  echo $dt_end_wflw_GEEDW_B_ODS_DELETES1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_DAILY_BULK_LX_MX_TABLES##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES1=$(date -d "$dt_start_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES1
dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES1=$(date -d "$dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES
 else
  echo $dt_end_wflw_GEEDW_DAILY_BULK_LX_MX_TABLES1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_DAILY_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_BULK1=$(date -d "$dt_start_wflw_GEEDW_DAILY_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_BULK1
dt_end_wflw_GEEDW_DAILY_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_BULK1=$(date -d "$dt_end_wflw_GEEDW_DAILY_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_BULK
 else
  echo $dt_end_wflw_GEEDW_DAILY_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW05##wflw_GEEDW_DOCUMENTUM_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DOCUMENTUM_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DOCUMENTUM_BULK1=$(date -d "$dt_start_wflw_GEEDW_DOCUMENTUM_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DOCUMENTUM_BULK1
dt_end_wflw_GEEDW_DOCUMENTUM_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DOCUMENTUM_BULK1=$(date -d "$dt_end_wflw_GEEDW_DOCUMENTUM_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DOCUMENTUM_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DOCUMENTUM_BULK
 else
  echo $dt_end_wflw_GEEDW_DOCUMENTUM_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_PARTY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_PARTY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_PARTY1=$(date -d "$dt_start_wf_EG_PLP_PARTY" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_PARTY1
dt_end_wf_EG_PLP_PARTY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_PARTY1=$(date -d "$dt_end_wf_EG_PLP_PARTY" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_PARTY" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_PARTY
 else
  echo $dt_end_wf_EG_PLP_PARTY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_PARTY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_MEASUREMENT##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_MEASUREMENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_MEASUREMENT1=$(date -d "$dt_start_wf_EG_PLP_MEASUREMENT" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_MEASUREMENT1
dt_end_wf_EG_PLP_MEASUREMENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_MEASUREMENT1=$(date -d "$dt_end_wf_EG_PLP_MEASUREMENT" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_MEASUREMENT" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_MEASUREMENT
 else
  echo $dt_end_wf_EG_PLP_MEASUREMENT1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_MEASUREMENT | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wflw_GEEDW_WORK_ORDER##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_WORK_ORDER=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_WORK_ORDER1=$(date -d "$dt_start_wflw_GEEDW_WORK_ORDER" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_WORK_ORDER1
dt_end_wflw_GEEDW_WORK_ORDER=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_WORK_ORDER1=$(date -d "$dt_end_wflw_GEEDW_WORK_ORDER" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_WORK_ORDER" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_WORK_ORDER
 else
  echo $dt_end_wflw_GEEDW_WORK_ORDER1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_ORDER | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_EVENT##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_EVENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_EVENT1=$(date -d "$dt_start_wf_EG_PLP_EVENT" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_EVENT1
dt_end_wf_EG_PLP_EVENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_EVENT1=$(date -d "$dt_end_wf_EG_PLP_EVENT" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_EVENT" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_EVENT
 else
  echo $dt_end_wf_EG_PLP_EVENT1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_EVENT | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_ITEM##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_ITEM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_ITEM1=$(date -d "$dt_start_wf_EG_PLP_ITEM" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_ITEM1
dt_end_wf_EG_PLP_ITEM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_ITEM1=$(date -d "$dt_end_wf_EG_PLP_ITEM" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_ITEM" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_ITEM
 else
  echo $dt_end_wf_EG_PLP_ITEM1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_ITEM | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_GEOGRAPHY_LOCATION##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_GEOGRAPHY_LOCATION=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_GEOGRAPHY_LOCATION1=$(date -d "$dt_start_wf_EG_PLP_GEOGRAPHY_LOCATION" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_GEOGRAPHY_LOCATION1
dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION1=$(date -d "$dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION
 else
  echo $dt_end_wf_EG_PLP_GEOGRAPHY_LOCATION1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_GEOGRAPHY_LOCATION | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_DOCUMENT##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_DOCUMENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_DOCUMENT1=$(date -d "$dt_start_wf_EG_PLP_DOCUMENT" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_DOCUMENT1
dt_end_wf_EG_PLP_DOCUMENT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_DOCUMENT1=$(date -d "$dt_end_wf_EG_PLP_DOCUMENT" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_DOCUMENT" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_DOCUMENT
 else
  echo $dt_end_wf_EG_PLP_DOCUMENT1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_DOCUMENT | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_JOB_CONTROL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_JOB_CONTROL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_JOB_CONTROL1=$(date -d "$dt_start_wf_JOB_CONTROL" +'%m/%d/%Y %r')
echo $dt_start_wf_JOB_CONTROL1
dt_end_wf_JOB_CONTROL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_JOB_CONTROL1=$(date -d "$dt_end_wf_JOB_CONTROL" +'%m/%d/%Y %r')
if [ "$dt_end_wf_JOB_CONTROL" == "" ]
 then 
  echo $dt_end_wf_JOB_CONTROL
 else
  echo $dt_end_wf_JOB_CONTROL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_JOB_CONTROL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wf_EG_PLP_WORK_PROCESS##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_WORK_PROCESS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_WORK_PROCESS1=$(date -d "$dt_start_wf_EG_PLP_WORK_PROCESS" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_WORK_PROCESS1
dt_end_wf_EG_PLP_WORK_PROCESS=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_WORK_PROCESS1=$(date -d "$dt_end_wf_EG_PLP_WORK_PROCESS" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_WORK_PROCESS" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_WORK_PROCESS
 else
  echo $dt_end_wf_EG_PLP_WORK_PROCESS1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wf_EG_PLP_WORK_PROCESS | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW06##wflw_GEEDW_WORK_PROCESS_STANDARD##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_WORK_PROCESS_STANDARD=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_WORK_PROCESS_STANDARD1=$(date -d "$dt_start_wflw_GEEDW_WORK_PROCESS_STANDARD" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_WORK_PROCESS_STANDARD1
dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD1=$(date -d "$dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD
 else
  echo $dt_end_wflw_GEEDW_WORK_PROCESS_STANDARD1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW06 wflw_GEEDW_WORK_PROCESS_STANDARD | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wf_EG_PLP_CONTRACT##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_CONTRACT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_CONTRACT1=$(date -d "$dt_start_wf_EG_PLP_CONTRACT" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_CONTRACT1
dt_end_wf_EG_PLP_CONTRACT=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_CONTRACT1=$(date -d "$dt_end_wf_EG_PLP_CONTRACT" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_CONTRACT" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_CONTRACT
 else
  echo $dt_end_wf_EG_PLP_CONTRACT1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CONTRACT | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wf_EG_PLP_STAT_CMNT_BRIDGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_STAT_CMNT_BRIDGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_STAT_CMNT_BRIDGE1=$(date -d "$dt_start_wf_EG_PLP_STAT_CMNT_BRIDGE" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_STAT_CMNT_BRIDGE1
dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE1=$(date -d "$dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE
 else
  echo $dt_end_wf_EG_PLP_STAT_CMNT_BRIDGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_STAT_CMNT_BRIDGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wf_EG_PLP_INTEGRATION_TABLE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_INTEGRATION_TABLE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_INTEGRATION_TABLE1=$(date -d "$dt_start_wf_EG_PLP_INTEGRATION_TABLE" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_INTEGRATION_TABLE1
dt_end_wf_EG_PLP_INTEGRATION_TABLE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_INTEGRATION_TABLE1=$(date -d "$dt_end_wf_EG_PLP_INTEGRATION_TABLE" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_INTEGRATION_TABLE" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_INTEGRATION_TABLE
 else
  echo $dt_end_wf_EG_PLP_INTEGRATION_TABLE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_INTEGRATION_TABLE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wf_EG_PLP_CHANNEL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_EG_PLP_CHANNEL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_EG_PLP_CHANNEL1=$(date -d "$dt_start_wf_EG_PLP_CHANNEL" +'%m/%d/%Y %r')
echo $dt_start_wf_EG_PLP_CHANNEL1
dt_end_wf_EG_PLP_CHANNEL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_EG_PLP_CHANNEL1=$(date -d "$dt_end_wf_EG_PLP_CHANNEL" +'%m/%d/%Y %r')
if [ "$dt_end_wf_EG_PLP_CHANNEL" == "" ]
 then 
  echo $dt_end_wf_EG_PLP_CHANNEL
 else
  echo $dt_end_wf_EG_PLP_CHANNEL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_EG_PLP_CHANNEL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wflw_GEEDW_SHIPMENT_ADV_NOTIFICN##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN1=$(date -d "$dt_start_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN1
dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN1=$(date -d "$dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN
 else
  echo $dt_end_wflw_GEEDW_SHIPMENT_ADV_NOTIFICN1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wflw_GEEDW_SHIPMENT_ADV_NOTIFICN | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW07##wf_CDR_ITEM_HST##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wf_CDR_ITEM_HST=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wf_CDR_ITEM_HST1=$(date -d "$dt_start_wf_CDR_ITEM_HST" +'%m/%d/%Y %r')
echo $dt_start_wf_CDR_ITEM_HST1
dt_end_wf_CDR_ITEM_HST=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wf_CDR_ITEM_HST1=$(date -d "$dt_end_wf_CDR_ITEM_HST" +'%m/%d/%Y %r')
if [ "$dt_end_wf_CDR_ITEM_HST" == "" ]
 then 
  echo $dt_end_wf_CDR_ITEM_HST
 else
  echo $dt_end_wf_CDR_ITEM_HST1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW07 wf_CDR_ITEM_HST | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_NCN_MFG_QCR_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_NCN_MFG_QCR_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_NCN_MFG_QCR_STAGE1=$(date -d "$dt_start_wflw_NCN_MFG_QCR_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_NCN_MFG_QCR_STAGE1
dt_end_wflw_NCN_MFG_QCR_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_NCN_MFG_QCR_STAGE1=$(date -d "$dt_end_wflw_NCN_MFG_QCR_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_NCN_MFG_QCR_STAGE" == "" ]
 then 
  echo $dt_end_wflw_NCN_MFG_QCR_STAGE
 else
  echo $dt_end_wflw_NCN_MFG_QCR_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_DAILY_STAGE_P1##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_STAGE_P1=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_STAGE_P11=$(date -d "$dt_start_wflw_GEEDW_DAILY_STAGE_P1" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_STAGE_P11
dt_end_wflw_GEEDW_DAILY_STAGE_P1=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_STAGE_P11=$(date -d "$dt_end_wflw_GEEDW_DAILY_STAGE_P1" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_STAGE_P1" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_P1
 else
  echo $dt_end_wflw_GEEDW_DAILY_STAGE_P11
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_STAGE_P1 | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_DOCUMENTUM_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DOCUMENTUM_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DOCUMENTUM_STAGE1=$(date -d "$dt_start_wflw_GEEDW_DOCUMENTUM_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DOCUMENTUM_STAGE1
dt_end_wflw_GEEDW_DOCUMENTUM_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DOCUMENTUM_STAGE1=$(date -d "$dt_end_wflw_GEEDW_DOCUMENTUM_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DOCUMENTUM_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DOCUMENTUM_STAGE
 else
  echo $dt_end_wflw_GEEDW_DOCUMENTUM_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_BULK1=$(date -d "$dt_start_wflw_GEEDW_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_BULK1
dt_end_wflw_GEEDW_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_BULK1=$(date -d "$dt_end_wflw_GEEDW_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_BULK
 else
  echo $dt_end_wflw_GEEDW_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_TCT_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_TCT_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_TCT_BULK1=$(date -d "$dt_start_wflw_GEEDW_TCT_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_TCT_BULK1
dt_end_wflw_GEEDW_TCT_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_TCT_BULK1=$(date -d "$dt_end_wflw_GEEDW_TCT_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_TCT_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_TCT_BULK
 else
  echo $dt_end_wflw_GEEDW_TCT_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_TCT_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_TCT_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_TCT_STAGE1=$(date -d "$dt_start_wflw_GEEDW_TCT_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_TCT_STAGE1
dt_end_wflw_GEEDW_TCT_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_TCT_STAGE1=$(date -d "$dt_end_wflw_GEEDW_TCT_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_TCT_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_TCT_STAGE
 else
  echo $dt_end_wflw_GEEDW_TCT_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_REACH_LEGACY_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_REACH_LEGACY_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_REACH_LEGACY_BULK1=$(date -d "$dt_start_wflw_GEEDW_REACH_LEGACY_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_REACH_LEGACY_BULK1
dt_end_wflw_GEEDW_REACH_LEGACY_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_REACH_LEGACY_BULK1=$(date -d "$dt_end_wflw_GEEDW_REACH_LEGACY_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_REACH_LEGACY_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_REACH_LEGACY_BULK
 else
  echo $dt_end_wflw_GEEDW_REACH_LEGACY_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_DAILY_BULK_P1##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DAILY_BULK_P1=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DAILY_BULK_P11=$(date -d "$dt_start_wflw_GEEDW_DAILY_BULK_P1" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DAILY_BULK_P11
dt_end_wflw_GEEDW_DAILY_BULK_P1=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DAILY_BULK_P11=$(date -d "$dt_end_wflw_GEEDW_DAILY_BULK_P1" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DAILY_BULK_P1" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DAILY_BULK_P1
 else
  echo $dt_end_wflw_GEEDW_DAILY_BULK_P11
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DAILY_BULK_P1 | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_EPASS_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_EPASS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_EPASS_BULK1=$(date -d "$dt_start_wflw_GEEDW_EPASS_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_EPASS_BULK1
dt_end_wflw_GEEDW_EPASS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_EPASS_BULK1=$(date -d "$dt_end_wflw_GEEDW_EPASS_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_EPASS_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_EPASS_BULK
 else
  echo $dt_end_wflw_GEEDW_EPASS_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_NCN_MFG_QCR_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_NCN_MFG_QCR_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_NCN_MFG_QCR_BULK1=$(date -d "$dt_start_wflw_NCN_MFG_QCR_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_NCN_MFG_QCR_BULK1
dt_end_wflw_NCN_MFG_QCR_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_NCN_MFG_QCR_BULK1=$(date -d "$dt_end_wflw_NCN_MFG_QCR_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_NCN_MFG_QCR_BULK" == "" ]
 then 
  echo $dt_end_wflw_NCN_MFG_QCR_BULK
 else
  echo $dt_end_wflw_NCN_MFG_QCR_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_NCN_MFG_QCR_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_EPASS_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_EPASS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_EPASS_STAGE1=$(date -d "$dt_start_wflw_GEEDW_EPASS_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_EPASS_STAGE1
dt_end_wflw_GEEDW_EPASS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_EPASS_STAGE1=$(date -d "$dt_end_wflw_GEEDW_EPASS_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_EPASS_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_EPASS_STAGE
 else
  echo $dt_end_wflw_GEEDW_EPASS_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_EPASS_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_ESMS_BULK##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_ESMS_BULK=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_ESMS_BULK1=$(date -d "$dt_start_wflw_GEEDW_ESMS_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_ESMS_BULK1
dt_end_wflw_GEEDW_ESMS_BULK=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_ESMS_BULK1=$(date -d "$dt_end_wflw_GEEDW_ESMS_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_ESMS_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_ESMS_BULK
 else
  echo $dt_end_wflw_GEEDW_ESMS_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_ESMS_STAGE##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_ESMS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_ESMS_STAGE1=$(date -d "$dt_start_wflw_GEEDW_ESMS_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_ESMS_STAGE1
dt_end_wflw_GEEDW_ESMS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_ESMS_STAGE1=$(date -d "$dt_end_wflw_GEEDW_ESMS_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_ESMS_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_ESMS_STAGE
 else
  echo $dt_end_wflw_GEEDW_ESMS_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_ESMS_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_COPICS_PART_COST##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_COPICS_PART_COST=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_COPICS_PART_COST1=$(date -d "$dt_start_wflw_GEEDW_COPICS_PART_COST" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_COPICS_PART_COST1
dt_end_wflw_GEEDW_COPICS_PART_COST=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_COPICS_PART_COST1=$(date -d "$dt_end_wflw_GEEDW_COPICS_PART_COST" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_COPICS_PART_COST" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_COPICS_PART_COST
 else
  echo $dt_end_wflw_GEEDW_COPICS_PART_COST1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_PART_COST | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wkflw_EP6_STG##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wkflw_EP6_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wkflw_EP6_STG1=$(date -d "$dt_start_wkflw_EP6_STG" +'%m/%d/%Y %r')
echo $dt_start_wkflw_EP6_STG1
dt_end_wkflw_EP6_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wkflw_EP6_STG1=$(date -d "$dt_end_wkflw_EP6_STG" +'%m/%d/%Y %r')
if [ "$dt_end_wkflw_EP6_STG" == "" ]
 then 
  echo $dt_end_wkflw_EP6_STG
 else
  echo $dt_end_wkflw_EP6_STG1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_STG | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_OFS_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_OFS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_OFS_STAGE1=$(date -d "$dt_start_wflw_GEEDW_OFS_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_OFS_STAGE1
dt_end_wflw_GEEDW_OFS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_OFS_STAGE1=$(date -d "$dt_end_wflw_GEEDW_OFS_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_OFS_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_OFS_STAGE
 else
  echo $dt_end_wflw_GEEDW_OFS_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY1=$(date -d "$dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY1
dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY1=$(date -d "$dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY
 else
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE1=$(date -d "$dt_start_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE1
dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE1=$(date -d "$dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE
 else
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_TSN_TSNPSN_VARIANCE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY1=$(date -d "$dt_start_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY1
dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY1=$(date -d "$dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY
 else
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_DRILL_ATTRIBUTE_VAR_SUMMARY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_CMD_TASK_DAILY_SCHEDULE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_CMD_TASK_DAILY_SCHEDULE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_CMD_TASK_DAILY_SCHEDULE1=$(date -d "$dt_start_wflw_CMD_TASK_DAILY_SCHEDULE" +'%m/%d/%Y %r')
echo $dt_start_wflw_CMD_TASK_DAILY_SCHEDULE1
dt_end_wflw_CMD_TASK_DAILY_SCHEDULE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_CMD_TASK_DAILY_SCHEDULE1=$(date -d "$dt_end_wflw_CMD_TASK_DAILY_SCHEDULE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_CMD_TASK_DAILY_SCHEDULE" == "" ]
 then 
  echo $dt_end_wflw_CMD_TASK_DAILY_SCHEDULE
 else
  echo $dt_end_wflw_CMD_TASK_DAILY_SCHEDULE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_CMD_TASK_DAILY_SCHEDULE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY1=$(date -d "$dt_start_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY" +'%m/%d/%Y %r')
echo $dt_start_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY1
dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY1=$(date -d "$dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY" == "" ]
 then 
  echo $dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY
 else
  echo $dt_end_wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_UNIT_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY1=$(date -d "$dt_start_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY" +'%m/%d/%Y %r')
echo $dt_start_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY1
dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY1=$(date -d "$dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY" == "" ]
 then 
  echo $dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY
 else
  echo $dt_end_wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_geedw_MFG_SPARES_ERROR_REP_DETAIL_SUMMARY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_PODS_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_PODS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_PODS_DAILY1=$(date -d "$dt_start_wflw_GEEDW_B_PODS_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_PODS_DAILY1
dt_end_wflw_GEEDW_B_PODS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_PODS_DAILY1=$(date -d "$dt_end_wflw_GEEDW_B_PODS_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_PODS_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_PODS_DAILY
 else
  echo $dt_end_wflw_GEEDW_B_PODS_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY1=$(date -d "$dt_start_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY1
dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY1=$(date -d "$dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY
 else
  echo $dt_end_wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PLDB_EEDW_VARIANCE_WEEKLY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_INTEGRATION_RUN_DTL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_INTEGRATION_RUN_DTL1=$(date -d "$dt_start_wflw_GEEDW_B_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_INTEGRATION_RUN_DTL1
dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL1=$(date -d "$dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL
 else
  echo $dt_end_wflw_GEEDW_B_INTEGRATION_RUN_DTL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_S_PODS_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_S_PODS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_S_PODS_DAILY1=$(date -d "$dt_start_wflw_GEEDW_S_PODS_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_S_PODS_DAILY1
dt_end_wflw_GEEDW_S_PODS_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_S_PODS_DAILY1=$(date -d "$dt_end_wflw_GEEDW_S_PODS_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_S_PODS_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_S_PODS_DAILY
 else
  echo $dt_end_wflw_GEEDW_S_PODS_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_PODS_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY1=$(date -d "$dt_start_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY1
dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY1=$(date -d "$dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY
 else
  echo $dt_end_wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_CSINV_PLDB_EEDW_VARIANCE_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_FCD_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_FCD_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_FCD_DAILY1=$(date -d "$dt_start_wflw_GEEDW_B_FCD_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_FCD_DAILY1
dt_end_wflw_GEEDW_B_FCD_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_FCD_DAILY1=$(date -d "$dt_end_wflw_GEEDW_B_FCD_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_FCD_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_FCD_DAILY
 else
  echo $dt_end_wflw_GEEDW_B_FCD_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_FCD_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL1=$(date -d "$dt_start_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL1
dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL1=$(date -d "$dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL
 else
  echo $dt_end_wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_PODS_INTEGRATION_RUN_DTL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_S_FCD_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_S_FCD_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_S_FCD_DAILY1=$(date -d "$dt_start_wflw_GEEDW_S_FCD_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_S_FCD_DAILY1
dt_end_wflw_GEEDW_S_FCD_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_S_FCD_DAILY1=$(date -d "$dt_end_wflw_GEEDW_S_FCD_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_S_FCD_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_S_FCD_DAILY
 else
  echo $dt_end_wflw_GEEDW_S_FCD_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_S_FCD_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_OFS_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_OFS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_OFS_BULK1=$(date -d "$dt_start_wflw_GEEDW_OFS_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_OFS_BULK1
dt_end_wflw_GEEDW_OFS_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_OFS_BULK1=$(date -d "$dt_end_wflw_GEEDW_OFS_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_OFS_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_OFS_BULK
 else
  echo $dt_end_wflw_GEEDW_OFS_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_OFS_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_PODS_POST_REPAIR##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_PODS_POST_REPAIR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_PODS_POST_REPAIR1=$(date -d "$dt_start_wflw_GEEDW_PODS_POST_REPAIR" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_PODS_POST_REPAIR1
dt_end_wflw_GEEDW_PODS_POST_REPAIR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_PODS_POST_REPAIR1=$(date -d "$dt_end_wflw_GEEDW_PODS_POST_REPAIR" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_PODS_POST_REPAIR" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_PODS_POST_REPAIR
 else
  echo $dt_end_wflw_GEEDW_PODS_POST_REPAIR1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_PODS_POST_REPAIR | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY1=$(date -d "$dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY1
dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY1=$(date -d "$dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY
 else
  echo $dt_end_wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_CSINV_PLDB_EEDW_SUMMARY_COUNTS_WEEKLY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_B_OSC_ODS_EEDW_WEEKLY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_B_OSC_ODS_EEDW_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_B_OSC_ODS_EEDW_WEEKLY1=$(date -d "$dt_start_wflw_B_OSC_ODS_EEDW_WEEKLY" +'%m/%d/%Y %r')
echo $dt_start_wflw_B_OSC_ODS_EEDW_WEEKLY1
dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY1=$(date -d "$dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY" == "" ]
 then 
  echo $dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY
 else
  echo $dt_end_wflw_B_OSC_ODS_EEDW_WEEKLY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_B_OSC_ODS_EEDW_WEEKLY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_S_OSC_ODS_EEDW_WEEKLY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_S_OSC_ODS_EEDW_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_S_OSC_ODS_EEDW_WEEKLY1=$(date -d "$dt_start_wflw_S_OSC_ODS_EEDW_WEEKLY" +'%m/%d/%Y %r')
echo $dt_start_wflw_S_OSC_ODS_EEDW_WEEKLY1
dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY1=$(date -d "$dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY" == "" ]
 then 
  echo $dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY
 else
  echo $dt_end_wflw_S_OSC_ODS_EEDW_WEEKLY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_S_OSC_ODS_EEDW_WEEKLY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wkflw_EP6_UPD_BTCH_LD_CALL_STG##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wkflw_EP6_UPD_BTCH_LD_CALL_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wkflw_EP6_UPD_BTCH_LD_CALL_STG1=$(date -d "$dt_start_wkflw_EP6_UPD_BTCH_LD_CALL_STG" +'%m/%d/%Y %r')
echo $dt_start_wkflw_EP6_UPD_BTCH_LD_CALL_STG1
dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG1=$(date -d "$dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG" +'%m/%d/%Y %r')
if [ "$dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG" == "" ]
 then 
  echo $dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG
 else
  echo $dt_end_wkflw_EP6_UPD_BTCH_LD_CALL_STG1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_UPD_BTCH_LD_CALL_STG | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wkflw_EP6_BASE##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wkflw_EP6_BASE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wkflw_EP6_BASE1=$(date -d "$dt_start_wkflw_EP6_BASE" +'%m/%d/%Y %r')
echo $dt_start_wkflw_EP6_BASE1
dt_end_wkflw_EP6_BASE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wkflw_EP6_BASE1=$(date -d "$dt_end_wkflw_EP6_BASE" +'%m/%d/%Y %r')
if [ "$dt_end_wkflw_EP6_BASE" == "" ]
 then 
  echo $dt_end_wkflw_EP6_BASE
 else
  echo $dt_end_wkflw_EP6_BASE1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wkflw_EP6_BASE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_DEPARTURE_BULK##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DEPARTURE_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DEPARTURE_BULK1=$(date -d "$dt_start_wflw_GEEDW_DEPARTURE_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DEPARTURE_BULK1
dt_end_wflw_GEEDW_DEPARTURE_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DEPARTURE_BULK1=$(date -d "$dt_end_wflw_GEEDW_DEPARTURE_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DEPARTURE_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DEPARTURE_BULK
 else
  echo $dt_end_wflw_GEEDW_DEPARTURE_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_DEPARTURE_STAGE##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_DEPARTURE_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_DEPARTURE_STAGE1=$(date -d "$dt_start_wflw_GEEDW_DEPARTURE_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_DEPARTURE_STAGE1
dt_end_wflw_GEEDW_DEPARTURE_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_DEPARTURE_STAGE1=$(date -d "$dt_end_wflw_GEEDW_DEPARTURE_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_DEPARTURE_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_DEPARTURE_STAGE
 else
  echo $dt_end_wflw_GEEDW_DEPARTURE_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_DEPARTURE_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_TC5_DELETE##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_TC5_DELETE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_TC5_DELETE1=$(date -d "$dt_start_wflw_GEEDW_TC5_DELETE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_TC5_DELETE1
dt_end_wflw_GEEDW_TC5_DELETE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_TC5_DELETE1=$(date -d "$dt_end_wflw_GEEDW_TC5_DELETE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_TC5_DELETE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_TC5_DELETE
 else
  echo $dt_end_wflw_GEEDW_TC5_DELETE1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_DELETE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_TC5_STAGE##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_TC5_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_TC5_STAGE1=$(date -d "$dt_start_wflw_GEEDW_TC5_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_TC5_STAGE1
dt_end_wflw_GEEDW_TC5_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_TC5_STAGE1=$(date -d "$dt_end_wflw_GEEDW_TC5_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_TC5_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_TC5_STAGE
 else
  echo $dt_end_wflw_GEEDW_TC5_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW09##wflw_GEEDW_TC5_BULK##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_TC5_BULK=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_TC5_BULK1=$(date -d "$dt_start_wflw_GEEDW_TC5_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_TC5_BULK1
dt_end_wflw_GEEDW_TC5_BULK=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_TC5_BULK1=$(date -d "$dt_end_wflw_GEEDW_TC5_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_TC5_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_TC5_BULK
 else
  echo $dt_end_wflw_GEEDW_TC5_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_KRONOS_STAGE##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_KRONOS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_KRONOS_STAGE1=$(date -d "$dt_start_wflw_GEEDW_KRONOS_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_KRONOS_STAGE1
dt_end_wflw_GEEDW_KRONOS_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_KRONOS_STAGE1=$(date -d "$dt_end_wflw_GEEDW_KRONOS_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_KRONOS_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_KRONOS_STAGE
 else
  echo $dt_end_wflw_GEEDW_KRONOS_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_KRONOS_BULK##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_KRONOS_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_KRONOS_BULK1=$(date -d "$dt_start_wflw_GEEDW_KRONOS_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_KRONOS_BULK1
dt_end_wflw_GEEDW_KRONOS_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_KRONOS_BULK1=$(date -d "$dt_end_wflw_GEEDW_KRONOS_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_KRONOS_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_KRONOS_BULK
 else
  echo $dt_end_wflw_GEEDW_KRONOS_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_FETCH_STAGE_P1##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_FETCH_STAGE_P1=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_FETCH_STAGE_P11=$(date -d "$dt_start_wflw_GEEDW_FETCH_STAGE_P1" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_FETCH_STAGE_P11
dt_end_wflw_GEEDW_FETCH_STAGE_P1=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_FETCH_STAGE_P11=$(date -d "$dt_end_wflw_GEEDW_FETCH_STAGE_P1" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_FETCH_STAGE_P1" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_FETCH_STAGE_P1
 else
  echo $dt_end_wflw_GEEDW_FETCH_STAGE_P11
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_STAGE_P1 | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_FETCH_BULK##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_FETCH_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_FETCH_BULK1=$(date -d "$dt_start_wflw_GEEDW_FETCH_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_FETCH_BULK1
dt_end_wflw_GEEDW_FETCH_BULK=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_FETCH_BULK1=$(date -d "$dt_end_wflw_GEEDW_FETCH_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_FETCH_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_FETCH_BULK
 else
  echo $dt_end_wflw_GEEDW_FETCH_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_FETCH_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_COPICS_MSAN_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_COPICS_MSAN_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_COPICS_MSAN_STAGE1=$(date -d "$dt_start_wflw_GEEDW_COPICS_MSAN_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_COPICS_MSAN_STAGE1
dt_end_wflw_GEEDW_COPICS_MSAN_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_COPICS_MSAN_STAGE1=$(date -d "$dt_end_wflw_GEEDW_COPICS_MSAN_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_COPICS_MSAN_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_COPICS_MSAN_STAGE
 else
  echo $dt_end_wflw_GEEDW_COPICS_MSAN_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'


#############################################EEDW08##wflw_GEEDW_COPICS_MSAN_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_COPICS_MSAN_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_COPICS_MSAN_BULK1=$(date -d "$dt_start_wflw_GEEDW_COPICS_MSAN_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_COPICS_MSAN_BULK1
dt_end_wflw_GEEDW_COPICS_MSAN_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_COPICS_MSAN_BULK1=$(date -d "$dt_end_wflw_GEEDW_COPICS_MSAN_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_COPICS_MSAN_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_COPICS_MSAN_BULK
 else
  echo $dt_end_wflw_GEEDW_COPICS_MSAN_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_COPICS_MSAN_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_SBOM_WCRT_ICM##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_SBOM_WCRT_ICM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_SBOM_WCRT_ICM1=$(date -d "$dt_start_wflw_GEEDW_SBOM_WCRT_ICM" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_SBOM_WCRT_ICM1
dt_end_wflw_GEEDW_SBOM_WCRT_ICM=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_SBOM_WCRT_ICM1=$(date -d "$dt_end_wflw_GEEDW_SBOM_WCRT_ICM" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_SBOM_WCRT_ICM" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_SBOM_WCRT_ICM
 else
  echo $dt_end_wflw_GEEDW_SBOM_WCRT_ICM1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SBOM_WCRT_ICM | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_SAP_ECCN_WEEKLY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_SAP_ECCN_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_SAP_ECCN_WEEKLY1=$(date -d "$dt_start_wflw_GEEDW_SAP_ECCN_WEEKLY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_SAP_ECCN_WEEKLY1
dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY1=$(date -d "$dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY
 else
  echo $dt_end_wflw_GEEDW_SAP_ECCN_WEEKLY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_WEEKLY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_SAP_ECCN_DAILY##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_SAP_ECCN_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_SAP_ECCN_DAILY1=$(date -d "$dt_start_wflw_GEEDW_SAP_ECCN_DAILY" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_SAP_ECCN_DAILY1
dt_end_wflw_GEEDW_SAP_ECCN_DAILY=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_SAP_ECCN_DAILY1=$(date -d "$dt_end_wflw_GEEDW_SAP_ECCN_DAILY" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_SAP_ECCN_DAILY" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_SAP_ECCN_DAILY
 else
  echo $dt_end_wflw_GEEDW_SAP_ECCN_DAILY1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_SAP_ECCN_DAILY | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_RBS_STAGE_SQLSVR##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_RBS_STAGE_SQLSVR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_RBS_STAGE_SQLSVR1=$(date -d "$dt_start_wflw_GEEDW_RBS_STAGE_SQLSVR" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_RBS_STAGE_SQLSVR1
dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR1=$(date -d "$dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR
 else
  echo $dt_end_wflw_GEEDW_RBS_STAGE_SQLSVR1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_STAGE_SQLSVR | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_RBS_BULK_SQLSVR##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_RBS_BULK_SQLSVR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_RBS_BULK_SQLSVR1=$(date -d "$dt_start_wflw_GEEDW_RBS_BULK_SQLSVR" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_RBS_BULK_SQLSVR1
dt_end_wflw_GEEDW_RBS_BULK_SQLSVR=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_RBS_BULK_SQLSVR1=$(date -d "$dt_end_wflw_GEEDW_RBS_BULK_SQLSVR" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_RBS_BULK_SQLSVR" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_RBS_BULK_SQLSVR
 else
  echo $dt_end_wflw_GEEDW_RBS_BULK_SQLSVR1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_RBS_BULK_SQLSVR | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_KRONOS_DEL##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_KRONOS_DEL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_KRONOS_DEL1=$(date -d "$dt_start_wflw_GEEDW_KRONOS_DEL" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_KRONOS_DEL1
dt_end_wflw_GEEDW_KRONOS_DEL=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_KRONOS_DEL1=$(date -d "$dt_end_wflw_GEEDW_KRONOS_DEL" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_KRONOS_DEL" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_KRONOS_DEL
 else
  echo $dt_end_wflw_GEEDW_KRONOS_DEL1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_KRONOS_DEL | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_INTERFACE_STAGE##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_INTERFACE_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_INTERFACE_STAGE1=$(date -d "$dt_start_wflw_GEEDW_INTERFACE_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_INTERFACE_STAGE1
dt_end_wflw_GEEDW_INTERFACE_STAGE=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_INTERFACE_STAGE1=$(date -d "$dt_end_wflw_GEEDW_INTERFACE_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_INTERFACE_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_INTERFACE_STAGE
 else
  echo $dt_end_wflw_GEEDW_INTERFACE_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_INTERFACE_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_INTERFACE_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_INTERFACE_BULK1=$(date -d "$dt_start_wflw_GEEDW_INTERFACE_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_INTERFACE_BULK1
dt_end_wflw_GEEDW_INTERFACE_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_INTERFACE_BULK1=$(date -d "$dt_end_wflw_GEEDW_INTERFACE_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_INTERFACE_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_INTERFACE_BULK
 else
  echo $dt_end_wflw_GEEDW_INTERFACE_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_INTERFACE_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_CAS_WLYECCN##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_CAS_WLYECCN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_CAS_WLYECCN1=$(date -d "$dt_start_wflw_GEEDW_CAS_WLYECCN" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_CAS_WLYECCN1
dt_end_wflw_GEEDW_CAS_WLYECCN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_CAS_WLYECCN1=$(date -d "$dt_end_wflw_GEEDW_CAS_WLYECCN" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_CAS_WLYECCN" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_CAS_WLYECCN
 else
  echo $dt_end_wflw_GEEDW_CAS_WLYECCN1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_WLYECCN | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW08##wflw_GEEDW_CAS_DLYECCN##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_CAS_DLYECCN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_CAS_DLYECCN1=$(date -d "$dt_start_wflw_GEEDW_CAS_DLYECCN" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_CAS_DLYECCN1
dt_end_wflw_GEEDW_CAS_DLYECCN=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_CAS_DLYECCN1=$(date -d "$dt_end_wflw_GEEDW_CAS_DLYECCN" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_CAS_DLYECCN" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_CAS_DLYECCN
 else
  echo $dt_end_wflw_GEEDW_CAS_DLYECCN1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_CAS_DLYECCN | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW03##wflw_GEEDW_CLRORBT_BULK##INF_AV_ASCII############################################
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_CLRORBT_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_CLRORBT_BULK1=$(date -d "$dt_start_wflw_GEEDW_CLRORBT_BULK" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_CLRORBT_BULK1
dt_end_wflw_GEEDW_CLRORBT_BULK=`pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_CLRORBT_BULK1=$(date -d "$dt_end_wflw_GEEDW_CLRORBT_BULK" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_CLRORBT_BULK" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_CLRORBT_BULK
 else
  echo $dt_end_wflw_GEEDW_CLRORBT_BULK1
fi
pmcmd getworkflowdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_BULK | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW03##wflw_GEEDW_CLRORBT_STAGE##INF_AV_UNICODE############################################
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_CLRORBT_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_CLRORBT_STAGE1=$(date -d "$dt_start_wflw_GEEDW_CLRORBT_STAGE" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_CLRORBT_STAGE1
dt_end_wflw_GEEDW_CLRORBT_STAGE=`pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_CLRORBT_STAGE1=$(date -d "$dt_end_wflw_GEEDW_CLRORBT_STAGE" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_CLRORBT_STAGE" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_CLRORBT_STAGE
 else
  echo $dt_end_wflw_GEEDW_CLRORBT_STAGE1
fi
pmcmd getworkflowdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_CLRORBT_STAGE | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'

#############################################EEDW03##wflw_GEEDW_COPICS_PART_COST_STG##INF_AV_UTF8############################################
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Folder:' | awk '{print $2}' | cut -c2-7
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Workflow run id' | awk '{print $4}' | cut -c2- | sed 's/].\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Workflow:' | awk '{print $2}' | cut -c2- | sed 's/]\+$//'
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Connected to Integration Service:' | awk '{print $5}' | cut -c2- | sed 's/].\+$//'
dt_start_wflw_GEEDW_COPICS_PART_COST_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Start time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_start_wflw_GEEDW_COPICS_PART_COST_STG1=$(date -d "$dt_start_wflw_GEEDW_COPICS_PART_COST_STG" +'%m/%d/%Y %r')
echo $dt_start_wflw_GEEDW_COPICS_PART_COST_STG1
dt_end_wflw_GEEDW_COPICS_PART_COST_STG=`pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'End time:' | awk '{print $3,$4,$5,$6,$7 }' | cut -c2- | sed 's/]\+$//'`
dt_end_wflw_GEEDW_COPICS_PART_COST_STG1=$(date -d "$dt_end_wflw_GEEDW_COPICS_PART_COST_STG" +'%m/%d/%Y %r')
if [ "$dt_end_wflw_GEEDW_COPICS_PART_COST_STG" == "" ]
 then 
  echo $dt_end_wflw_GEEDW_COPICS_PART_COST_STG
 else
  echo $dt_end_wflw_GEEDW_COPICS_PART_COST_STG1
fi
pmcmd getworkflowdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_COPICS_PART_COST_STG | grep 'Workflow run status:' | awk '{print $4}' | cut -c2- | sed 's/]\+$//'
sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_WORKLFOW_STATUS_Data_Format.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_WORKLFOW_STATUS_Data_Format_LOG.txt 2>&1
