
##################################################################################################################################
## 																		    ##
## Script Name:sh_GEEDW_SHELL_CMD_wflw_GEEDW_REACH_LEGACY_BULK.sh 									    ##
## Author: Sanjib Patra 															    ##
## Creation Date:09-AUG-2012 														    ##
## Modified Date: 																    ##
## 																		    ##
## Description: 																    ##
##   This Script triggers wflw_GEEDW_CDR_DMREL_BULK					  						    ##
## 																		    ##
##          																	    ##
##################################################################################################################################


pmcmd startworkflow -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_REACH_LEGACY_BULK
