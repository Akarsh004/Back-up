##################################################################################################################################
##                                                                                                                              ##
##       Script Name:sh_GEEDW_SHELL_CALL_ORAP_BULK.sh                                                                           ##
##       Author: Ragini                                                                                                         ##
##       Creation Date:20th Sept 2011                                                                                           ##
##       Modified Date:                                                                                                         ##
##                                                                                                                              ##
##       Description:                                                                                                           ##
##          This script calls the wflw_GEEDW_ORAP_BULK workflow in EEDW04                                                       ##
##                                                                                                                              ##
##                                                                                                                              ##
##################################################################################################################################

pmcmd startworkflow -sv INF_AV_UTF8 -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW04 wflw_GEEDW_ORAP_BULK