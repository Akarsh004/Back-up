#########################################################################################
##	Author: Ragini Banerjee, 28-DEC-2011
##
##	This script
##	1) This Script calls the workflow wflw_GEEDW_DAILY_BULK which is loacted in the folder EEDW05
##	 
####################################################################################################

pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW03 wflw_GEEDW_DAILY_BULK_ONCE
