sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_GEEDW_ODS_S_DAILY_STAGE1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_GEEDW_ODS_S_DAILY_STAGE_LOG.txt 2>&1
