#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_GEEDW_SHELL_SESSION_STAT.sh
# Creation Date:26/09/12
# Last Modified: 29/10/12
# Purpose:Generating the Session Statistics from the sesslog
# The script expects 5 arguments as input.
# Arg 1 :- File Name containing the session and log file names.
# Arg 2 :- Script Log filename where output of each commnad can be stored.
# Arg 3 :- PMCMD Log file name where the output of the pmcmd command can be stored.
# Arg 4 :- Temporary file name .
# Arg 5 :- Report filename where the session details can be stored.
# Created By: Sasmita
#
# ----------------------------------------------------------------------------

######################################################################
##################      LOCAL VARIABLES       ########################
######################################################################

SRCPATH=/data/informatica/ETCOE/EEDW01/Config/
LOADERPATH=/data/informatica/ETCOE/EEDW01/OutFiles/
SESSLOGPATH=/data/informatica/ETCOE/EEDW01/SessLogs/
SRCFILES=/data/informatica/ETCOE/EEDW01/SrcFiles/
CONFIGFILES=/data/informatica/ETCOE/EEDW01/Config/
File_name=$1
Log_File=$2
PMCMD_Log_File=$3
Temp_File=$4
Report_File=$5

######################################################################
####################       Main Code         #########################
######################################################################
echo "INFO :" `date`  ":SCRIPT sh_GEEDW_SHELL_SESSION_STAT.sh PROCESSING STARTED"   > $SESSLOGPATH"$Log_File"

################ Function To Calculate Numeric Month ###################
Numeric_Month()
{
Month=$1
       if [ $Month = 'Jan' ]; 
	then
		num_month=1
	elif [ $Month = 'Feb' ];
		then
			num_month=2
	elif [ $Month = 'Mar' ];
		then
			num_month=3
	elif [ $Month = 'Apr' ];
		then
			num_month=4
	elif [ $Month = 'May' ];
		then
			num_month=5
	elif [ $Month = 'Jun' ];
		then
			num_month=6
	elif [ $Month = 'Jul' ];
		then
			num_month=7
	elif [ $Month = 'Aug' ];
		then
			num_month=8
	elif [ $Month = 'Sep' ];
		then
			num_month=9
	elif [ $Month = Oct ];
		then
			num_month=10
	echo "1"
	elif [ $Month = 'Nov' ];
		then
			num_month=11
	elif [ $Month = 'Dec' ];
		then
			num_month=12
	fi
echo "INFO :" `date`  ":Numeric Month=" $num_month   >> $SESSLOGPATH"$Log_File"
}
Report_File=`echo $Report_File | sed 's/\.txt/\.csv/'`
#####Checks for the SrcFiles directory##########
if [ -d $SRCFILES ]; then
        cd $SRCFILES
	if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$SRCFILES}" successful "   >> $SESSLOGPATH"$Log_File"
         else
                    echo "ERROR:" `date` ":Path change" {$SRCFILES}" failed "  >> $SESSLOGPATH"$Log_File"
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$SRCFILES} " Not Found "  >> $SESSLOGPATH"$Log_File"
        exit 1
fi
######Checks for the Report File .If Present delete it###########
	
if test -f $Report_File
	then
		echo "INFO :" `date`  ":Report " $Report_File " Found"   >> $SESSLOGPATH"$Log_File"
		rm -f $Report_File
		echo "INFO :" `date`  ":" $Report_File " Deleted"   >> $SESSLOGPATH"$Log_File"

	else
		echo "INFO :" `date`  ":Report " $Report_File " Not Found"   >> $SESSLOGPATH"$Log_File"
		
	fi
#####Checks for the Config directory##########
if [ -d $CONFIGFILES ]; then
        cd $CONFIGFILES
	if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$CONFIGFILES}" successful "   >> $SESSLOGPATH"$Log_File"
         else
                    echo "ERROR:" `date` ":Path change" {$CONFIGFILES}" failed "  >> $SESSLOGPATH"$Log_File"
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$CONFIGFILES} " Not Found "  >> $SESSLOGPATH"$Log_File"
        exit 1
fi
######Checks for the File containing all the sesslog names###########	
if test -f $File_name
	then
		echo "INFO :" `date`  ":Sesslog " $File_name " Found"   >> $SESSLOGPATH"$Log_File"
	else
		echo "ERROR :" `date`  ":Sesslog " $File_name " Not Found"   >> $SESSLOGPATH"$Log_File"
		exit 1
	fi
#########Get the First Line from the file #################
First_Row=`head -1 $File_name`
echo "INFO :" `date`  ":First Line the config file   "$First_Row"  found "   >> $SESSLOGPATH"$Log_File"
#########Get the Folder Name################
Folder_Name=`echo $First_Row|awk -F"," '{print $1}'`
echo "INFO :" `date`  ":Folder Name  "$Folder_Name"  found "   >> $SESSLOGPATH"$Log_File"
#########Get the workflow Name##############
Wflw_Name=`echo $First_Row|awk -F"," '{print $2}'`
echo "INFO :" `date`  ":Workflow object Name  "$Wflw_Name"  found "   >> $SESSLOGPATH"$Log_File"

`sed 1d $File_name >$SESSLOGPATH"$Temp_File"`
chmod 777 $SESSLOGPATH"$Temp_File"
cat $SESSLOGPATH"$Temp_File" >> $SESSLOGPATH"$Log_File"
#######reads the sesslog names from the file ############
cat $SESSLOGPATH"$Temp_File" |
{
while read Line1
do
echo "INFO :" `date`  ":File Read  "$Line1" Line found "   >> $SESSLOGPATH"$Log_File"
###########Get the task name ####################
Task_Name=`echo $Line1|awk -F"," '{print $1}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": Task Name " $Task_Name "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Task Name " $Task_Name " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

###########Get the session Log name##############
SessLog_File_Name=`echo $Line1|awk -F"," '{print $2}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": SessLog Name " $SessLog_File_Name "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": SessLog Name " $SessLog_File_Name " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
##########Get the Loader Log Name#############
Loader_Log=`echo $Line1|awk -F"," '{print $3}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": Loader Log Name " $Loader_Log "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Loader Log Name " $Loader_Log " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

##########Check for the sesslog path#############
if [ -d $SESSLOGPATH ]; then
        cd $SESSLOGPATH
	if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$SESSLOGPATH}" successful "   >> $SESSLOGPATH"$Log_File"
         else
                    echo "ERROR:" `date` ":Path change" {$SESSLOGPATH}" failed "  >> $SESSLOGPATH"$Log_File"
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$SESSLOGPATH} " Not Found "  >> $SESSLOGPATH"$Log_File"
        exit 1
fi
##############Get the task Properties##############
if [ $Wflw_Name = 'wflw_GEEDW_ORAP_STAGE' ];
	then
			pmcmd gettaskdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f $Folder_Name -w $Wflw_Name $Task_Name>$PMCMD_Log_File
elif [ $Wflw_Name = 'wflw_GEEDW_ORAP_BULK' ];
	then
			pmcmd gettaskdetails -sv INF_AV_UTF8 -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f $Folder_Name -w $Wflw_Name $Task_Name>$PMCMD_Log_File
elif [ $Wflw_Name = 'wflw_GEEDW_DAILY_STAGE' ];
	then
			pmcmd gettaskdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f $Folder_Name -w $Wflw_Name $Task_Name>$PMCMD_Log_File
elif [ $Wflw_Name = 'wflw_GEEDW_DAILY_STAGE_P1' ];
	then
			pmcmd gettaskdetails -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f $Folder_Name -w $Wflw_Name $Task_Name>$PMCMD_Log_File
else
			pmcmd gettaskdetails -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f $Folder_Name -w $Wflw_Name $Task_Name>$PMCMD_Log_File
fi

############Check for the presence of the sesslog file  #############
if test -f $SessLog_File_Name
	then
		echo "INFO :" `date`  ":Sesslog " $SessLog_File_Name " Found"   >> $SESSLOGPATH"$Log_File"
	else
		echo "ERROR :" `date`  ":Sesslog " $SessLog_File_Name " Not Found"   >> $SESSLOGPATH"$Log_File"
		exit 1
	fi

############Check for the presence of the PMCMD log file  #############
if test -f $PMCMD_Log_File
	then
		echo "INFO :" `date`  ":PMCMD log " $PMCMD_Log_File " Found"   >> $SESSLOGPATH"$Log_File"
	else
		echo "ERROR :" `date`  ":PMCMD log " $PMCMD_Log_File " Not Found"   >> $SESSLOGPATH"$Log_File"
		exit 1
	fi

##############MAPPING NAME###############
mapping_name=`cat $SessLog_File_Name | grep -F 'Mapping name: ' | head -1 | awk -F " " '{print $5}' | cut -d"." -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": Mapping Name " $mapping_name "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Mapping Name " $mapping_name " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
##########WORKFLOW NAME################
workflow_name=`cat $PMCMD_Log_File | grep -F 'Workflow:' | awk -F " " '{print $2}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": WorkFlow Name " $workflow_name "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": WorkFlow Name " $workflow_name " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
############SESSION NAME################
session_name=`cat $PMCMD_Log_File | grep -F 'Session Instance:' | awk -F " " '{print $3}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ": Session Name " $session_name "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Session Name " $session_name " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

###########SESSION START MONTH################
session_start_mon=`cat $PMCMD_Log_File | grep -F 'Start time:' | head -1 | awk -F " " '{print $4}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Start Month " $session_start_mon "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Start Month " $session_start_mon " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
##########NUMERIC START MONTH##########
Numeric_Month $session_start_mon
num_start_month=`echo $num_month`
  echo "INFO :" `date`  ":Start Month " $num_start_month "found "   >> $SESSLOGPATH"$Log_File"
##########SESSION START DAY#############
session_start_Day=`cat $PMCMD_Log_File | grep -F 'Start time:' | head -1 | awk -F " " '{print $5}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Start Day " $session_start_Day "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":Start Day " $session_start_Day " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
############SESSION START YEAR#############
session_start_year=`cat $PMCMD_Log_File | grep -F 'Start time:' | head -1 | awk -F " " '{print $7}' | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Start Year " $session_start_year "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Start Year " $session_start_year " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
############SESSION START TIME############
session_start_time=`cat $PMCMD_Log_File | grep -F 'Start time:' | head -1 | awk -F " " '{print $6}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Start Time " $session_start_time "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":Start Time " $session_start_time " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
###########SESSION END MONTH##############
session_end_mon=`cat $PMCMD_Log_File | grep -F 'End time:' |head -1 | awk -F " " '{print $4}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":End Month " $session_end_mon "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": End Month " $session_end_mon " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
################NUMERIC SESSION END MONTH###############
Numeric_Month $session_end_mon
num_end_month=`echo $num_month`
             echo "INFO :" `date`  ":Numeric End Month " $num_end_month "found "   >> $SESSLOGPATH"$Log_File"
        		 
################SESSION END DAY#################
session_end_Day=`cat $PMCMD_Log_File | grep -F 'End time:' | head -1 | awk -F " " '{print $5}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":End Day " $session_end_Day "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":End Day " $session_end_Day " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
##############SESSION END YEAR###############
session_end_year=`cat $PMCMD_Log_File | grep -F 'End time:' | head -1 | awk -F " " '{print $7}'|cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":End Year " $session_end_year "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": End Year " $session_end_year " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
#####################SESSION END TIME #################
session_end_time=`cat $PMCMD_Log_File | grep -F 'End time:' | head -1 | awk -F " " '{print $6}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":End Time " $session_end_time "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": End Time  " $session_end_time " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
#################GET THE RECORD COUNT ################
###########IF LOADER LOG IS NOT PRESENT , GET THE COUNTS FROM THE SESSION LOG ELSE GET THE COUNTS FROM THE LOADER LOG###############
if [ -z $Loader_Log ]
then
echo "INFO :" `date`  ":Extracting the load information from the sesslog "   >> $SESSLOGPATH"$Log_File"
source_insert_rows=`cat $PMCMD_Log_File | grep -F 'Source success rows' | awk -F " " '{print $4}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Source Rows " $source_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Source Rows " $source_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
if [ -z $source_insert_rows ]
then
source_insert_rows=`cat $SessLog_File_Name | grep -F 'Output Rows' | head -1 | awk -F " " '{print $3}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Source Rows " $source_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Source Rows " $source_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
fi
target_insert_rows=`cat $PMCMD_Log_File | grep -F 'Target success rows:' |awk -F " " '{print $4}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Inserted Rows " $target_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":Target Inserted Rows " $target_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
if [ -z $target_insert_rows ]
then
target_insert_rows=`cat $SessLog_File_Name | grep -F 'Applied Rows' | tail -1 | awk -F " " '{print $9}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Inserted Rows " $target_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Target Inserted Rows " $target_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
fi

target_reject_rows=`cat $SessLog_File_Name | grep -F 'Rejected Rows' | tail -1 | awk -F " " '{print $12}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Rejected Rows " $target_reject_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Target Rejected Rows " $target_reject_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

else
echo "INFO :" `date`  ":Extracting the load information from the loaderlog "   >> $SESSLOGPATH"$Log_File"

############ Change Path to OutFiles Directory #################
if [ -d $LOADERPATH ]; then
        cd $LOADERPATH
	if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$LOADERPATH}" successful "   >> $SESSLOGPATH"$Log_File"
         else
                    echo "ERROR:" `date` ":Path change" {$LOADERPATH}" failed "  >> $SESSLOGPATH"$Log_File"
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$LOADERPATH} " Not Found "  >> $SESSLOGPATH"$Log_File"
        exit 1
fi
############Check for the Loader Log Type##################
Fast_Load_Type=`cat $Loader_Log | grep -F 'FASTLOAD' | head -1 | awk -F" " '{print $2}'`
Multi_Load_Type=`cat $Loader_Log | grep -F 'MultiLoad' | head -1| awk -F" " '{print $3}'`

echo "INFO :" `date`  ":Load Type  :"$Fast_Load_Type " "$Multi_Load_Type   >> $SESSLOGPATH"$Log_File"

################ Get the load informations from the Loader Log################
if  [[ -n $Fast_Load_Type && -z $Multi_Load_Type ]]
then
echo "INFO :" `date`  ":Target Load Tyep : " $Fast_Load_Type "found "   >> $SESSLOGPATH"$Log_File"
source_insert_rows=`cat $Loader_Log | grep -F 'Total Records Read' | head -1 | awk -F "=" '{print $2}' `
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Source Rows " $source_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Source Rows " $source_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
target_insert_rows=`cat $Loader_Log | grep -F 'Total Inserts Applied' | head -1 | awk -F "=" '{print $2}' `
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Inserted Rows " $target_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":Target Inserted Rows " $target_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

target_reject_rows=`cat $SessLog_File_Name | grep -F 'Total Records rejected' | head -1 | awk -F "=" '{print $2}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Rejected Rows " $target_reject_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Target Rejected Rows " $target_reject_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
elif  [[ -z $Fast_Load_Type && -n $Multi_Load_Type ]]
then
echo "INFO :" `date`  ":Target Load Tyep : " $Multi_Load_Type "found "   >> $SESSLOGPATH"$Log_File"
source_insert_rows=`cat $Loader_Log | grep -F 'Candidate records considered:' | head -1 | awk -F " " '{print $5}' `
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Source Rows " $source_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Source Rows " $source_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
target_insert_rows=`cat $Loader_Log | grep -F 'Apply conditions satisfied:' | head -1 | awk -F " " '{print $5}' `
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Inserted Rows " $target_insert_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ":Target Inserted Rows " $target_insert_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

target_reject_rows=`cat $SessLog_File_Name | grep -F 'Candidate records rejected:' | head -1 | awk -F " " '{print $2}'`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Rejected Rows " $target_reject_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Target Rejected Rows " $target_reject_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
fi
fi
if [ -z $target_reject_rows ]
then
target_reject_rows=0
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Target Rejected Rows " $target_reject_rows "found "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Target Rejected Rows " $target_reject_rows " not found "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi

fi
##############Change to Sesslog Path###############
if [ -d $SESSLOGPATH ]; then
        cd $SESSLOGPATH
	if [ $? -eq 0 ]
         then
                    echo "INFO :" `date`  ":Path Change "{$SESSLOGPATH}" successful "   >> $SESSLOGPATH"$Log_File"
         else
                    echo "ERROR:" `date` ":Path change" {$SESSLOGPATH}" failed "  >> $SESSLOGPATH"$Log_File"
                    exit 1
         fi
else
        echo "ERROR:" `date` ":Path" {$SESSLOGPATH} " Not Found "  >> $SESSLOGPATH"$Log_File"
        exit 1
fi
##############SESSION STATUS###############
workflow_status=`cat $PMCMD_Log_File | grep -F 'Task run status:' | awk -F " " '{print $4}' | cut -d"[" -f2 | cut -d"]" -f1`
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Workflow Status " $workflow_status "found "   >> $SESSLOGPATH"$Log_File"
			else
				  echo "INFO :" `date`  ":Workflow Status not found "   >> $SESSLOGPATH"$Log_File"
				  exit 1
			fi
###################ERROR###################
error=`cat $PMCMD_Log_File | grep -F 'Task run error message:' | awk '{delim=" ";for(i=5;i<=NF;i++) {printf delim "%s",$i,delim=OFS};print "\n"}' | tr -d '[' | tr -d ']'`
		if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Error  " $error "found "   >> $SESSLOGPATH"$Log_File"
			else
				  echo "INFO :" `date`  ":Error not found "   >> $SESSLOGPATH"$Log_File"
				  exit 1
			fi

if [ "$error" = " Completed successfully." ];
	then 
		error='No Error'
		echo "INFO :" `date`  ":Error  " $error "found "   >> $SESSLOGPATH"$Log_File"
	else
		error=`cat $PMCMD_Log_File | grep -A 2 'Task run error message:'`
		echo "INFO :" `date`  ":Error  " $error "found "   >> $SESSLOGPATH"$Log_File"

	fi

##############CREATE THE .CSV FILE ###############

echo $workflow_name","$session_name","$mapping_name","$session_start_year"-"$num_start_month"-"$session_start_Day" "$session_start_time","$session_end_year"-"$num_end_month"-"$session_end_Day" "$session_end_time","$source_insert_rows","$target_insert_rows","$target_reject_rows","$workflow_status","$error >> $SRCFILES"$Report_File"
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Report File  " $Report_File "cretaed "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Report File " $Report_File " can not be created "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
#############CHANGE THE PERMISSION OF THE FILE################
chmod 777 $SRCFILES"$Report_File"
if [ $? -eq 0 ]
         		then
                  		  echo "INFO :" `date`  ":Report File " $Report_File "permission changed "   >> $SESSLOGPATH"$Log_File"
        		 else
                 		  echo "ERROR:" `date` ": Report File " $Report_File " permission can not be changed "  >> $SESSLOGPATH"$Log_File"
                 	   	  exit 1
        		 fi
done 
}
echo $Report_File > $SRCFILES"GEEDW_SESSION_STAT.csv"

exit 0
