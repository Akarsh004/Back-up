#########################################################################################
##                                                                                     ##
##   File: sh_GEEDW_SHELL_CALL_PODS_PRE_RPR_BULK.sh                                    ##
##   Creation Date:20/09/12                                                            ##
##   Last Modified:15/10/12                                                            ##
##   Purpose:This script is used to call PODS Bulk workflow                            ##
##   Created By: Subhashree                                                            ##
##                                                                                     ##
#########################################################################################


pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM1 -uv PM_USER -pv PM_PASSWD  -f EEDW09 wflw_GEEDW_B_PODS_DAILY
