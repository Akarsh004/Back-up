#########################################################################################
##                                                                                     ##
##   File: sh_GEEDW_SHELL_CALL_FCD_BULK.sh                                             ##
##   Creation Date:20/09/12                                                            ##
##   Last Modified:15/10/12                                                            ##
##   Purpose:This script is used to call FCD Bulk workflow                             ##
##   Created By: Subhashree                                                            ##
##                                                                                     ##
#########################################################################################


pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD  -f EEDW09 wflw_GEEDW_B_FCD_DAILY
