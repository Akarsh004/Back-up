
# ---------------------------------------------------------------------------- 
#			
# File: sh_GEEDW_SHELL_CALL_ODS_DELETES.sh
# Creation Date: 09/20/11 
# Last Modified: 09/20/11 
# Purpose:This is used for deleting records in stage tables for ORAP
# Created By: Ragini
#
# ----------------------------------------------------------------------------
pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_ODS_DELETES