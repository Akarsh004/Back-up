pmcmd startworkflow -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_TCT_BULK
