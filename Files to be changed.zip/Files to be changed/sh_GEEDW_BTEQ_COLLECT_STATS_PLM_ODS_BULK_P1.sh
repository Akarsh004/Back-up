##################################################################################################################################
##                                                                                                                              ##
##       Script Name:sh_GEEDW_BTEQ_COLLECT_STATS_PLM_ODS_BULK.sh                                                                ##
##       Author: Sanjib Patra                                                                                                   ##
##       Creation Date:09-AUG-2012                                                                                              ##
##       Modified Date:                                                                                                         ##
##                                                                                                                              ##
##       Description:                                                                                                           ##
##        This Script calls the sh_GEEDW_BTEQ_COLLECT_STATS_PLM_ODS_BULK.sql and runs the collect stats on PLM ODS Bulk Tables. ##
##                                                                                                                              ##
##                                                                                                                              ##
##################################################################################################################################

pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_PWODS_STAGE

. /data/informatica/ETCOE/EEDW01/SrcFiles/dbenv.sh

bteq <<EOF

/* .RUN File = ${SrcDir}/td_plp.mlbt */

 .RUN File = /apps/informatica/product/pc/bin/td_geedw_plp.mlbt; 

database GEEDW_PLM_ODS_BULK_V;

.run FILE=/data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_BTEQ_COLLECT_STATS_PLM_ODS_BULK_P1.sql;

.LOGOFF
.EXIT 0
EOF

bteqexitcode=$?
echo "Exited With errorcode $bteqexitcode"
exit $bteqexitcode