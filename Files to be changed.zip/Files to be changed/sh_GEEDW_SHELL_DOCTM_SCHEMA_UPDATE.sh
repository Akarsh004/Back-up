###################################################################################################
##############################created by Tech Mahindra ##########################################
##############################created date : 17th July 2014 ####################################
##############################Reviewed by :Gayatri Sahoo #########################################
##############################Purpose : Updating the schema name in documentum parameter file ###########################
###################################################################################################
#bin bash
SCH=`cat /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DOCUMENTUM_STAGE.txt | grep '\$\$DCDE=' | awk -F'=' '{print $2}'`
echo $SCH
if [ $SCH = 'DCTE' ]
then
DCDE="DCIG"
DCDE1="\$\$DCDE="$DCDE
#SRCTYPE="'DCIG'"
#SRCTYPE1="\$\$SRCTYPE="$SRCTYPE
sed -i "/DCDE=/ c $DCDE1" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DOCUMENTUM_STAGE.txt
#sed -i "/SRCTYPE=/ c $SRCTYPE1" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DOCUMENTUM_STAGE.txt
echo "Documentum workflow triggered"
pmcmd startworkflow -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW08 wflw_GEEDW_DOCUMENTUM_STAGE
exit 0;
else
if [ $SCH = 'DCIG' ]
then
DCDE="DCTE"
DCDE1="\$\$DCDE="$DCDE
#SRCTYPE="'DCTE'"
#SRCTYPE1="\$\$SRCTYPE="$SRCTYPE
sed -i "/DCDE=/ c $DCDE1" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DOCUMENTUM_STAGE.txt
#sed -i "/SRCTYPE=/ c $SRCTYPE1" /data/informatica/ETCOE/EEDW01/Config/wflw_GEEDW_DOCUMENTUM_STAGE.txt
echo "Documentum workflow not triggered"
fi
fi
exit 0;
