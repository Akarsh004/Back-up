	#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_GEEDW_SHELL_CALL_S_ORAP_INTEGRATION_RUN_DTL.sh
# Creation Date:28/11/12
# Last Modified: 28/11/12
# Purpose:Calls the workflow  wflw_GEEDW_S_ORAP_INTEGRATION_RUN_DTL
# Created By: Nitai
#
# ----------------------------------------------------------------------------

##############CALL THE WORKFLOW##############
pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW02 wflw_GEEDW_INTEGRATION_RUN_DTL

