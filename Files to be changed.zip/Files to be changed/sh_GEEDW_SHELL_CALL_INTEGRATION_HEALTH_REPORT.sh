	#!/usr/bin/ksh
# ----------------------------------------------------------------------------
#
# File:sh_GEEDW_DELETE_HEALTH_REPORT.sh
# Creation Date:10/13/12
# Last Modified: 10/13/12
# Purpose:Calls the workflow  wflw_GEEDW_B_INTEGRATION_RUN_DTL
# Created By: Sasmita
#
# ----------------------------------------------------------------------------

##############CALL THE WORKFLOW##############
pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_B_INTEGRATION_RUN_DTL