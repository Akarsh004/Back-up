sh /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_INTERFACE_DAILY_BULK1.sh > /data/informatica/ETCOE/EEDW01/ScriptFiles/sh_GEEDW_SHELL_CALL_INTERFACE_DAILY_BULK_LOG.txt 2>&1;
