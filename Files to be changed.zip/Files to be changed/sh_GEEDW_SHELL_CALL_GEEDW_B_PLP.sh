####################################################################################################################################
## Script Name:sh_GEEDW_SHELL_CALL_GEEDW_PLP_GIB_GEEDW_B_PLP.sh 										##
## Author: Sanjib Patra 																##
## Creation Date:09-AUG-2012 															##
## Modified Date: 																	##
## 																			##
## Description: 																	##
##   This Script triggers wflw_GEEDW_B_PLP 							                                         ##
## 																			##
##          																		##
####################################################################################################################################



pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_B_PLP
