#########################################################################################
##	Author: Aditya Ranjan, 18-MAR-2013
##
##	This script
##	1) This Script calls the workflow wflw_GEEDW_DAILY_BULK_LX_MX_TABLES which is loacted in the folder EEDW05
##	 
###########################################################################################
rm -f /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_ODS_LXSTATE_398850F1_cdr_ods_lxstate_398850f1_s.out;
pmcmd startworkflow -sv INF_AV_ASCII -d INF_PWPROD_DOM -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DAILY_BULK_LX_MX_TABLES