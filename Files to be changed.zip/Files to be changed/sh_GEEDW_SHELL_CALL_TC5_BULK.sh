pmcmd startworkflow -sv INF_AV_UNICODE -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW09 wflw_GEEDW_TC5_BULK
