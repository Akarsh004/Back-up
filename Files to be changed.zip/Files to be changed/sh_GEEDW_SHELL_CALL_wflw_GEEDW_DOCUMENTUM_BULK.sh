#########################################################################################
##	Author: Ragini Banerjee, 5-NOV-2012
##
##	This script
##	1) This Script Calls the workflow wflw_GEEDW_DOCUMENTUM_BULK located in the folder EEDW05
##	 
###########################################################################################
rm -f /data/informatica/ETCOE/EEDW01/OutFiles/s_m_GEEDW_S_DOCTM_DM_SYSOBJECT_R_cdr_doctm_dm_sysobject_r1.out;
pmcmd startworkflow -sv INF_AV_ASCII -d INF_AVPROD_DOM1 -uv PM_USER -pv PM_PASSWD -f EEDW05 wflw_GEEDW_DOCUMENTUM_BULK