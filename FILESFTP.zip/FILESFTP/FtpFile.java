import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class FtpFile {

	/**
	 * @param args
	 */
	String RemoteHostName;
	int port;
	String UserName;
	String Password;
	String RemotePath;
	String RemoteFileName;
	String LocalPath;
	String DateFormat1;
	String AppendCHAR;
	boolean AppendDate;
	boolean IsLikeOperator;
	boolean MultiFile;
	FTPClient ftp_client;
	int History;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String PropFile=args[0];
		String FileDate=args[1];
		System.out.println("PropFile:"+PropFile);
		System.out.println("FileDate:"+FileDate);
		FtpFile FTPInstance= new FtpFile();
		FTPInstance.executeFTP(PropFile,FileDate);
	}

	private Date StringtoDate(String DT){
		try{
			SimpleDateFormat DateFormat = new SimpleDateFormat(DateFormat1); 
			
			return DateFormat.parse(DT);
		} catch ( Exception e)
		{
			System.out.println("Date Error:-"+ e.toString());
			return null;
		}

	}
	private String DatetoString(Date DT){
		try{
			SimpleDateFormat DateFormat = new SimpleDateFormat (DateFormat1); 
			return DateFormat.format(DT);
		} catch ( Exception e)
		{
			System.out.println("Date Error:-"+ e.toString());
			return null;
		}

	}
	private void executeFTP(String PropFile, String DT)
	{		 
		setConfguration(PropFile);
		setConnection(RemoteHostName,port, UserName, Password);	
		//PC1DownloadFile(RemotePath,RemoteFileName, LocalPath);
		DownloadFile(RemotePath,RemoteFileName, LocalPath,DT);

	}


	public void setConnection(String RemoteHostName,int port,String UserName,String Password) 

	{
		ftp_client = new FTPClient();
		try{
			
			System.out.println("Before Connecting");
			System.out.println ("RemoteHostName" +RemoteHostName +"\nport:" + port + "\nUserName:" + UserName + "\nPassword:" +Password );
			ftp_client.connect(RemoteHostName, port);
			ftp_client.login(UserName, Password);
			ftp_client.enterLocalPassiveMode();
			ftp_client.setFileType(FTP.BINARY_FILE_TYPE);
			System.out.println("After Connecting");
		}catch (Exception e)
		{
			System.out.println("FTP Error");
			System.out.println(e.toString());
		}

	}
	public void altDownload()
	{
		if (AppendDate)
		{
			if(IsLikeOperator)
			{

			}else{

			}

		}else{

			if(IsLikeOperator)
			{

			}else{

			}

		}

	}

	private Date AddDate(Date DT,int Days)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(DT);
		cal.add(Calendar.DATE,Days );
		return cal.getTime();
	}
	public void DownloadFile(String RemotePath,String RemoteFileName,String LocalPath,String FileDate)
	{
		try
		{
		String DownloadFile[]= null;
		HashMap<Integer, String>  FileDownload= new HashMap<Integer, String>();
		OutputStream outputStream=null;
		


			if (MultiFile)
			{
				DownloadFile=RemoteFileName.split("\\|");
			}else
			{
				DownloadFile= new String[1];
				DownloadFile[0]=RemoteFileName;
			}


			if(AppendDate)
			{
				int j= DownloadFile.length;
				int Seq=0;
				for(int i=0; i<j; i++)
				{
					String TempDownloadFile=DownloadFile[i];

					for (int k=0; k<History;k++ )
					{

						Date DT=StringtoDate(FileDate);
						DT=AddDate(DT,-k);
						String newDownloadFile=TempDownloadFile.replaceAll(AppendCHAR, DatetoString(DT));
						FileDownload.put(Seq, newDownloadFile);				    	
						Seq= Seq+1;

					}

				}   
			} else {
				int j= DownloadFile.length;
				int Seq=0;
				for(int i=0; i<j; i++)
				{
					String TempDownloadFile=DownloadFile[i];
					FileDownload.put(Seq, TempDownloadFile);				    	
					Seq= Seq+1;
				}

			}


			if(IsLikeOperator)
			{

				String RemoteFiles[]=ftp_client.listNames(RemotePath);
				/*
				try{
				ftp_client.cwd(RemotePath);
			
				FTPFile[] files = null;
				int i = ftp_client.list(RemotePath);
				
			    
			    for (int k= 0 ;k<files.length;k++)
			    {
			    	FTPFile f = files[k];
			    	System.out.println(f.getName());
			    }
				}
				catch(Exception e)
				{ System.out.println(e.toString());} 
					
			    */
			    
				int j= RemoteFiles.length;
				for(int i=0; i<j; i++)
				{
					String RemoteFile=RemoteFiles[i];
					RemoteFile=RemoteFile.substring(RemoteFile.lastIndexOf("/")+1,RemoteFile.length() );
					Set<Integer> Keyset=FileDownload.keySet();
					Iterator<Integer> itr = Keyset.iterator();
					while (itr.hasNext())
					{
						Integer Key = itr.next();

						if (RemoteFile.contains((String)FileDownload.get(Key)))
						{
							//String remoteFiles =FileDownload.get(Key).toString();
							System.out.println(RemoteFile);
							String nwRemotepath=RemotePath+RemoteFile;
							String nwLocalPath=LocalPath+RemoteFile;
							outputStream= new BufferedOutputStream(new FileOutputStream(nwLocalPath));
							boolean success = ftp_client.retrieveFile(nwRemotepath, outputStream);
						}

					}
				}



			}else{
				Set<Integer> Keyset=FileDownload.keySet();
				Iterator<Integer> itr = Keyset.iterator();
				while (itr.hasNext())
				{
					Integer Key = itr.next();
					String nwRemotepath=RemotePath+FileDownload.get(Key);
					String nwLocalPath=LocalPath+FileDownload.get(Key);
					outputStream= new BufferedOutputStream(new FileOutputStream(nwLocalPath));
					boolean success = ftp_client.retrieveFile(nwRemotepath, outputStream);
				}


			}

		}catch (Exception e)
		{
			System.out.println(e.toString());
		}

	}



	private void setConfguration(String PropFile)
	{
		Properties prop = new Properties();
		InputStream input = null;
		try {

			System.out.println("In setConfguration");
			input = new FileInputStream(PropFile);
			prop.load(input);
			
			RemoteHostName=prop.getProperty("RemoteHostName");
			System.out.println("RemoteHostName:"+RemoteHostName);
			port=Integer.parseInt(prop.getProperty("port"));
			UserName=prop.getProperty("UserName");
			Password=prop.getProperty("Password");
			RemotePath=prop.getProperty("RemotePath");
			RemoteFileName=prop.getProperty("RemoteFileName");
			LocalPath=prop.getProperty("LocalPath");
			IsLikeOperator=Boolean.parseBoolean(prop.getProperty("IsLikeOperator"));
			MultiFile=Boolean.parseBoolean(prop.getProperty("MultiFile"));
			AppendDate=Boolean.parseBoolean(prop.getProperty("AppendDate"));
			DateFormat1=prop.getProperty("DateFormat");
			AppendCHAR=prop.getProperty("AppendReplaceFileCHAR");

			History=Integer.parseInt(prop.getProperty("History"));
		}catch(Exception e)
		{
			System.out.println("setconfiguration Method Error:"+e.toString());
		}


	}


}
