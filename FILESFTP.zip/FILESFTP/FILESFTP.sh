#!/bin/bash
TODAYDT=date
HOMEPATH='/data/informatica/ETCOE/EEDW01/JAVA_CODE'
export HOMEPATH
echo HOMEPATH: $HOMEPATH

PROJECTPATH=$HOMEPATH/FILESFTP
export PROJECTPATH
echo PROJECTPATH: $PROJECTPATH

LOGPATH=$PROJECTPATH
export LOGPATH
echo LOGPATH: $LOGPATH

LIB=$HOMEPATH/lib
export LIB
echo LIB: $LIB 

CLASSPATH=$LIB/commons-net-1.4.1.jar
CLASSPATH=$CLASSPATH:$PROJECTPATH
echo $CLASSPATH
export CLASSPATH

cd $PROJECTPATH
pwd

#Compile Code
#/data/informatica/ETCOE/EEDW01/JAVA_CODE/JAVA/bin/javac -Xlint:unchecked -classpath $CLASSPATH  FtpFile.java 1>$LOGPATH/COMPILE"$TODAYDT".txt 
#chmod 777 FtpFile.class


#RUN Code
/data/informatica/ETCOE/EEDW01/JAVA_CODE/JAVA/bin/java -classpath $CLASSPATH  FtpFile /data/informatica/ETCOE/EEDW01/JAVA_CODE/FILESFTP/FTP_CDI_Config.txt 170226  1>$LOGPATH/SFTPFILE"$TODAYDT".txt 
